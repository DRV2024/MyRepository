# Gui Test Starter

Dieses Repository dient als Startpunkt für die Erstellung von Oberflächentests mit Playwright und Cucumber auf Basis von Typescript.

## Basis und Kudos

Die Inhalte basieren auf dem Repository [cucumber-playwright](https://github.com/Tallyb/cucumber-playwright)

## Installation

```
npm i
npx playwright install
```

## Verwendung mit mehreren Teams

Unter "Umgebungsvariablen für dieses Konto bearbeiten" die Umgebungsvariable RVFitTeam mit dem jeweiligen Wert des Team-Namen hinzufügen.

## Umgebungsvariablen

Die Konfiguration der Tests geschieht über Umgebungsvariablen, diese steuern wie die Tests laufen und welche Services sie ansprechen. Eine BEispielskonfiguration die in die .bashrc eingetragen werden kann sähe so aus:


``` 
export RVFitTeam="flash"
export ENVIRONMENT="local"
```

### Ausführung von Tests

`npm run test` zur Ausführung aller Tests

`npm run test <Featurename>` zur Ausführung eines einzelnen Features

### Browserverwendung

Per Default wird Chromium verwendet. Über die Umgebungsvariable `BROWSER` kann der Name eines alternativen Browsers gesetzt werden.

Mögliche Optionen: chromium, firefox, webkit

Beispiel für Windows

```
set BROWSER=firefox
npm run test
```

### Ignorieren eines Szenarios

Durch Verwendung des Tags `@ignore`

### Identifizieren von TypeScript, Linting oder Gherkin Fehlern

`npm run build`

### Auswertung der Step-Usage

`npm run steps-usage`

\*Weitere Optionen/Befehle lassen sich aus dem [Basis-Repo](https://github.com/Tallyb/cucumber-playwright) entnehmen.

### Verwendung Gherkin Linter
Unter `.gherkin-lintrc` werden die entsprechenden Gherkin-Regeln konfiguriert.

`npm run gherkin` führt eine Validierung der Gherkin-Regeln durch.

### Sichten eines Playwright Trace

Zu jedem fehlgeschlagenen Szenario wird ein Trace im Ordner `trace` gespeichert.

Dieser Trace kann mittels `npx playwright show-trace <NAME-DES-TRACE>.zip` analysiert werden.
