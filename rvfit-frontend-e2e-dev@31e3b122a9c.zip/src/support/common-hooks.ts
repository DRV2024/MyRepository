import { ICustomWorld } from './custom-world';
import { config } from './config';
import { Einrichtungen } from '../pages/einrichtungen';
import { VersichertenHeader } from '../pages/versichertenHeader';
import { Anspruchspruefung } from '../pages/anspruchspruefung';
import { Aussteurung } from '../pages/aussteurung';
import { Antragaufnahme } from '../pages/antragaufnahme';
import { Keycloak } from '../pages/keycloak';
import { Sachverhaltsaufklaerung } from '../pages/sachverhaltaufklaerung';
import { Before, After, BeforeAll, AfterAll, Status, setDefaultTimeout } from '@cucumber/cucumber';
import {
  chromium,
  ChromiumBrowser,
  firefox,
  FirefoxBrowser,
  webkit,
  WebKitBrowser,
  ConsoleMessage,
  request,
} from '@playwright/test';
import { ITestCaseHookParameter } from '@cucumber/cucumber/lib/support_code_library_builder/types';
import { ensureDir } from 'fs-extra';

let browser: ChromiumBrowser | FirefoxBrowser | WebKitBrowser;
const tracesDir = 'traces';

declare global {
  // eslint-disable-next-line no-var
  let browser: ChromiumBrowser | FirefoxBrowser | WebKitBrowser;
}

setDefaultTimeout(process.env.PWDEBUG ? -1 : 30 * 1000);

BeforeAll(async function () {
  switch (config.browser) {
    case 'firefox':
      browser = await firefox.launch(config.browserOptions);
      break;
    case 'webkit':
      browser = await webkit.launch(config.browserOptions);
      break;
    default:
      browser = await chromium.launch(config.browserOptions);
  }
  await ensureDir(tracesDir);
});

Before({ tags: '@ignore' }, async function () {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return 'skipped' as any;
});

Before({ tags: '@debug' }, async function (this: ICustomWorld) {
  this.debug = true;
});

Before(async function (this: ICustomWorld, { pickle }: ITestCaseHookParameter) {
  this.startTime = new Date();
  this.testName = pickle.name.replace(/\W/g, '-');
  // customize the [browser context](https://playwright.dev/docs/next/api/class-browser#browsernewcontextoptions)
  this.context = await browser.newContext({
    acceptDownloads: true,
    recordVideo: process.env.PWVIDEO ? { dir: 'screenshots' } : undefined,
    // viewport: { width: 1900, height: 1200 },
    viewport: null,
  });
  this.requestContext = await request.newContext({
    // All requests we send go to this API endpoint.
    baseURL: config.BASE_API_URL,
  });

  //Endpoint zum reset der Datenbank vor jedem Test
  this.requestResponse = await this.requestContext?.delete('/testsupport/antraege', {
    headers: {
      authorization: `Bearer ${this.accessToken}`,
    },
  });

  await this.context.tracing.start({ screenshots: true, snapshots: true });
  this.page = await this.context.newPage();
  this.anspruchspruefung = new Anspruchspruefung(this.page);
  this.aussteurung = new Aussteurung(this.page);
  this.einrichtungen = new Einrichtungen(this.page);
  this.versichertenHeader = new VersichertenHeader(this.page);
  this.antragaufnahme = new Antragaufnahme(this.page);
  this.keycloak = new Keycloak(this.page);
  this.sachverhaltsaufklaerung = new Sachverhaltsaufklaerung(this.page);
  this.page.on('console', async (msg: ConsoleMessage) => {
    if (msg.type() === 'error') {
      this.attach(msg.text());
    }
  });
  this.feature = pickle;
});

After(async function (this: ICustomWorld, { result }: ITestCaseHookParameter) {
  if (result) {
    this.attach(`Status: ${result?.status}. Duration:${result.duration?.seconds}s`);

    if (result.status !== Status.PASSED) {
      const image = await this.page?.screenshot();
      image && this.attach(image, 'image/png');
      const traceFileName = `${this.testName}-${this.startTime
        ?.toISOString()
        .replaceAll(':', '-')
        .split('.')[0]}`;
      await this.context?.tracing.stop({
        path: `${tracesDir}/${traceFileName}-trace.zip`,
      });
    }

    //Endpoint zum reset der Datenbank vor jedem Test auf Team space
    const resetUUIDApiContext = await request.newContext({
      baseURL: config.BASE_SERVICE_PIPELINE_URL,
    });
    const deletePath = `/antraege/${this.uuid}`;
    //console.log(`id zu löschen ${this.uuid}`);
    try {
      //Delete Request von generierten UUID
      //const resetRequest =
      await resetUUIDApiContext?.delete(deletePath, {
        headers: {
          authorization: `Bearer ${this.accessToken}`,
        },
      });
      // const requestStatus = resetRequest.status();
      //  console.log(`Status der Delete Request ${requestStatus}`);
    } finally {
      await resetUUIDApiContext.dispose();
    }
  }
  await this.page?.close();
  // verwirft alle gespeicherten Antworten
  await this.requestContext?.dispose();

  await this.context?.close();
});

AfterAll(async function () {
  await browser.close();
});
