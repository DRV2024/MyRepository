import { Einrichtungen } from '../pages/einrichtungen';
import { VersichertenHeader } from '../pages/versichertenHeader';
import { Antragaufnahme } from '../pages/antragaufnahme';
import { Anspruchspruefung } from '../pages/anspruchspruefung';
import { Sachverhaltsaufklaerung } from '../pages/sachverhaltaufklaerung';
import { Aussteurung } from '../pages/aussteurung';
import { Keycloak } from '../pages/keycloak';
import { setWorldConstructor, World, IWorldOptions } from '@cucumber/cucumber';
import * as messages from '@cucumber/messages';
import {
  BrowserContext,
  Page,
  PlaywrightTestOptions,
  APIRequestContext,
  APIResponse,
} from '@playwright/test';

export interface CucumberWorldConstructorParams {
  parameters: { [key: string]: string };
}

export interface ICustomWorld extends World {
  debug: boolean;
  feature?: messages.Pickle;
  context?: BrowserContext;
  page?: Page;
  aussteurung?: Aussteurung;
  anspruchspruefung?: Anspruchspruefung;
  einrichtungen?: Einrichtungen;
  versichertenHeader?: VersichertenHeader;
  antragaufnahme?: Antragaufnahme;
  keycloak?: Keycloak;
  sachverhaltsaufklaerung?: Sachverhaltsaufklaerung;
  testName?: string;
  startTime?: Date;
  accessToken?: string;
  uuid?: string;

  requestContext?: APIRequestContext;
  requestPath?: string;
  requestParams?: { [key: string]: string | number | boolean };
  requestResponse?: APIResponse;

  playwrightOptions?: PlaywrightTestOptions;
}

export class CustomWorld extends World implements ICustomWorld {
  constructor(options: IWorldOptions) {
    super(options);
  }
  debug = false;
}

setWorldConstructor(CustomWorld);
