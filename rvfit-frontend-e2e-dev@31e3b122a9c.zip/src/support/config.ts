import { getBackendUrl, getTestServiceUrl } from './environments';
import { LaunchOptions } from '@playwright/test';
import 'dotenv/config';
const browserOptions: LaunchOptions = {
  headless: true,
  devtools: false,
  slowMo: 0,
  args: [
    '--use-fake-ui-for-media-stream',
    '--use-fake-device-for-media-stream',
    '--start-maximized',
    //'--disable-web-security',
  ],
  firefoxUserPrefs: {
    'media.navigator.streams.fake': true,
    'media.navigator.permission.disabled': true,
  },
};

export const config = {
  browser: process.env.BROWSER || 'chromium',
  browserOptions,
  IMG_THRESHOLD: { threshold: 0.4 },
  BASE_API_URL: `${getBackendUrl()}`,
  BASE_SERVICE_PIPELINE_URL: `${getTestServiceUrl()}`,
  clientInfos: {
    id: process.env.CLIENT_ID!,
    secret: process.env.CLIENT_SECRET!,
  },
  keycloakUrl: process.env.KEYCLOAK_URL!,
};

export function getClientID() {
  return config.clientInfos.id;
}

export function getClientSecret() {
  return config.clientInfos.secret;
}

export function getKeycloakUrl() {
  return config.keycloakUrl;
}
