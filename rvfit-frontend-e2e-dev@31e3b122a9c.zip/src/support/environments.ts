import 'dotenv/config';
export const getFrontendUrl = (): string => {
  const environment = process.env.ENVIRONMENT || 'shared';
  const sharedNumber = process.env.SHAREDNUMBER || '5';
  switch (environment.toLowerCase()) {
    case 'dev':
      return `https://rvfit-frontend-dev1-dev.apps.os-evo.entw.bund.drv`;
    case 'shared':
      return `https://rvfit-frontend-dev1-shared${sharedNumber}.apps.os-evo.entw.bund.drv`;
    case 'local':
      return 'http://localhost:4200';
    case 'demo':
      return '';
    default:
      throw new Error(`Unbekannter Wert '${environment}' für 'ENVIRONMENT' gesetzt.`);
  }
};

export const getBackendUrl = (): string => {
  const environment = process.env.ENVIRONMENT || 'shared';
  const sharedNumber = process.env.SHAREDNUMBER || '5';
  switch (environment.toLowerCase()) {
    case 'dev':
      return `https://rvfit-backend-dev1-dev.apps.os-evo.entw.bund.drv`;
    case 'shared':
      return `https://rvfit-backend-dev1-shared${sharedNumber}.apps.os-evo.entw.bund.drv`;
    case 'demo':
      return 'http://localhost:8080';
    case 'local':
      return 'http://localhost:8080';
    default:
      throw new Error(`Unbekannter Wert '${environment}' für 'ENVIRONMENT' gesetzt.`);
  }
};

export const getTestServiceUrl = (): string => {
  const environment = process.env.ENVIRONMENT || 'shared';
  const sharedNumber = process.env.SHAREDNUMBER || '5';
  switch (environment.toLowerCase()) {
    case 'dev':
      return 'https://rvfit-test-data-service-dev1-dev.apps.os-evo.entw.bund.drv';
    case 'shared':
      return `https://rvfit-test-data-service-dev1-shared${sharedNumber}.apps.os-evo.entw.bund.drv`;
    case 'demo':
      return 'http://localhost:8080';
    case 'local':
      return 'http://localhost:8080';
    default:
      throw new Error(`Unbekannter Wert '${environment}' für 'ENVIRONMENT' gesetzt.`);
  }
};
