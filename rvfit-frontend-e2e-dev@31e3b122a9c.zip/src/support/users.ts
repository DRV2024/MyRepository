import { config } from 'dotenv';
config();
export interface User {
  userName: string;
  password: string;
}

export const usersMap: Record<string, User> = {
  benutzer_Ktan_15: {
    userName: getEnvVariable('BENUTZER_KTAN_15'),
    password: getEnvVariable('KENNWORT_KTAN_15'),
  },
  benutzer_Ktan_17: {
    userName: getEnvVariable('BENUTZER_KTAN_17'),
    password: getEnvVariable('KENNWORT_KTAN_17'),
  },
  benutzer_Ktan_70: {
    userName: getEnvVariable('BENUTZER_KTAN_70'),
    password: getEnvVariable('KENNWORT_KTAN_70'),
  },
};

//Funtkion zu prüfen ob die Zugangsdaten in der .env Datei vorhanden sind
function getEnvVariable(varName: string): string {
  const entVarWert = process.env[varName];
  if (!entVarWert) {
    throw new Error(`Umgebungs Variable ${varName} ist undefiniert`);
  }
  return entVarWert;
}
