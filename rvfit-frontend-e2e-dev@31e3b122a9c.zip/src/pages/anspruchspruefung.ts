import { getFrontendUrl } from '../support/environments';
import { Locator, Page } from '@playwright/test';

export class Anspruchspruefung {
  readonly page: Page;
  //Button
  private readonly button: Locator;
  //Anspruchsprüfung
  private readonly ueberschrift: Locator;
  private readonly unterueberschrift: Locator;
  private readonly erfuelltItems: Locator;
  private readonly nichtErfuelltItems: Locator;
  private readonly nichtErmittelbarItems: Locator;
  private readonly regel1: Locator;
  private readonly regel2: Locator;
  private readonly regel3: Locator;
  private readonly nicht_erfuellt_regel03: Locator;
  private readonly regel4: Locator;
  private readonly regel5: Locator;
  private readonly regel6: Locator;
  private readonly regel7: Locator;
  private readonly regel8: Locator;
  private readonly regel9: Locator;
  private readonly regel10: Locator;
  private readonly buttonRegel1: Locator;
  private readonly buttonAblehnen: Locator;
  private readonly nicht_ermittelbar_regel01: Locator;
  private readonly begründung1: Locator;
  private readonly begründung2: Locator;
  private readonly begründung3: Locator;
  private readonly nicht_erfuellt_begruendung03: Locator;
  private readonly begründung4: Locator;
  private readonly begründung5: Locator;
  private readonly begründung6: Locator;
  private readonly begründung7: Locator;
  private readonly begründung8: Locator;
  private readonly begründung9: Locator;
  private readonly begründung10: Locator;
  private readonly error!: Locator;
  private ändernNichtErfüllt!: Locator;
  private ändernNichtErmittelbar!: Locator;
  private ändern!: Locator;
  private openstaat: Locator;
  private nichtErf!: Locator;
  private ausklappSymbol!: Locator;
  //Sidepanel
  private readonly schliessen: Locator;
  private readonly radioNichtErfüllt: Locator;
  private readonly radioErfüllt: Locator;
  private readonly radioNichtErfülltChecked: Locator;
  private readonly radioErfülltChecked: Locator;
  private readonly begruendung: Locator;
  private readonly anzahlZeichen: Locator;
  private readonly sidepanelTitle: Locator;
  private readonly frage: Locator;
  private readonly begruendungLabel: Locator;
  private readonly fehler: Locator;
  private readonly alert: Locator;
  private readonly speichern: Locator;
  private readonly reset: Locator;
  private readonly geaenderteMeldung: Locator;
  private readonly maschinellesErgebnisNichtErfüllt: Locator;
  private readonly maschinellesÄndernErmittelbar: Locator;
  private readonly maschinellesÄndernNichtErfüllt: Locator;
  private readonly maschinellesÄndernErmittelbarStaat: Locator;
  private readonly fehlerRadio: Locator;
  private readonly alertRadio: Locator;
  private readonly sachverhaltAufklaeren: Locator;
  private readonly antragBewilligen: Locator;
  private readonly infomeldung: Locator;
  private readonly erfülltList: Locator;
  private readonly nichtErfülltList: Locator;
  private readonly nichtErmittelbarList: Locator;

  private readonly antragBewilligenErfolgreich: Locator;
  private readonly antragBewilligenTechFehler: Locator;
  readonly antragAblehnen: Locator;
  readonly antragAblehnenÜberschift: Locator;
  readonly antragAblehnenZwischenÜberschift: Locator;
  readonly antragAblehnenBeschreibung: Locator;
  readonly antragAbelehnenErfolgsmeldung: Locator;
  readonly antragAblehnenTechFehler: Locator;
  readonly iframeAntragAblehnen: Locator;
  readonly absenden: Locator;
  readonly documentabsendenok: Locator;
  readonly telNummer: Locator;
  readonly änderungsDatum: Locator;
  // readonly iframeSachverhaltsaufklaerung: Locator;
  // readonly absendenSachverhaltsaufklaerung: Locator;
  //uuid variable wird auf diesen Skope umbennant, um Verwirrung mit der UUID Variable vom Custom-world zu vermeiden
  private uuidWert?: string;

  constructor(page: Page) {
    this.page = page;
    //Button
    this.button = page.locator('#buttonAktion');
    this.buttonAblehnen = page.locator('#buttonAktion > button > span');
    //Anspruchsprüfung
    this.ueberschrift = page.locator('#anspruchspruefung-h2');
    this.unterueberschrift = page.locator('#anspruchspruefung-p');
    this.erfuelltItems = page.locator('#tableErfuellt').locator('tr');
    this.nichtErfuelltItems = page.locator('#tableNichtErfuellt').locator('tr');
    this.nichtErmittelbarItems = page.locator('#tableNichtErmittelbar').locator('tr');
    this.erfuelltItems = page.locator('#tableErfuellt').getByRole('listitem');
    this.nichtErfuelltItems = page.locator('#tableNichtErfuellt').getByRole('listitem');
    this.nichtErmittelbarItems = page.locator('#tableNichtErmittelbar').getByRole('listitem');
    this.regel1 = page.locator('#regelNichtErfuellt0');
    this.regel2 = page.locator('#regelNichtErfuellt1');
    this.regel3 = page.locator('#regelNichtErfuellt2');
    this.nicht_erfuellt_regel03 = page.locator('#regelNichtErfuellt3');
    this.regel4 = page.locator('#regelNichtErmittelbar0');
    this.regel5 = page.locator('#regelErfuellt0');
    this.regel6 = page.locator('#regelErfuellt1');
    this.regel7 = page.locator('#regelErfuellt2');
    this.regel8 = page.locator('#regelErfuellt3');
    this.regel9 = page.locator('#regelErfuellt4');
    this.regel10 = page.locator('#regelNichtErmittelbar1');
    this.buttonRegel1 = page.locator('#buttonNichtErfuellt0');
    this.nicht_ermittelbar_regel01 = page.locator('#regelNichtErmittelbar0');
    this.begründung1 = page.locator('#begruendungNichtErfuellt0');
    this.begründung2 = page.locator('#begruendungNichtErfuellt1');
    this.begründung3 = page.locator('#begruendungNichtErfuellt2');
    this.nicht_erfuellt_begruendung03 = page.locator('#begruendungNichtErfuellt2');
    this.begründung4 = page.locator('#begruendungNichtErmittelbar0');
    this.begründung5 = page.locator('#begruendungErfuellt0');
    this.begründung6 = page.locator('#begruendungErfuellt1');
    this.begründung7 = page.locator('#begruendungErfuellt2');
    this.begründung8 = page.locator('#begruendungErfuellt3');
    this.begründung9 = page.locator('#begruendungErfuellt4');
    this.begründung10 = page.locator('#begruendungNichtErmittelbar1');
    this.error = page.locator('#fehlerMeldungNichtErmittelbar0');
    this.openstaat = page.locator('#buttonNichtErfuellt0');
    this.erfülltList = page.locator('#bullet-check').getByRole('img');
    this.nichtErfülltList = page.locator('#error-alt').getByRole('img');
    this.nichtErmittelbarList = page.locator('#question-mark').getByRole('img');
    this.telNummer = page.locator('#vsnr').getByText('Telefon:');
    this.änderungsDatum = page.locator('#originalErgebnisNichtErfuellt2');

    this.schliessen = page.getByRole('button', { name: 'schließen', exact: true });
    this.ausklappSymbol = page.locator('#bullet-check');
    //Sidepanel
    this.radioErfülltChecked = page.locator('#radiobuttonErfuellt');
    this.radioNichtErfülltChecked = page.locator('#radiobuttonNichtErfuellt');
    this.radioErfüllt = page.locator('drv-radioButton[name="radiobuttonErfuellt"]');
    this.radioNichtErfüllt = page.locator('drv-radioButton[name="radiobuttonNichtErfuellt"]');
    //this.radioNichtErfüllt = page.getByText('Ja, ');
    this.begruendung = page.locator('#begruendung');
    this.speichern = page.locator('#buttonSpeichern');
    this.anzahlZeichen = page.locator('#begruendung_count');
    this.sidepanelTitle = page.locator('#sidepanel-heading-sidepanel');
    this.frage = page.locator('#inputGroupId-legend');
    this.begruendungLabel = page.locator('label[for="begruendung"]');
    this.fehler = page.locator('#begruendung-errors').locator('.drv-field-message__text');
    //this.alert = page.locator('#begruendung-errors').locator('[ng-reflect-type="attention"]');
    this.alert = page.locator('ul[id="inputGroupId-errors"]>li>span>drv-icon');
    this.reset = page.locator('#buttonReset');
    this.geaenderteMeldung = page.locator('#originalErgebnisNichtErfuellt0');
    this.maschinellesErgebnisNichtErfüllt = page.locator('#originalErgebnisMeldung');
    this.maschinellesÄndernErmittelbar = page.locator('#originalErgebnisNichtErfuellt3');
    this.maschinellesÄndernNichtErfüllt = page.locator('#originalErgebnisErfuellt2');
    this.maschinellesÄndernErmittelbarStaat = page.locator('#originalErgebnisNichtErfuellt0');
    this.fehlerRadio = page.locator('#inputGroupId').locator('.drv-field-message__text');
    this.alertRadio = page.locator('ul[id="begruendung-errors"]>li>span>drv-icon');
    this.sachverhaltAufklaeren = page.locator('#buttonSachverhalt');
    this.antragBewilligen = page.locator('#buttonAktion');
    this.infomeldung = page.getByText('Anspruchsvoraussetzung ist nicht erfüllt.');
    this.antragBewilligenErfolgreich = page.getByText('Antrag bewilligt', { exact: true });
    this.antragBewilligenTechFehler = page.locator('#notification_header_bewilligung-error');
    this.antragAblehnen = page.locator('#buttonAktion');
    this.antragAblehnenÜberschift = page.locator('#antrag-ablehnung-title');
    this.antragAblehnenZwischenÜberschift = page.locator('#antrag-ablehnung-subtitle');
    this.antragAblehnenBeschreibung = page.locator('#antrag-ablehnung-erklaerung');
    this.antragAblehnenTechFehler = page.locator('#notification_header_error');
    this.iframeAntragAblehnen = page.locator('#antrag-ablehnung-iframe');
    this.absenden = page
      .frameLocator('#antrag-ablehnung-iframe')
      .getByRole('button', { name: 'Absenden' });
    this.documentabsendenok = page
      .frameLocator('#antrag-ablehnung-iframe')
      .getByRole('button', { name: 'Ok' });
    this.antragAbelehnenErfolgsmeldung = page.getByText('Antrag abgelehnt');
  }

  public async openAnspruchspruefung(uuidWert: string) {
    await this.page?.goto(`${getFrontendUrl()}/antrag/${uuidWert}/anspruchspruefung`);
  }

  public async checkSeite() {
    return this.page.url();
  }

  public async getUeberschrift() {
    return this.ueberschrift.innerText();
  }

  public async getUnterueberschrift() {
    return this.unterueberschrift.innerText();
  }

  public async getButtonName() {
    // return this.button.getAttribute('ng-reflect-label');
    return this.buttonAblehnen.innerText();
  }

  public async clickButton() {
    await this.button.click();
  }

  public async getErfülltCount() {
    return await this.erfuelltItems.count();
  }

  public async getNichtErfülltCount() {
    return await this.nichtErfuelltItems.count();
  }

  public async getNichtErmittelbarCount() {
    return await this.nichtErmittelbarItems.count();
  }

  public async getNichtErfuelltIcon() {
    return this.page.locator('#error-alt drv-icon svg');
  }

  public async getNichtErfuelltText() {
    return await this.page.getByText('Nicht erfüllt', { exact: true }).innerText();
  }

  public async getNichtErmittelbarIcon() {
    return this.page.locator('#question-mark drv-icon svg');
  }

  public async getNichtErmittelbarText() {
    return await this.page.locator('summary').filter({ hasText: 'Nicht ermittelbar' }).innerText();
  }

  public async getErfülltIcon() {
    return this.page.locator('#bullet-check drv-icon svg');
  }

  public async getErfülltText() {
    return await this.page.getByText('Erfüllt', { exact: true }).innerText();
  }

  public async getRegel1() {
    return await this.regel1.innerText();
  }

  public async getRegelTip1() {
    return await this.buttonRegel1.innerText();
  }

  public async getRegel2() {
    return await this.regel2.innerText();
  }
  public async getRegel3() {
    return await this.regel3.innerText();
  }

  public async getVierteNichtErfuelltRegel() {
    return await this.nicht_erfuellt_regel03.innerText();
  }

  public async getRegel4() {
    return await this.regel4.innerText();
  }

  public async getRegel10() {
    return await this.regel10.innerText();
  }

  public async getErsteNichtErmittelbarRegel() {
    return await this.nicht_ermittelbar_regel01.innerText();
  }

  public async getRegel5() {
    return await this.regel5.innerText();
  }

  public async getRegel6() {
    return await this.regel6.innerText();
  }

  public async getRegel7() {
    return await this.regel7.innerText();
  }

  public async getRegel8() {
    return await this.regel8.innerText();
  }

  public async getRegel9() {
    return await this.regel9.innerText();
  }

  public async getBegründung1() {
    return await this.begründung1.innerText();
  }

  public async getBegründung2() {
    return await this.begründung2.innerText();
  }
  public async getBegründung3() {
    return await this.begründung3.innerText();
  }

  public async getNichtErfuelltBegründung04() {
    return await this.nicht_erfuellt_begruendung03.innerText();
  }

  public async getBegründung4() {
    return await this.begründung4.innerText();
  }

  public async getBegründung10() {
    return await this.begründung10.innerText();
  }

  public async getBegründung5() {
    return await this.begründung5.innerText();
  }

  public async getBegründung6() {
    return await this.begründung6.innerText();
  }

  public async getBegründung7() {
    return await this.begründung7.innerText();
  }
  public async getBegründung8() {
    return await this.begründung8.innerText();
  }

  public async getBegründung9() {
    return await this.begründung9.innerText();
  }

  public async isError() {
    return this.error.getAttribute('iconlabel');
  }

  public async getErrorText() {
    return await this.error.innerText();
  }

  public async openSidepanelNichtErfüllt(regel: string) {
    this.ändernNichtErfüllt = this.page.locator(`button[aria-label="${regel} ändern"]`);
    await this.ändernNichtErfüllt.click();
  }

  public async openSidepanelNichtErmittelbar(regel: string) {
    this.ändernNichtErmittelbar = this.page.locator(`button[aria-label="${regel} ändern"]`);
    await this.ändernNichtErmittelbar.click();
  }

  public async openSidepanelReset(regel: string) {
    switch (regel) {
      case 'Aktive Beschäftigung/Selbständigkeit':
        this.ändern = this.page.locator('#buttonNichtErfuellt0');
        break;
      case 'Staatsangehörigkeit':
        this.ändern = this.page.locator('#buttonNichtErfuellt0');
        break;
      case 'Laufendes Rechtsbehelfsverfahren':
        this.ändern = this.page.locator('#buttonNichtErfuellt0');
        break;
      case 'Antrag auf Altersrente':
        this.ändern = this.page.locator('#buttonNichtErfuellt1');
        break;
    }
    await this.ändern.click();
  }

  public async openSidepanelEdit(regel: string) {
    switch (regel) {
      case 'Aktive Beschäftigung/Selbständigkeit':
        this.ändern = this.page.locator('#buttonNichtErfuellt0');
        break;
      case 'Staatsangehörigkeit':
        this.ändern = this.page.locator('#buttonNichtErfuellt0');
        break;
      case 'Laufendes Rechtsbehelfsverfahren':
        this.ändern = this.page.locator('#buttonNichtErmittelbar0');
        break;
      case 'Antrag auf Altersrente':
        this.ändern = this.page.locator('#buttonNichtErfuellt1');
        break;
    }
    await this.ändern.click();
  }

  public async showErfuelltRegelListe() {
    await this.ausklappSymbol.getByRole('img').click();
  }

  public async openSidepanelDritteErfuelltRegel() {
    this.ändern = this.page.locator('#buttonErfuellt2');
    await this.ändern.click();
  }

  public async openSidepanelVierteNichtErfuelltRegel() {
    this.ändern = this.page.locator('#buttonNichtErfuellt3');
    await this.ändern.click();
  }

  public async openSidepanel(regel: string) {
    switch (regel) {
      case 'Antrag auf Altersrente':
        this.ändern = this.page.locator(`//*[@id="buttonNichtErfuellt1"]`);
        break;
      case 'Staatsangehörigkeit':
        this.ändern = this.page.locator(`//*[@id="buttonNichtErmittelbar0"]`);
        break;
      case 'Aktive Beschäftigung/Selbständigkeit':
        this.ändern = this.page.locator(`//*[@id="buttonNichtErmittelbar0"]`);
        break;
      case 'Altersteilzeit':
        this.ändern = this.page.locator(`//*[@id="buttonNichtErmittelbar0"]`);
        break;
      case 'Laufendes Rechtsbehelfsverfahren':
        this.ändern = this.page.locator(`//*[@id="buttonNichtErmittelbar1"]`);
        break;
      case 'Erfüllt: Antrag auf Altersrente':
        this.ändern = this.page.locator('//*[@id="buttonErfuellt1"]');
        break;
      case 'Nicht Erfüllt: Laufendes Rechtsbehelfsverfahren':
        this.ändern = this.page.locator('//*[@id="buttonNichtErfuellt2"]');
        break;
      case 'Nicht Erfüllt: Staatsangehörigkeit':
        this.ändern = this.page.locator('//*[@id="buttonNichtErfuellt0"]');
        break;
      case 'Nicht Erfüllt: Aktive Beschäftigung/Selbständigkeit':
        this.ändern = this.page.locator('//*[@id="buttonNichtErfuellt0"]');
        break;
      case 'Nicht Erfüllt: Altersteilzeit':
        this.ändern = this.page.locator('//*[@id="buttonNichtErfuellt0"]');
        break;
    }
    await this.ändern.click();
  }

  public async closeSidepanelNichtErfüllt() {
    await this.schliessen.click();
  }

  public async closeSidepanelNichtErmittelbar() {
    await this.schliessen.click();
  }

  public async isSite() {
    return this.ueberschrift.isVisible();
  }

  public async setRadioNichtErfülltCheck() {
    await this.radioNichtErfüllt.click();
  }

  public async setRadioErfülltCheck() {
    await this.radioErfüllt.click();
  }

  public async setBegruedung(begründung: string) {
    await this.begruendung.type(begründung);
  }

  public async save() {
    await this.speichern.click();
  }

  public async getRadioErfüllt() {
    return this.radioErfüllt.isVisible();
  }

  public async getRadioNichtErfüllt() {
    return this.radioNichtErfüllt.isVisible();
  }

  public async getRadioChecked(auswahl: string) {
    if (
      auswahl.includes('liegt ein begründeter Antrag auf Altersrente') ||
      auswahl.includes('einem für RV Fit relevanten Rechtsbehelfsverfahren')
    ) {
      return this.radioNichtErfülltChecked.isChecked();
    } else {
      return this.radioErfülltChecked.isChecked();
    }
  }

  public async getRadioErfülltText() {
    return this.radioErfüllt.innerText();
  }

  public async getPlaceholder() {
    return this.begruendung.getAttribute('placeholder');
  }

  public async getBegründung() {
    return this.begruendung.inputValue();
  }

  public async getInfomeldung() {
    return this.infomeldung.innerText();
  }

  public async clicktToggleTip() {
    await this.page.getByRole('button', { name: 'Hinweis' }).click();
  }

  public async getTipp() {
    const text = await this.page
      .locator(`#inputGroupId > div > div > drv-toggletip > span`)
      .textContent();

    return text?.replace('Schließen ', '').replace(/\n/g, '');
  }

  public async isChangeAendern(regel: string) {
    switch (regel) {
      case 'Antrag auf Altersrente':
        this.ändern = this.page.locator(`//*[@id="buttonErfuellt1"]`);
        break;
      case 'Laufendes Rechtsbehelfsverfahren':
        this.ändern = this.page.locator(`//*[@id="buttonNichtErfuellt0"]`);
        break;
      case 'Staatsangehörigkeit':
        this.ändern = this.page.locator(`//*[@id="buttonNichtErfuellt0"]`);
        break;
      case 'Aktive Beschäftigung/Selbständigkeit':
        this.ändern = this.page.locator(`//*[@id="buttonNichtErfuellt0"]`);
        break;
    }
    return this.ändern.isVisible();
  }

  public async getRadioNichtErfülltText() {
    // switch (auswahl) {
    //   case 'Nein, es liegt keine EU/EWR/Schweizer/Türkische Staatsangehörigkeit sowie eine andere Staatsangehörigkeit mit unbefristetem Aufenthaltstitel vor.':
    //     return this.radioErfüllt.innerText();
    //   case 'Nein, die Anspruchsvoraussetzung Aufenthalt außerhalb von Deutschland ist nicht erfüllt.':
    //     return this.radioErfüllt.innerText();
    //   case 'Nein, die Wartezeit ist nicht erfüllt.':
    //     return this.radioErfüllt.innerText();
    //   case 'Nein, es liegt keine aktive Beschäftigung/Selbstständigkeit vor.':
    //     return this.radioErfüllt.innerText();
    //   default:
    //     return this.radioNichtErfüllt.innerText();
    // }
    return this.radioNichtErfüllt.innerText();
  }

  public async getZeichen() {
    return this.anzahlZeichen.innerText();
  }

  public async getBegruendungLabel() {
    return this.begruendungLabel.textContent();
  }

  public async getSidepanelTitle() {
    return this.sidepanelTitle.innerText();
  }

  public async getFrage() {
    return this.frage.innerText();
  }

  public async getResetVisible() {
    return this.reset.isVisible();
  }

  public async clickReset() {
    await this.reset.click();
  }

  public async getgGeaenderteMeldung() {
    return await this.geaenderteMeldung.innerText();
  }

  public async getMaschinellesErgebnis() {
    return await this.maschinellesErgebnisNichtErfüllt.innerText();
  }

  public async getMaschinellesÄndern(maschÄndern: string) {
    if (maschÄndern.includes('nicht ermittelbar')) {
      return await this.maschinellesÄndernErmittelbar.innerText();
    } else {
      return await this.maschinellesÄndernNichtErfüllt.innerText();
    }
  }
  public async getMaschinellesÄndernStaats() {
    return await this.maschinellesÄndernErmittelbarStaat.innerText();
  }

  public async getFehler(error: string) {
    if (error.includes('Option')) {
      return await this.fehlerRadio.innerText();
    } else {
      return await this.fehler.innerText();
    }
  }

  public async isAlert(error: string) {
    if (error.includes('Option')) {
      return await this.alertRadio.getAttribute('type');
    } else {
      return await this.alert.getAttribute('type');
    }
  }

  public async getkeinNichtErfuellt() {
    return await this.page.textContent('#keineNichtErfuellt');
  }

  public async getkeinNichtErm() {
    return await this.page.textContent('#keineNichtErmittelbar');
  }

  public async getkeinErfuellt() {
    return this.page.locator('#tableErfuellt').getByRole('listitem').innerText();
  }

  public async openSidepanelStaat() {
    await this.openstaat.click();
  }

  public async clickOnSachverhaltAufklaeren() {
    await this.sachverhaltAufklaeren.click();
  }

  public async getRegelNichtErfuellt(regel: string) {
    return this.page.getByRole('heading', { name: regel, exact: true }).innerText();
  }

  public async getBegründungNichtErfuellt(begründung: string) {
    return this.page.getByText(begründung).innerText();
  }

  public async getNichtErfuelltReset(regel: string) {
    switch (regel) {
      case 'Antrag auf Altersrente':
        this.nichtErf = this.page.locator('#regelNichtErfuellt0');
        break;
      case 'Aktive Beschäftigung/Selbständigkeit':
        this.nichtErf = this.page.locator('#regelNichtErfuellt1');
        break;
      case 'Bezug einer Rente wegen Erwerbsminderung':
        this.nichtErf = this.page.locator('#regelNichtErfuellt2');
        break;
      case 'Abgeschlossene Rehabilitationsmaßnahme':
        this.nichtErf = this.page.locator('#regelNichtErfuellt3');
        break;
    }
    return await this.nichtErf.innerText();
  }

  public async getRegelErfuellt(regel: string) {
    return this.page.getByRole('heading', { name: regel }).innerText();
  }

  public async getBegründungErfuellt(begründung: string) {
    return this.page.getByText(begründung).innerText();
  }

  public async getRegelNichtErmittelbar(regel: string) {
    return this.page.getByRole('heading', { name: regel, exact: true }).innerText();
  }
  public async getBegründungNichtErmittelbar(begründung: string) {
    switch (begründung) {
      case 'Begründung: Es liegen keine vollstaendigen Daten vor':
        return this.page.locator('#begruendungNichtErmittelbar2').innerText();
      default:
        return this.page.getByText(begründung).innerText();
    }
  }
  public async openErfülltList() {
    this.erfülltList.click();
  }

  public async openNichtErfülltList() {
    this.nichtErfülltList.click();
  }

  public async openNichtErmittelbarList() {
    this.nichtErmittelbarList.click();
  }
  public async getListItemErfüllt() {
    return this.page.locator('#tableErfuellt').getByRole('listitem').innerText();
  }
  public async getListItemNichtErfüllt() {
    return this.page.locator('#tableNichtErfuellt').getByRole('listitem').innerText();
  }
  public async getListItemNichtErmittelbar() {
    return this.page.locator('#tableNichtErmittelbar').getByRole('listitem').innerText();
  }
  public async clickOnAntragBewilligen() {
    await this.antragBewilligen.click();
  }

  public async setUUID(uuid: string) {
    this.uuidWert = uuid;
  }

  public async getUUID() {
    return this.uuidWert;
  }

  public async istAntragBewilligt() {
    //await this.page?.waitForTimeout(2000);
    return await this.antragBewilligenErfolgreich.isVisible();
  }

  public async istAntragBewilligtTechFehler() {
    return await this.antragBewilligenTechFehler.isVisible();
  }

  public async clickOnAntragAblehnen() {
    await this.antragAblehnen.click();
  }

  public async clickOnAbsenden() {
    await this.absenden.click();
  }

  public async clickOnOK() {
    await this.documentabsendenok.scrollIntoViewIfNeeded({ timeout: 10000 });
    await this.documentabsendenok.click();
  }

  public async istantragAblehnenÜberschiftSichtbar() {
    return await this.antragAblehnenÜberschift.isVisible();
  }

  public async istantragAblehnenZwischenÜberschiftSichtbar() {
    return await this.antragAblehnenZwischenÜberschift.isVisible();
  }

  public async istAntragAblehnenBeschreibungSichtbar() {
    return await this.antragAblehnenBeschreibung.isVisible();
  }

  public async istAntragAbgelehntTechFehler() {
    return await this.antragAblehnenTechFehler.isVisible();
  }

  public async istIframeVisible() {
    return this.iframeAntragAblehnen.isVisible();
  }
}
