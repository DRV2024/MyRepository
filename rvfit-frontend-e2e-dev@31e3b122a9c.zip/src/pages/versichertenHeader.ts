import { Locator, Page } from '@playwright/test';

export class VersichertenHeader {
  readonly page: Page;
  readonly versicherterVSNR: Locator;
  readonly ueberschrift: Locator;
  readonly error: Locator;
  readonly errortext: Locator;

  constructor(page: Page) {
    this.page = page;
    this.versicherterVSNR = page.locator('#vsnr > b');
    this.ueberschrift = page.locator('#title');
    this.error = page.locator('#notification_header_error');
    this.errortext = page.locator('.drv-notification__text');
  }

  public async getVersicherterVSNR() {
    return await this.versicherterVSNR.innerText();
  }

  public async getUeberschrift() {
    return await this.ueberschrift.innerText();
  }

  public async getErrorTitle() {
    return await this.error.innerText();
  }

  public async getErrorText() {
    return await this.errortext.innerText();
  }

  public async getErrorNotification() {
    return await this.error.isVisible();
  }
}
