import { getFrontendUrl } from '../support/environments';
import { Locator, Page } from '@playwright/test';
import { readFileSync } from 'fs';
import { join } from 'path';

export class Antragaufnahme {
  readonly page: Page;
  readonly anmelden: Locator;
  readonly abmelden: Locator;
  readonly sideNavigation: Locator;
  readonly eingabefelder: Locator;
  readonly eingabefelderlabel: Locator;
  readonly checkboxfelderlabel: Locator;
  readonly vsnrTextFeld: Locator;
  readonly vsnrTextAnzeigefeld: Locator;
  readonly vsnrEingebenUeberschrift: Locator;
  readonly vsnrTextFeldInfo: Locator;
  readonly vsnrTextFeldLabel: Locator;
  readonly vsnrfehlerText: Locator;
  readonly vsnrFehlermeldung: Locator;
  readonly vsnrNavigationLeiste: Locator;
  readonly antrDatenEingNavigationLeiste: Locator;
  readonly abschlussNavigationLeiste: Locator;
  readonly antragsinformationen: Locator;
  readonly vorRehaEin: Locator;
  readonly angabenzurPerson: Locator;
  readonly dokumentenzugang: Locator;
  readonly weiter: Locator;
  readonly zurueck: Locator;
  readonly ueberschrift: Locator;
  readonly zwischenschrift: Locator;
  readonly eingangsdatumcheckbox: Locator;
  readonly eingangsdatumfeld: Locator;
  readonly antragsdatumfeld: Locator;
  readonly rehaEinR1feld: Locator;
  readonly rehaEinR2feld: Locator;
  readonly nachnamefeld: Locator;
  readonly nachnamefeldhinweis: Locator;
  readonly vornamefeld: Locator;
  readonly vornamefeldhinweis: Locator;
  readonly geburtsnamefeld: Locator;
  readonly geburtsnamefeldhinweis: Locator;
  readonly frueherenamenfeld: Locator;
  readonly frueherenamenfeldhinweis: Locator;
  readonly geburtsdatumfeld: Locator;
  readonly geburtsdatumfeldhinweis: Locator;
  readonly geschlechtfeld: Locator;
  readonly geschlechtfeldhinweis: Locator;
  readonly vorsatzwortfeld: Locator;
  readonly vorsatzwortfeldhinweis: Locator;
  readonly namenszusatzfeld: Locator;
  readonly namenszusatzfeldhinweis: Locator;
  readonly titelfeld: Locator;
  readonly titelfeldhinweis: Locator;
  readonly geburtsortfeld: Locator;
  readonly geburtsortfeldhinweis: Locator;
  readonly staatsangehoerigkeitfeld: Locator;
  readonly staatsangehoerigkeitleerfeld: Locator;
  readonly staatsangehoerigkeitfeldhinweis: Locator;
  readonly adressefeld: Locator;
  readonly adressefeldhinweis: Locator;
  readonly postleitzahlfeld: Locator;
  readonly postleitzahlfeldhinweis: Locator;
  readonly wohnortfeld: Locator;
  readonly wohnortfeldhinweis: Locator;
  readonly telefonnummerfeld: Locator;
  readonly telefonnummerfeldhinweis: Locator;
  readonly telefaxfeld: Locator;
  readonly telefaxfeldhinweis: Locator;
  readonly deMailCB: Locator;
  readonly deMailfeld: Locator;
  readonly deMailfeldhinweis: Locator;
  readonly großDruckCB: Locator;
  readonly inBrailleKurzCB: Locator;
  readonly inBrailleVollCB: Locator;
  readonly alsCDCB: Locator;
  readonly alsHoermediumCB: Locator;
  readonly eingangsdatumsfehlertext: Locator;
  readonly antragsdatumsfehlertext: Locator;
  readonly erfolgreichtext: Locator;
  readonly navigationsleiste: Locator;
  readonly anderevsnrmodal: Locator;
  readonly bemerkungen: Locator;
  readonly bemerkungenfeld: Locator;
  readonly bemerkungenUeberschrift: Locator;
  readonly bemerkungenLabel: Locator;
  readonly bemerkungenInfotext: Locator;
  readonly bemerkungenInfoLabel: Locator;
  readonly bemerkungenZaehler: Locator;
  readonly entwurfSpeichern: Locator;
  readonly antragVerarbeiten: Locator;
  readonly ueberschriftInfoTextGespeichert: Locator;
  readonly infoTextGespeichert: Locator;
  readonly ueberschriftinfoTextTechProblem: Locator;
  readonly infoTextTechProblem: Locator;
  readonly antragsDatenEingebenUeberschrift;
  readonly abbrechen: Locator;
  readonly fortfahren: Locator;
  readonly infoTextZwischengespeichert: Locator;
  readonly infoTextAntragVerarbeitet: Locator;
  readonly ueberschriftInfoTextAntragVerarbeitetFehler: Locator;
  readonly infoTextAntragVerarbeitetFehler: Locator;
  readonly ueberschriftInfoTextDateninkonsistenzFehler: Locator;
  readonly infoTextDateninkonsistenzFehler: Locator;
  readonly ueberschriftPersonenDatenHinweis: Locator;
  readonly textPersonenDatenHinweis: Locator;
  readonly zudenPersonendaten: Locator;
  readonly datenAktualisieren: Locator;
  readonly textPersonenDatenAktuellUeberschrift: Locator;
  readonly textPersonenDatenAktuellHinweis: Locator;
  readonly autocomplete1Ergebnis: Locator;
  readonly autocomplete2Ergebnis: Locator;

  constructor(page: Page) {
    this.page = page;

    this.navigationsleiste = page.locator('.drv-progress__subitem');

    this.anmelden = page.getByRole('button', { name: 'Anmelden' });
    this.abmelden = page.getByRole('button', { name: 'Abmelden' });

    this.sideNavigation = page.locator('nav[class="drv-navigation"]');

    this.vsnrNavigationLeiste = this.sideNavigation.locator('//drv-progressnavnode[1]');
    this.antrDatenEingNavigationLeiste = this.sideNavigation.locator('//drv-progressnavnode[2]');
    this.abschlussNavigationLeiste = this.sideNavigation.locator('//drv-progressnavnode[3]');

    this.antragsinformationen = this.sideNavigation.locator('//li[2]/ol/li[1]/span');
    this.vorRehaEin = page.locator('#formular-rehaeinrichtungen-header');
    this.angabenzurPerson = page.locator(
      '//*[@id="formular-person-header  drv-mb-lg--01 drv-mb-md--01"]',
    );
    // this.angabenzurPerson = page.locator('#formular-person-header  drv-mb-lg--01 drv-mb-md--01');
    this.dokumentenzugang = page.locator('#formular-dokumentenzugang-header');
    this.bemerkungen = this.sideNavigation.locator('//li[2]/ol/li[5]/span');
    // this.bemerkungenLabel = this.sideNavigation.locator('//nav/div/ol/li[2]/ol/li[5]/span');
    this.bemerkungenLabel = page.locator('label[for = "formular-bemerkungen-feld"]');
    this.vsnrEingebenUeberschrift = page.locator('#vsnr-header');
    this.vsnrTextFeldInfo = page.locator('#vsnr-subheader');
    this.vsnrTextFeldLabel = page.locator(
      '//*[@id="vsnr-component"]/div[3]/div/drv-textinput/drv-formitem/span/label',
    );
    this.vsnrTextFeld = page.locator('#vsnr-feld');
    this.vsnrTextAnzeigefeld = page.locator('#formular-vsnr-feld');
    this.vsnrFehlermeldung = page.locator('span[class="drv-field-message__text"]');
    this.weiter = page.locator('#buttonbar-button-forward');
    this.zurueck = page.locator('#buttonbar-button-back');
    this.antragVerarbeiten = page.locator('#buttonbar-button-submit');
    this.entwurfSpeichern = page.locator('#buttonbar-button-save');

    this.eingabefelder = page.locator(
      '.drv-text-input drv-text-input--light ng-untouched ng-pristine ng-valid',
    );
    this.eingabefelderlabel = page.locator('.drv-label');
    this.checkboxfelderlabel = page.locator('.drv-checkbox__label');
    this.vsnrTextFeld = page.locator('#vsnr-feld');
    this.vsnrfehlerText = page.locator('#vsnrFeld_errors');
    this.ueberschrift = page.locator('h1');
    this.zwischenschrift = page.locator('h2');

    this.eingangsdatumfeld = page.locator('#formular-eingangsdatum-feld');
    this.eingangsdatumsfehlertext = page.locator(
      '//*[@id="eingangsdatumFeld_errors"]/li/span/span',
    );
    this.eingangsdatumcheckbox = page.locator(
      '//*[@id="formular-form-component"]/form/div[3]/div/drv-checkbox/label',
    );
    this.antragsdatumfeld = page.locator('#formular-antragsdatum-feld');
    this.antragsdatumsfehlertext = page.locator('//*[@id="antragsdatumFeld_errors"]/li/span/span');
    this.rehaEinR1feld = page.locator('#formular-rehaeinrichtung1-feld');
    this.autocomplete1Ergebnis = page.locator('#formular-rehaeinrichtung1-suchergebnis');
    this.rehaEinR2feld = page.locator('#formular-rehaeinrichtung2-feld');
    this.autocomplete2Ergebnis = page.locator('#formular-rehaeinrichtung2-suchergebnis');
    this.vornamefeld = page.locator('#formular-vorname-feld');
    this.vornamefeldhinweis = page.locator('#formular-vorname-feld_errors');
    this.nachnamefeld = page.locator('#formular-name-feld');
    this.nachnamefeldhinweis = page.locator('#formular-name-feld_errors');
    this.geburtsnamefeld = page.locator('#formular-geburtsname-feld');
    this.geburtsnamefeldhinweis = page.locator('#formular-geburtsname-feld_errors');
    this.frueherenamenfeld = page.locator('#formular-frueherenamen-feld');
    this.frueherenamenfeldhinweis = page.locator('#formular-frueherenamen-feld_errors');
    this.geburtsdatumfeld = page.locator('#formular-geburtdatum-feld');
    this.geburtsdatumfeldhinweis = page.locator('#formular-geburtdatum-feld_errors');
    this.geschlechtfeld = page.locator('#formular-geschlecht-feld');
    this.geschlechtfeldhinweis = page.locator('#formular-geburtdatum-feld_errors');
    this.vorsatzwortfeld = page.locator('#formular-vorsatzwort-feld');
    this.vorsatzwortfeldhinweis = page.locator('#formular-vorsatzwort-feld_errors');
    this.namenszusatzfeld = page.locator('#formular-namenszusatz-feld');
    this.namenszusatzfeldhinweis = page.locator('#formular-namenszusatz-feld_errors');
    this.titelfeld = page.locator('#formular-titel-feld');
    this.titelfeldhinweis = page.locator('#formular-titel-feld_errors');
    this.geburtsortfeld = page.locator('#formular-geburtsort-feld');
    this.geburtsortfeldhinweis = page.locator('#formular-geburtsort-feld_errors');

    this.staatsangehoerigkeitfeld = page.locator('#formular-staatsangehoerigkeit-feld');
    this.staatsangehoerigkeitleerfeld = page.locator(
      'drv-dropdown-value_formular-staatsangehoerigkeit-feld-0',
    );
    this.staatsangehoerigkeitfeldhinweis = page.locator(
      '#formular-staatsangehoerigkeit-feld_errors',
    );
    this.adressefeld = page.locator('#formular-adresse-feld');
    this.adressefeldhinweis = page.locator('#formular-adresse-feld_errors');
    this.postleitzahlfeld = page.locator('#formular-plz-feld');
    this.postleitzahlfeldhinweis = page.locator('#formular-plz-feld_errors');
    this.wohnortfeld = page.locator('#formular-wohnort-feld');
    this.wohnortfeldhinweis = page.locator('#formular-wohnort-feld_errors');
    this.telefonnummerfeld = page.locator('#formular-telefon-feld');
    this.telefonnummerfeldhinweis = page.locator('#formular-telefon-feld_errors');
    this.telefaxfeld = page.locator('#formular-telefax-feld');
    this.telefaxfeldhinweis = page.locator('#formular-telefax-feld_errors');
    this.deMailCB = page.locator(
      '//*[@id="formular-form-component"]/form/div[18]/div[1]/div/drv-checkbox/label',
    );
    this.deMailfeld = page.locator('#formular-demail-feld');
    this.deMailfeldhinweis = page.locator('//*[@id="formular-demail-feld-errors"]/li/span/span');
    this.großDruckCB = page.getByLabel('als Großdruck');
    this.inBrailleKurzCB = page.getByLabel('in Braille (Kurzschrift)');
    this.inBrailleVollCB = page.getByLabel('in Braille (Vollschrift)');
    this.alsCDCB = page.getByLabel('als CD (Schriftdatei oder Textdatei im ".doc"- Format)');
    this.alsHoermediumCB = page.getByLabel('als Hörmedium (CD-DAISY Format)');

    this.erfolgreichtext = page.locator(
      '.drv-notification__item drv-notification__item--active drv-notification__item--success',
    );
    // this.anderevsnrmodal = page.locator('#modal-heading-changeVsnrSidepanel');
    this.anderevsnrmodal = page.locator('div[class="drv-modal__wrapper"]');
    this.bemerkungenUeberschrift = page.locator('#formular-bemerkungen-header');
    this.bemerkungenInfotext = page.locator('#tooltip_formular-bemerkungen-feld');
    this.bemerkungenInfoLabel = page.getByRole('button', { name: 'Hinweis' });
    this.antragsDatenEingebenUeberschrift = page.locator('#formular-form-title');
    this.bemerkungenfeld = page.locator('#formular-bemerkungen-feld');
    this.bemerkungenZaehler = page.locator('#formular-bemerkungen-feld_count');
    this.abbrechen = page.getByRole('button', { name: 'Abbrechen' });
    this.fortfahren = page.getByRole('button', { name: 'Fortfahren' });
    this.ueberschriftInfoTextGespeichert = page.locator(
      '#notification_header_entwurf-speichern-success',
    );
    this.infoTextGespeichert = page.locator(
      '//div[contains(text(),"Eingaben wurden erfolgreich zwischengespeichert")]',
    );
    this.ueberschriftinfoTextTechProblem = page.locator(
      '#notification_header_entwurf-speichern-error',
    );
    this.infoTextZwischengespeichert = page.locator('//*[@id="formular-status-entwurf"]/span');

    this.infoTextAntragVerarbeitet = page.locator(
      '//*[@id="antragaufnahme-abschluss"]/div/drv-statusscreen/div[2]',
    );
    this.ueberschriftInfoTextAntragVerarbeitetFehler = page.locator(
      '#notification_header_papierantrag-senden-error',
    );
    this.infoTextTechProblem = page.locator(
      '//div[contains(text(),"technischer Einschränkungen")]',
    );
    this.infoTextAntragVerarbeitetFehler = page.locator(
      '//div[contains(text(),"aufgrund eines technischen Problems")]',
    );
    this.ueberschriftInfoTextDateninkonsistenzFehler = page.locator(
      '#notification_header_papierantrag-senden-personendaten-abweichung-error',
    );
    this.infoTextDateninkonsistenzFehler = page.locator(
      '//div[contains(text(),"Eingabe stimmt nicht mit den Personendaten überein")]',
    );
    this.ueberschriftPersonenDatenHinweis = page.locator(
      '//header[contains(text(),"Prüfen Sie, ob die Angaben zur Person")]',
    );
    this.textPersonenDatenHinweis = page.locator(
      '//p[contains(text(),"Nehmen Sie erforderliche Anpassungen direkt in den Personendaten vor.")]',
    );
    this.zudenPersonendaten = page.locator('//span[contains(text(),"Zu den Personendaten")]');
    this.datenAktualisieren = page.locator('//span[contains(text(),"Daten aktualisieren")]');
    this.textPersonenDatenAktuellHinweis = page.locator(
      '//div[contains(text(),"Die Personendaten wurden erfolgreich abgefragt. Die angezeigten Daten sind bereits auf dem aktuellsten Stand.")]',
    );
    this.textPersonenDatenAktuellUeberschrift = page.locator(
      '#notification_header_personendaten-update-no-change',
    );
  }
  public async getInputValueOrNull(locator: Locator): Promise<string | null> {
    const value = await locator.inputValue();
    return value === '' ? null : value;
  }

  public async openAntragaufnahme() {
    await this.page?.goto(`${getFrontendUrl()}/antragaufnahme`);
  }

  public async clickAnmelden() {
    return await this.anmelden.click();
  }

  public async clickAbmelden() {
    return await this.abmelden.click();
  }

  public async istAnmeldenSichtbar() {
    return await this.anmelden.isVisible();
  }

  public async istAbmeldenSichtbar() {
    return await this.abmelden.isVisible();
  }

  public async getRehaEinR1feld() {
    return this.getInputValueOrNull(this.rehaEinR1feld);
  }

  public async setRehaEinR1feld(RehaEinR1: string) {
    await this.rehaEinR1feld.click();
    await this.rehaEinR1feld.clear();
    await this.rehaEinR1feld.type(RehaEinR1);
  }

  public async getVornameFeld() {
    return this.getInputValueOrNull(this.vornamefeld);
  }
  public async istVornameFeldAenderbar() {
    return await this.vornamefeld.isEditable();
  }
  public async setVornameFeld(vorname: string) {
    await this.vornamefeld.clear();
    await this.vornamefeld.type(vorname);
    await this.clickOnTab();
  }
  public async getVornameFeldLaenge() {
    return this.getInputValueOrNull(this.vornamefeld);
  }

  public async getVornameFeldHinweis() {
    return await this.vornamefeldhinweis.innerText();
  }
  public async istVornameFeldHinweisSichtbar() {
    return await this.vornamefeldhinweis.isVisible();
  }

  public async istAutocompleteErgebnis1Sichtbar() {
    return await this.autocomplete1Ergebnis.isVisible();
  }

  public async anzahlAutocompleteErgebnis() {
    const items = this.autocomplete1Ergebnis.locator('drv-itemlistitem > drv-iconlink');
    return (await items.count()).toString();
  }

  public async anzahlAutocompleteErgebnisZwei() {
    const items = this.autocomplete2Ergebnis.locator('drv-itemlistitem > drv-iconlink');
    return (await items.count()).toString();
  }

  public async istAutocompleteErgebnis2Sichtbar() {
    return await this.autocomplete2Ergebnis.isVisible();
  }

  public async getRehaEinR2feld() {
    return this.getInputValueOrNull(this.rehaEinR2feld);
  }

  public async setRehaEinR2feld(rehaEinR2feld: string) {
    await this.rehaEinR2feld.click();
    await this.rehaEinR2feld.clear();
    await this.rehaEinR2feld.type(rehaEinR2feld);
  }

  public async istNachnameFeldAenderbar() {
    return await this.nachnamefeld.isEditable();
  }

  public async getNachnameFeld() {
    return this.getInputValueOrNull(this.nachnamefeld);
  }

  public async setNachnameFeld(nachname: string) {
    await this.nachnamefeld.clear();
    await this.nachnamefeld.fill(nachname);
    await this.clickOnTab();
  }
  public async clearNachnameFeld() {
    await this.nachnamefeld.clear();
  }
  public async getNachnameFeldLaenge() {
    return (await this.nachnamefeld.inputValue()).length;
  }

  public async getNachnameFeldHinweis() {
    return await this.nachnamefeldhinweis.innerText();
  }
  public async istNachnameFeldHinweisSichtbar() {
    return await this.nachnamefeldhinweis.isVisible();
  }

  public async getGeburtsnameFeld() {
    return this.getInputValueOrNull(this.geburtsnamefeld);
  }

  public async istGeburtsnameFeldEditable() {
    return await this.geburtsnamefeld.isEditable();
  }

  public async getGeburtsnameFeldLaenge() {
    return (await this.geburtsnamefeld.inputValue()).length;
  }

  public async getGeburtsnameFeldHinweis() {
    return await this.geburtsnamefeldhinweis.innerText();
  }
  public async istGeburtsnameFeldHinweisSichtbar() {
    return await this.geburtsnamefeldhinweis.isVisible();
  }

  public async setGeburtsnameFeld(geburtsname: string) {
    await this.geburtsnamefeld.fill(geburtsname);
    await this.clickOnTab();
  }

  public async getFruehereNamenFeld() {
    return this.getInputValueOrNull(this.frueherenamenfeld);
  }

  public async istFruehereNamenAenderbar() {
    return await this.frueherenamenfeld.isEditable();
  }

  public async getFruehereNamenFeldLaenge() {
    return (await this.frueherenamenfeld.inputValue()).length;
  }

  public async getFruehereNamenFeldHinweis() {
    return await this.frueherenamenfeldhinweis.innerText();
  }
  public async istFruehereNamenFeldHinweisSichtbar() {
    return await this.frueherenamenfeldhinweis.isVisible();
  }

  public async setFruehereNamenFeld(frueherenamen: string) {
    await this.geburtsnamefeld.fill(frueherenamen);
    await this.clickOnTab();
  }

  public async getGeburtsdatumFeld() {
    return this.getInputValueOrNull(this.geburtsdatumfeld);
  }
  public async istGeburtsdatumEditable() {
    return await this.geburtsdatumfeld.isEditable();
  }

  public async istGeburtdatumAenderbar() {
    return await this.geburtsdatumfeld.isEditable();
  }

  public async setGeburtsdatumFeld(geburtsdatum: string) {
    await this.geburtsdatumfeld.clear();
    await this.geburtsdatumfeld.fill(geburtsdatum);
    await this.clickOnTab();
    await this.clickOnTab();
    await this.clickOnTab();
  }
  public async getGeburtsdatumFeldLaenge() {
    return (await this.geburtsdatumfeld.inputValue()).length;
  }

  public async getGeburtsdatumFeldHinweis() {
    return await this.geburtsdatumfeldhinweis.innerText();
  }
  public async istGeburtsdatumFeldHinweisSichtbar() {
    return await this.geburtsdatumfeldhinweis.isVisible();
  }

  public async getGeschlechtFeld() {
    return (await this.geschlechtfeld.inputValue()).toString().substring(3, 4);
  }

  public async getGeschlechtDropDown() {
    return await this.getDropDownValue(this.geschlechtfeld);
  }

  public async istGeschlechtAenderbar() {
    return await this.geschlechtfeld.isEditable();
  }

  public async getGeschlechtFeldLaenge() {
    return (await this.geschlechtfeld.inputValue()).length;
  }
  public async getGeschlechtFeldHinweis() {
    return await this.geschlechtfeldhinweis.innerText();
  }

  public async istGeschlechtFeldHinweisSichtbar() {
    return await this.geschlechtfeldhinweis.isVisible();
  }

  public async getVorsatzwortFeld() {
    return this.getInputValueOrNull(this.vorsatzwortfeld);
  }

  public async istVorsatzwortAenderbar() {
    return await this.vorsatzwortfeld.isEditable();
  }

  public async getVorsatzwortausgewaehlteValue() {
    return await this.vorsatzwortfeld.getByText('Vorsatzwort auswählen').getAttribute('value');
  }

  public async getVorsatzwortDropDown() {
    return await this.getDropDownValue(this.vorsatzwortfeld);
  }

  public async getVorsatzwortFeldLaenge() {
    return (await this.vorsatzwortfeld.inputValue()).length;
  }
  public async getVorsatzwortFeldHinweis() {
    return await this.vorsatzwortfeldhinweis.innerText();
  }

  public async istVorsatzwortFeldHinweisSichtbar() {
    return await this.vorsatzwortfeldhinweis.isVisible();
  }

  public async getNamenszusatzFeld() {
    return this.getInputValueOrNull(this.namenszusatzfeld);
  }

  public async istNamenszusatzAenderbar() {
    return await this.namenszusatzfeld.isEditable();
  }

  public async getNamenszusatzausgewaehlteValue() {
    return await this.namenszusatzfeld.getByText('Namenszusatz auswählen').getAttribute('value');
  }

  public async getNamenszusatzDropDown() {
    return await this.getDropDownValue(this.namenszusatzfeld);
  }

  public async getDropDownValue(loc: Locator) {
    const text = await loc.inputValue();
    return text.substring(text.indexOf(':') + 1).trim();
  }

  public async getNamenszusatzFeldLaenge() {
    return (await this.namenszusatzfeld.inputValue()).length;
  }

  public async getNamenszusatzFeldHinweis() {
    return await this.namenszusatzfeldhinweis.innerText();
  }
  public async istNamenszusatzFeldHinweisSichtbar() {
    return await this.namenszusatzfeldhinweis.isVisible();
  }

  public async getTitelFeld() {
    return this.getInputValueOrNull(this.titelfeld);
  }

  public async istTitelAenderbar() {
    return await this.titelfeld.isEditable();
  }
  public async setTitelfeld(titel: string) {
    await this.titelfeld.fill(titel);
    await this.clickOnTab();
  }
  public async getTitelfeldLaenge() {
    return (await this.titelfeld.inputValue()).length;
  }

  public async getTitelfeldHinweis() {
    return await this.titelfeldhinweis.innerText();
  }
  public async istTitelFeldHinweisSichtbar() {
    return await this.titelfeldhinweis.isVisible();
  }

  public async typeGeburtsortFeld(input: string) {
    await this.geburtsortfeld.type(input);
  }
  public async getGeburtsortFeld() {
    return this.getInputValueOrNull(this.geburtsortfeld);
  }

  public async istGeburtsortAenderbar() {
    return await this.geburtsortfeld.isEditable();
  }
  public async setGeburtsortFeld(geburtsort: string) {
    await this.geburtsortfeld.fill(geburtsort);
    await this.clickOnTab();
  }
  public async getGeburtsortFeldLaenge() {
    return (await this.geburtsortfeld.inputValue()).length;
  }

  public async getGeburtsortFeldHinweis() {
    return await this.geburtsortfeldhinweis.innerText();
  }
  public async istGeburtsortFeldHinweisSichtbar() {
    return await this.geburtsortfeldhinweis.isVisible();
  }

  public async getStaatsangehoerigkeitDropDown() {
    return await this.getDropDownValue(this.staatsangehoerigkeitfeld);
  }

  public async getStaatsangehoerigkeitFeld() {
    return (await this.staatsangehoerigkeitleerfeld.inputValue()).toString().substring(3, 7).trim();
  }

  public async istStaatsangehoerigAenderbar() {
    return await this.staatsangehoerigkeitfeld.isEditable();
  }
  public async getStaatsangehoerigkeitFeldLaenge() {
    return (await this.staatsangehoerigkeitfeld.inputValue()).length;
  }

  public async getStaatsangehoerigkeitFeldHinweis() {
    return await this.staatsangehoerigkeitfeldhinweis.innerText();
  }
  public async istStaatsangehoerigkeitFeldHinweisSichtbar() {
    return await this.staatsangehoerigkeitfeldhinweis.isVisible();
  }

  public async getTelefonnummerFeld() {
    return this.getInputValueOrNull(this.telefonnummerfeld);
  }
  public async istTelefonnummerAenderbar() {
    return await this.telefonnummerfeld.isEditable();
  }
  public async setTelefonnummerFeld(telefonnummer: string) {
    await this.telefonnummerfeld.fill(telefonnummer);
    await this.clickOnTab();
  }
  public async getTelefonnummerFeldLaenge() {
    return (await this.telefonnummerfeld.inputValue()).length;
  }

  public async getTelefonnummerFeldHinweis() {
    return await this.telefonnummerfeldhinweis.innerText();
  }
  public async istTelefonnummerFeldHinweisSichtbar() {
    return await this.telefonnummerfeldhinweis.isVisible();
  }

  public async getTelefaxFeld() {
    return this.getInputValueOrNull(this.telefaxfeld);
  }
  public async istTelefaxAenderbar() {
    return await this.telefaxfeld.isEditable();
  }

  public async setTelefaxFeld(telefax: string) {
    await this.telefaxfeld.fill(telefax);
    await this.clickOnTab();
  }
  public async getTelefaxFeldLaenge() {
    return (await this.telefaxfeld.inputValue()).length;
  }

  public async getTelefaxFeldHinweis() {
    return await this.telefaxfeldhinweis.innerText();
  }
  public async istTelefaxFeldHinweisSichtbar() {
    return await this.telefaxfeldhinweis.isVisible();
  }

  public async istDeMailCBAktiviert() {
    return await this.deMailCB.isChecked();
  }

  public async checkDeMailCB() {
    if ((await this.deMailCB.isChecked()) === false) {
      await this.deMailCB.evaluate((input: HTMLInputElement) => input.click());
    }
  }
  public async uncheckDeMailCB() {
    if ((await this.deMailCB.isChecked()) === true) {
      await this.deMailCB.evaluate((input: HTMLInputElement) => input.click());
    }
  }

  public async istGroßDruckCBAktiviert() {
    return await this.großDruckCB.isChecked();
  }

  public async checkGroßDruckCB() {
    if ((await this.großDruckCB.isChecked()) === false) {
      await this.großDruckCB.evaluate((input: HTMLInputElement) => input.click());
    }
  }

  public async uncheckGroßDruckCB() {
    if ((await this.großDruckCB.isChecked()) === true) {
      await this.großDruckCB.evaluate((input: HTMLInputElement) => input.click());
    }
  }

  public async getDeMailFeld() {
    return this.getInputValueOrNull(this.deMailfeld);
  }

  public async istDeMailFeldSichtbar() {
    return await this.deMailfeld.isVisible();
  }

  public async setdeMailFeld(demail: string) {
    await this.deMailfeld.fill(demail);
    await this.clickOnTab();
  }
  public async getDeMailFeldLaenge() {
    return (await this.deMailfeld.inputValue()).length;
  }

  public async getDeMailFeldHinweis() {
    return await this.deMailfeldhinweis.innerText();
  }
  public async istDeMailFeldHinweisSichtbar() {
    return await this.deMailfeldhinweis.isVisible();
  }

  public async istInBrailleKurzCBAktiviert() {
    return await this.inBrailleKurzCB.isChecked();
  }
  public async checkInBrailleKurzCB() {
    if ((await this.inBrailleKurzCB.isChecked()) === false) {
      await this.inBrailleKurzCB.evaluate((input: HTMLInputElement) => input.click());
    }
  }
  public async uncheckInBrailleKurzCB() {
    if ((await this.inBrailleKurzCB.isChecked()) === true) {
      await this.inBrailleKurzCB.evaluate((input: HTMLInputElement) => input.click());
    }
  }

  public async istInBrailleVollCBAktiviert() {
    return await this.inBrailleVollCB.isChecked();
  }
  public async checkInBrailleVollCB() {
    if ((await this.inBrailleVollCB.isChecked()) === false) {
      await this.inBrailleVollCB.evaluate((input: HTMLInputElement) => input.click());
    }
  }
  public async uncheckInBrailleVollCB() {
    if ((await this.inBrailleVollCB.isChecked()) === true) {
      await this.inBrailleVollCB.evaluate((input: HTMLInputElement) => input.click());
    }
  }

  public async istAlsCDCBAktiviert() {
    return await this.alsCDCB.isChecked();
  }
  public async checkAlsCDCB() {
    if ((await this.alsCDCB.isChecked()) === false) {
      await this.alsCDCB.evaluate((input: HTMLInputElement) => input.click());
    }
  }
  public async uncheckAlsCDCB() {
    if ((await this.alsCDCB.isChecked()) === true) {
      await this.alsCDCB.evaluate((input: HTMLInputElement) => input.click());
    }
  }

  public async istAlsHoermediumCBAktiviert() {
    return await this.alsHoermediumCB.isChecked();
  }
  public async checkAlsHoermediumCB() {
    if ((await this.alsHoermediumCB.isChecked()) === false) {
      await this.alsHoermediumCB.evaluate((input: HTMLInputElement) => input.click());
    }
  }
  public async uncheckAlsHoermediumCB() {
    if ((await this.alsHoermediumCB.isChecked()) === true) {
      await this.alsHoermediumCB.evaluate((input: HTMLInputElement) => input.click());
    }
  }

  public async clickvsnrNavigationLeiste() {
    return await this.vsnrNavigationLeiste.click();
  }

  public async clickOnAbschlussNavigationLeiste() {
    await this.abschlussNavigationLeiste.click();
  }

  public async istvsnrEingebenUeberschriftSichtbar() {
    return await this.vsnrEingebenUeberschrift.isVisible();
  }

  public async istvsnrTextFeldInfoSichtbar() {
    return await this.vsnrTextFeldInfo.isVisible();
  }

  public async istvsnrTextFeldLabelSichtbar() {
    return await this.vsnrTextFeldLabel.isVisible();
  }

  public async istvsnrTextFeldSichtbar() {
    return await this.vsnrTextFeld.isVisible();
  }

  public async loescheVersicherungsnummerTextFeld() {
    await this.vsnrTextFeld.clear();
  }

  public async eingabeVersicherungsnummerTextFeld(input: string) {
    await this.vsnrTextFeld.clear();
    await this.vsnrTextFeld.type(input);
  }

  public async getvsnrTextFeld() {
    return this.getInputValueOrNull(this.vsnrTextFeld);
  }

  public async istVersicherungsnummerEditable() {
    await this.vsnrTextAnzeigefeld.isEditable();
  }

  public async getvsnrTextAnzeigefeld() {
    return this.getInputValueOrNull(this.vsnrTextAnzeigefeld);
  }

  public async getvsnrFehlermeldung() {
    return await this.vsnrFehlermeldung.innerText();
  }

  public async clickOnWeiter() {
    await this.weiter.click();
  }

  public async clickOnZurueck() {
    await this.zurueck.click();
  }

  public istantragsinformationenSichtbar() {
    return this.antragsinformationen.isVisible();
  }

  public istvorRehaEinSichtbar() {
    return this.vorRehaEin.isVisible();
  }

  public istangabenzurPersonSichtbar() {
    return this.angabenzurPerson.isVisible();
  }

  public istdokumentenzugangSichtbar() {
    return this.dokumentenzugang.isVisible();
  }

  public istbemerkungenSichtbar() {
    return this.bemerkungen.isVisible();
  }

  public async getFehlerText() {
    return await this.vsnrfehlerText.innerText();
  }

  public async clickOnTab() {
    await this.page?.keyboard.press('Tab');
  }

  public async getUeberschriftText() {
    return await this.ueberschrift.innerText();
  }

  public async getAllZwischenschrifts() {
    return await this.zwischenschrift.allInnerTexts();
  }

  public async getAllZwischenschriftsCount() {
    return await this.zwischenschrift.count();
  }

  public async getEingabefelderText() {
    return await this.eingabefelderlabel.allInnerTexts();
  }

  public async getEingabefelderCount() {
    return await this.eingabefelderlabel.count();
  }

  public async getCheckBoxfelderText() {
    return await this.checkboxfelderlabel.allInnerTexts();
  }

  public async getCheckBoxfelderCount() {
    return await this.checkboxfelderlabel.count();
  }

  public async isVorsatzwortFeldEditable() {
    return await this.vorsatzwortfeld.isEditable();
  }

  public async isNamenszusatzFeldEditable() {
    return await this.namenszusatzfeld.isEditable();
  }
  public async istitelfeldEditable() {
    return await this.titelfeld.isEditable();
  }

  public async getEingabeFelderCount() {
    return await this.eingabefelder.count();
  }

  public async isCheckboxAktiviert() {
    return await this.eingangsdatumcheckbox.isChecked();
  }

  public async isAntragsDatumEditable() {
    return this.antragsdatumfeld.isDisabled();
  }

  public async getEingangsDatum() {
    return this.getInputValueOrNull(this.eingangsdatumfeld);
  }

  public async getAntragsDatum() {
    return this.getInputValueOrNull(this.antragsdatumfeld);
  }

  public async checkEingangsDatumCheckbox() {
    if ((await this.isCheckboxAktiviert()) === false) {
      await this.eingangsdatumcheckbox.evaluate((input: HTMLInputElement) => input.click());
    }
  }

  public async unCheckEingangsDatumCheckbox() {
    if ((await this.isCheckboxAktiviert()) === true) {
      await this.eingangsdatumcheckbox.evaluate((input: HTMLInputElement) => input.click());
    }
  }

  public async getEingangsDatumFormat() {
    return await this.eingangsdatumfeld.getAttribute('type');
  }

  public async getAntragsDatumFormat() {
    return await this.antragsdatumfeld.getAttribute('type');
  }

  public async typeEingangsDatum(input: string) {
    await this.eingangsdatumfeld.click();
    await this.eingangsdatumfeld.clear();
    await this.eingangsdatumfeld.type(input);
  }

  public async loescheEingangsDatum() {
    await this.eingangsdatumfeld.click();
    await this.eingangsdatumfeld.clear();
  }

  public async typeAntragsDatum(input: string) {
    await this.unCheckEingangsDatumCheckbox();
    await this.antragsdatumfeld.click();
    await this.antragsdatumfeld.clear();
    await this.antragsdatumfeld.type(input);
  }

  public async loescheAntragsDatum() {
    await this.antragsdatumfeld.click();
    await this.antragsdatumfeld.clear();
  }

  public async getEingangsDatumsFehlerText() {
    return await this.eingangsdatumsfehlertext.innerText();
  }

  public async getAntragsDatumsFehlerText() {
    return await this.antragsdatumsfehlertext.innerText();
  }

  public async istEntwurfSpeichernSichtbar() {
    await this.entwurfSpeichern.isVisible();
  }

  public async istEntwurfSpeichernAktiviert() {
    await this.entwurfSpeichern.isEnabled();
  }
  public async clickOnEntwurfSpeichern() {
    await this.entwurfSpeichern.click();
  }

  public async clickOnAntragVerarbeiten() {
    await this.antragVerarbeiten.click();
  }

  public async getErfolgreichtGespeichertText() {
    return await this.erfolgreichtext.innerText();
  }

  public async typeAdresseFeld(input: string) {
    await this.adressefeld.clear();
    await this.adressefeld.type(input);
  }
  public async getAdresseFeld() {
    return (await this.adressefeld.inputValue()).split('.')[0] + '.';
  }
  public async istAdresseAenderbar() {
    return await this.adressefeld.isEditable();
  }
  public async setAdresseFeld(adresse: string) {
    await this.adressefeld.fill(adresse);
    await this.clickOnTab();
  }
  public async getAdresseFeldLaenge() {
    return (await this.adressefeld.inputValue()).length;
  }

  public async getAdresseFeldHinweis() {
    return await this.adressefeldhinweis.innerText();
  }
  public async istAdresseFeldHinweisSichtbar() {
    return await this.adressefeldhinweis.isVisible();
  }

  public async getPostleitzahlFeld() {
    return this.getInputValueOrNull(this.postleitzahlfeld);
  }
  public async istPostleitzahlAenderbar() {
    return await this.postleitzahlfeld.isEditable();
  }
  public async setPostleitzahlFeld(postleitzahl: string) {
    await this.postleitzahlfeld.fill(postleitzahl);
    await this.clickOnTab();
  }
  public async getPostleitzahlFeldLaenge() {
    return (await this.postleitzahlfeld.inputValue()).length;
  }

  public async getPostleitzahlFeldHinweis() {
    return await this.postleitzahlfeldhinweis.innerText();
  }
  public async istPostleitzahlFeldHinweisSichtbar() {
    return await this.postleitzahlfeldhinweis.isVisible();
  }

  public async typePostleitzahlFeld(input: string) {
    await this.postleitzahlfeld.type(input);
  }

  public async typeWohnortFeld(input: string) {
    await this.wohnortfeld.type(input);
  }

  public async getWohnortFeld() {
    return this.getInputValueOrNull(this.wohnortfeld);
  }
  public async istWohnortAenderbar() {
    return await this.wohnortfeld.isEditable();
  }
  public async setWohnortFeld(wohnort: string) {
    await this.wohnortfeld.fill(wohnort);
    await this.clickOnTab();
  }
  public async getWohnortFeldLaenge() {
    return (await this.wohnortfeld.inputValue()).length;
  }

  public async getWohnortFeldHinweis() {
    return await this.wohnortfeldhinweis.innerText();
  }
  public async istWohnortFeldHinweisSichtbar() {
    return await this.wohnortfeldhinweis.isVisible();
  }

  public async getNavigationsleisteText() {
    return await this.navigationsleiste.allInnerTexts();
  }

  public async getNavigationsleisteCount() {
    return await this.navigationsleiste.count();
  }

  public async istAndereVsnrSidepanelSichtbar() {
    return await this.anderevsnrmodal.isVisible();
  }

  public async istBemerkungenFeldSichtbar() {
    return await this.bemerkungenfeld.isVisible();
  }

  public async clickOnBemerkungenFeld() {
    await this.bemerkungenfeld.click();
  }

  public async eingabeBemerkungenFeld(input: string) {
    await this.bemerkungenfeld.clear();
    await this.bemerkungenfeld.type(input);
  }

  public async eingabeBemerkungenFeldFuellen(laenge: string) {
    await this.bemerkungenfeld.clear();
    const bemString = new Array(parseInt(laenge) + 1).join('x');
    await this.bemerkungenfeld.fill(bemString);
  }

  public async eingabeBemerkungenFeldAnhaengen(input: string) {
    await this.bemerkungenfeld.type(input);
  }

  public async getBemerkungenFeld() {
    return await this.getInputValueOrNull(this.bemerkungenfeld);
  }

  public async loescheBemerkungenFeld() {
    return await this.bemerkungenfeld.clear();
  }

  public async getStringRechtsImBemerkungenFeld(anzahl: number) {
    const bemTextLength = (await this.bemerkungenfeld.inputValue()).length;
    return this.getInputValueOrNull(this.bemerkungenfeld)
      .toString()
      .substring(bemTextLength - anzahl, bemTextLength);
  }

  public async istBemerkungenZaehlerSichtbar() {
    return await this.bemerkungenZaehler.isVisible();
  }

  public async getBemerkungenZaehler() {
    return await this.bemerkungenZaehler.allInnerTexts();
  }

  public async istBemerkungenUeberschriftSichtbar() {
    return await this.bemerkungenUeberschrift.isVisible();
  }

  public async istBemerkungenLabelSichtbar() {
    return await this.bemerkungenLabel.isVisible();
  }

  public async istBemerkungenInfoLabelSichtbar() {
    return await this.bemerkungenInfoLabel.isVisible();
  }

  public async clickOnBemerkungenInfoLabel() {
    await this.bemerkungenInfoLabel.click();
  }

  public async getBemerkungenInfotext() {
    return await this.bemerkungenInfotext.textContent();
  }

  public async istBemerkungenInfotextSichtbar() {
    return await this.bemerkungenInfotext.isVisible();
  }

  public async getUeberschriftInfoTextGespeichert() {
    return await this.ueberschriftInfoTextGespeichert.textContent();
  }
  public async istUeberschriftInfoTextGespeichertSichtbar() {
    return await this.ueberschriftInfoTextGespeichert.isVisible();
  }

  public async getinfoTextAntragVerarbeitet() {
    return await this.infoTextAntragVerarbeitet.textContent();
  }
  public async istinfoTextAntragVerarbeitetSichtbar() {
    return await this.infoTextAntragVerarbeitet.isVisible();
  }

  public async getUeberschriftInfoTextAntragVerarbeitetFehler() {
    return await this.ueberschriftInfoTextAntragVerarbeitetFehler.textContent();
  }
  public async istUeberschriftInfoTextAntragVerarbeitetFehlerSichtbar() {
    return await this.ueberschriftInfoTextAntragVerarbeitetFehler.isVisible();
  }
  public async getUeberschriftInfoTextDateninkonsistenzFehler() {
    return await this.ueberschriftInfoTextDateninkonsistenzFehler.textContent();
  }
  public async istUeberschriftInfoTextDateninkonsistenzFehlerSichtbar() {
    return await this.ueberschriftInfoTextDateninkonsistenzFehler.isVisible();
  }

  public async getInfoTextGespeichert() {
    return await this.infoTextGespeichert.allInnerTexts();
  }

  public async getInfoTextDateninkonsistenzFehler() {
    return await this.infoTextDateninkonsistenzFehler.textContent();
  }

  public async getInfoTextAntragVerarbeitetFehler() {
    return await this.infoTextAntragVerarbeitetFehler.textContent();
  }

  public async istUeberschriftinfoTextTechProblemSichtbar() {
    return await this.ueberschriftinfoTextTechProblem.isVisible();
  }
  public async getUeberschriftinfoTextTechProblem() {
    return await this.ueberschriftinfoTextTechProblem.textContent();
  }
  public async getInfoTextTechProblem() {
    return await this.infoTextTechProblem.textContent();
  }

  public async clickAbbrechen() {
    await this.abbrechen.click();
  }
  public async clickfortfahren() {
    await this.fortfahren.click();
  }

  public async istAntragsDatenEingebenUeberschriftSichtbar() {
    return await this.antragsDatenEingebenUeberschrift.isVisible();
  }

  public async getInfoTextZwischengespeichert() {
    return await this.infoTextZwischengespeichert.innerText();
  }
  public async istUeberschriftPersonenDatenHinweisSichtbar() {
    return await this.ueberschriftPersonenDatenHinweis.isVisible();
  }
  public async getUeberschriftPersonenDatenHinweis() {
    return await this.ueberschriftPersonenDatenHinweis.textContent();
  }
  public async getTextPersonenDatenHinweis() {
    return await this.textPersonenDatenHinweis.textContent();
  }

  public async istZudenPersonendatenVerfuegbar() {
    return await this.zudenPersonendaten.isVisible();
  }

  public async istDatenAktualisierenVerfuegbar() {
    return await this.datenAktualisieren.isVisible();
  }

  public async clickDatenAktualisieren() {
    return await this.datenAktualisieren.click();
  }

  public async istTextPersonenDatenAktuellUeberschriftSichtbar() {
    return await this.textPersonenDatenAktuellUeberschrift.isVisible();
  }

  public async getTextPersonenDatenAktuellUeberschrift() {
    return await this.textPersonenDatenAktuellUeberschrift.textContent();
  }

  public async getTextPersonenDatenAktuellHinweis() {
    return await this.textPersonenDatenAktuellHinweis.textContent();
  }

  public async erzeugeNeuenEntwurf(vsnr: string) {
    const versicherter = this.getNeuerEntwurf(vsnr);
    await this.unCheckEingangsDatumCheckbox();
    await this.typeEingangsDatum(versicherter.eingangsdatum.toString());
    await this.typeAntragsDatum(versicherter.antragsdatum.toString());
    await this.setRehaEinR1feld(versicherter.einrichtungStartAuf.toString());
    await this.setRehaEinR2feld(versicherter.einrichtungTraining.toString());
    if (versicherter.deMailAdresse.toString().trim() === '') {
      await this.uncheckDeMailCB();
    } else {
      await this.checkDeMailCB();
      await this.setdeMailFeld(versicherter.deMailAdresse.toString());
    }
    if (parseInt(versicherter.grossdruck.toString()) === 1) {
      await this.checkGroßDruckCB();
    }
    if (parseInt(versicherter.kurzschrift.toString()) === 1) {
      await this.checkInBrailleKurzCB();
    }
    if (parseInt(versicherter.vollschrift.toString()) === 1) {
      await this.checkInBrailleVollCB();
    }
    if (parseInt(versicherter.cd.toString()) === 1) {
      await this.checkAlsCDCB();
    }
    if (parseInt(versicherter.hoermedium.toString()) === 1) {
      await this.checkAlsHoermediumCB();
    }
    await this.eingabeBemerkungenFeld(versicherter.bemerkungen.toString());
    await this.clickOnEntwurfSpeichern();
  }

  public getPersonendaten(vsnr: string) {
    const papierantragPersonendaten = readFileSync(
      join(__dirname, '../data/papierantrag_Personendaten.json'),
      'utf-8',
    );
    const vsnrDaten = JSON.parse(papierantragPersonendaten);
    let versicherter = {
      vsnr: String,
      vorname: String,
      nachname: String,
      geburtsdatum: String,
      geburtsort: String,
      strasse: String,
      plz: String,
      wohnort: String,
      vorsatzwort: String,
      namenszusatz: String,
      titel: String,
      geschlecht: String,
      geburtsname: String,
      fruehererName: String,
      telefon: String,
      telefax: String,
      staatsangehoerigkeit: String,
    };
    if (Array.isArray(vsnrDaten)) {
      versicherter = vsnrDaten.filter((eintrag) => eintrag.vsnr === vsnr)[0];
    }
    return versicherter;
  }

  public getEntwurfdaten(vsnr: string) {
    const papierantragEntwurfdaten = readFileSync(
      join(__dirname, '../data/papierantrag_Entwurfdaten.json'),
      'utf-8',
    );
    const vsnrDaten = JSON.parse(papierantragEntwurfdaten);
    let versicherter = {
      id: Number,
      antrag: {
        id: Number,
        guuid: String,
        vsnr: String,
        status: String,
        eingangsdatum: String,
        antragsart: String,
        strasse: String,
        hausnummer: String,
        plz: String,
        wohnort: String,
        land: String,
        vorname: String,
        nachname: String,
        fruehererName: String,
        geburtsdatum: String,
        geburtsname: String,
        geburtsort: String,
        geburtsland: String,
        geschlecht: String,
        vorsatzwort: String,
        namenszusatz: String,
        titel: String,
        staatsangehoerigkeit: String,
        einrichtungStartAuf: String,
        einrichtungTraining: String,
        telefon: String,
        fax: String,
        grossdruck: Boolean,
        kurzschrift: Boolean,
        vollschrift: Boolean,
        cd: Boolean,
        hoermedium: Boolean,
        antragsdatum: String,
        bemerkungen: String,
        deMailAdresse: String,
        versichertenStammdaten: [],
        kontoinformationen: [],
        pruefergebnisse: [],
      },
    };
    if (Array.isArray(vsnrDaten)) {
      versicherter = vsnrDaten.filter((eintrag) => eintrag.antrag.vsnr === vsnr)[0];
    }
    return versicherter;
  }

  public getNeuerEntwurf(vsnr: string) {
    const papierantragEntwurfdaten = readFileSync(
      join(__dirname, '../data/papierantrag_NeuerEntwurf.json'),
      'utf-8',
    );
    const vsnrDaten = JSON.parse(papierantragEntwurfdaten);
    let versicherter = {
      vsnr: String,
      eingangsdatum: String,
      strasse: String,
      hausnummer: String,
      plz: String,
      wohnort: String,
      land: String,
      vorname: String,
      nachname: String,
      fruehererName: String,
      geburtsdatum: String,
      geburtsname: String,
      geburtsort: String,
      geburtsland: String,
      geschlecht: String,
      vorsatzwort: String,
      namenszusatz: String,
      titel: String,
      staatsangehoerigkeit: String,
      einrichtungStartAuf: String,
      einrichtungTraining: String,
      telefon: String,
      fax: String,
      grossdruck: String,
      kurzschrift: String,
      vollschrift: String,
      cd: String,
      hoermedium: String,
      antragsdatum: String,
      bemerkungen: String,
      deMailAdresse: String,
    };
    if (Array.isArray(vsnrDaten)) {
      versicherter = vsnrDaten.filter(function (eintrag) {
        return eintrag.vsnr === vsnr;
      })[0];
    }
    return versicherter;
  }
}
