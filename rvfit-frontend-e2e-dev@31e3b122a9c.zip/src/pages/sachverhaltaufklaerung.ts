import { Download, Locator, Page } from '@playwright/test';

export class Sachverhaltsaufklaerung {
  readonly page: Page;
  readonly zwischenÜberschift: Locator;
  readonly untertitel: Locator;
  readonly sachverhaltsaufKlaerungErfolgsmeldung: Locator;
  readonly sachverhaltsaufKlaerungAbsenden: Locator;
  readonly sachverhaltsaufKlaerungOk: Locator;
  readonly sachverhaltsaufklaerungAbelehnenErfolgsmeldung: Locator;
  readonly angabenzumSachverhalt: Locator;
  readonly angabenzumSachverhaltTextfeld: Locator;
  readonly angabenzumSachverhaltUeberschrift: Locator;
  readonly paperboycomponent: Locator;
  readonly herunterladen: Locator;
  constructor(page: Page) {
    this.page = page;
    this.zwischenÜberschift = this.page.locator('#sachverhaltsaufklaerung-subtitle');
    this.untertitel = this.page.locator('#sachverhaltsaufklaerung-erklaerung');
    this.sachverhaltsaufKlaerungErfolgsmeldung = this.page.getByText(
      'Schreiben zur Aufklärung des Sachverhalts abgesendet',
    );
    this.sachverhaltsaufKlaerungAbsenden = page
      .frameLocator('#sachverhaltsaufklaerung-iframe')
      .getByRole('button', { name: 'Absenden' });
    this.sachverhaltsaufKlaerungOk = page
      .frameLocator('#sachverhaltsaufklaerung-iframe')
      .getByRole('button', { name: 'Ok' });
    this.sachverhaltsaufklaerungAbelehnenErfolgsmeldung = page.getByText(
      'Schreiben zur Aufklärung des Sachverhalts abgesendet',
    );
    this.paperboycomponent = this.page.locator(
      '//*[@id="sachverhaltsaufklaerung-main"]/div[2]/div/div/div/pb-doe',
    );
    this.angabenzumSachverhalt = this.paperboycomponent
      .frameLocator('iframe')
      .getByText('Angaben zum Sachverhalt');

    this.angabenzumSachverhaltTextfeld = this.paperboycomponent
      .frameLocator('iframe')
      .getByText('Bitte Text vorgeben *')
      .locator('../mat-form-field/div/div/div/textarea');
    this.angabenzumSachverhaltUeberschrift = this.paperboycomponent
      .frameLocator('iframe')
      .getByText('Bitte Überschrift vorgeben *')
      .locator('../mat-form-field/div/div/div/textarea');
    this.herunterladen = this.paperboycomponent
      .frameLocator('iframe')
      .getByRole('button', { name: 'Herunterladen' });
  }

  public async clickonsachverhaltsaufKlaerungOk() {
    await this.sachverhaltsaufKlaerungOk.click();
  }

  public async clickonsachverhaltsaufKlaerungAbsenden() {
    await this.sachverhaltsaufKlaerungAbsenden.click();
  }

  public async clickonAngabenzumSachverhalt() {
    await this.angabenzumSachverhalt.click();
  }

  public async typetextAngabenzumSachverhalt(text: string) {
    await this.angabenzumSachverhaltTextfeld.clear();
    await this.angabenzumSachverhaltTextfeld.type(text);
  }

  public async typetextAngabenzumSachverhaltUeberschriftfeld(text: string) {
    await this.angabenzumSachverhaltUeberschrift.clear();
    await this.angabenzumSachverhaltUeberschrift.type(text);
  }

  public async clickOnTabInIframe() {
    await this.page?.keyboard.press('Tab');
  }
  public async clickOnHerunterladen() {
    await this.herunterladen.click();
  }

  public async isdownloaded() {
    this.page.waitForEvent('download');
    await this.page.waitForTimeout(3000);
    await this.herunterladen.click();
    await this.page.waitForTimeout(3000);
    const download: Download = await this.page.waitForEvent('download');

    if (download.suggestedFilename() !== '') {
      console.log('Download path ', download.path());
      return true;
    } else {
      console.log('Download failed ');
      return false;
    }
  }
}
