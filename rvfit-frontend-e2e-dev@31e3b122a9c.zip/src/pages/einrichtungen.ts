import { getFrontendUrl } from '../support/environments';
import { Locator, Page } from '@playwright/test';

export class Einrichtungen {
  readonly page: Page;
  //Buttons
  private readonly aendernButtonStartphase: Locator;
  private readonly aendernButtonTraingsphase: Locator;
  private readonly einrichtungAuswaehlenButtonStartphase: Locator;
  private readonly einrichtungAuswaehlenTraingsphase: Locator;
  private readonly sachverhalt: Locator;
  private readonly bescheid: Locator;
  private readonly bescheidAnsicht: Locator;
  private readonly sachverhaltAnsicht: Locator;
  //Informationsspalte
  private readonly information: Locator;
  private readonly antragsart: Locator;
  private readonly datum: Locator;
  private readonly bemerkung: Locator;
  private readonly phase13: Locator;
  private readonly phase2: Locator;
  private grund!: Locator;
  //Einrichtungsspalte
  private readonly einrichtungenAuswählenText: Locator;
  private readonly einrichtungenAllePhasenText: Locator;
  private readonly einrichtungStartphase: Locator;
  private readonly einrichtungTrainingsphase: Locator;
  private readonly einrichtungAuffrischungsphase: Locator;
  private readonly einrichtungStartphaseAdresse: Locator;
  private readonly einrichtungStartphaseAmbulanteText: Locator;
  private readonly einrichtungStartphasefreiePlätze: Locator;
  private readonly einrichtungTrainingphaseAdresse: Locator;
  private readonly einrichtungTrainingphaseAmbulanteText: Locator;
  private readonly einrichtungTrainingphasefreiePlätze: Locator;
  private readonly einrichtungAuffrischungsAdresse: Locator;
  private readonly einrichtungAuffrischungsAmbulanteText: Locator;
  private readonly einrichtungAuffrischungfreiePlätze: Locator;
  private readonly einrichtungStartphaseUhrSymbol: Locator;
  private readonly einrichtungStartphaseStandortSymbol: Locator;
  private readonly einrichtungTrainingphaseUhrSymbol: Locator;
  private readonly einrichtungTrainingStandortSymbol: Locator;
  private readonly einrichtungAuffrischungsphaseUhrSymbol: Locator;
  private readonly einrichtungAuffrischungsphaseStandortSymbol: Locator;
  private readonly hinweisStartphase: Locator;
  private readonly hinweisTrainingsphase: Locator;
  private readonly hinweisAuffrischungsphase: Locator;
  //Locators zu testen mit Auto-retrying assertions
  readonly einrichtungStartphasefehlendeAuswahlText: Locator;
  readonly einrichtungTrainingphasefehlendeAuswahlText: Locator;
  //Sidepanel
  private readonly schliessenStart: Locator;
  private readonly schliessenTraining: Locator;
  private readonly plzStartphase: Locator;
  private readonly plzTraingsphase: Locator;
  private readonly ergebnisStartphase: Locator;
  private readonly ergebnisTrainingsphase: Locator;
  private readonly onlineTrainingsphase: Locator;
  private readonly ergebnisStartphaseListe: Locator;
  private readonly ergebnisTrainingsphaseListe: Locator;
  private readonly umkreisStartphase: Locator;
  private readonly umkreisTraingsphase: Locator;
  private readonly sucheStartphase: Locator;
  private readonly sucheTraingsphase: Locator;
  private auswahlStart!: Locator;
  private auswahlTraining!: Locator;
  private readonly uebernehmenStart: Locator;
  private readonly uebernehmenTraining: Locator;
  private readonly sidepanelStartEinrichtung: Locator;
  private readonly sidePanelTrainingEinrichtung: Locator;
  private readonly sidePanelStartAdresse: Locator;
  private readonly sidePanelTrainingAdresse: Locator;
  private readonly sidePanelStartPhase: Locator;
  private readonly sidePanelTrainingPhase: Locator;
  private readonly sidePanelStartDauer: Locator;
  private readonly sidePanelStartDauerDrop: Locator;
  private readonly sidePanelTrainingDauer: Locator;
  private readonly sidePanelStartPlatz: Locator;
  private readonly sidePanelTrainingPlatz: Locator;
  private readonly sidePanelStartHinweis: Locator;
  private readonly sidePanelTrainingHinweis: Locator;
  private readonly antragBewilligen: Locator;
  private readonly antragBewilligenErfolgreich: Locator;
  private readonly antragBewilligenTechFehler: Locator;
  private readonly sachverhaltAufklaeren: Locator;
  private readonly startPhaseBtn: Locator;

  private uuid?: string;

  constructor(page: Page) {
    this.page = page;
    //Buttons
    this.aendernButtonStartphase = page.locator('#buttonStartphase[label=Ändern]');
    this.aendernButtonTraingsphase = page.locator('#buttonTrainingsphase[label=Ändern]');
    this.einrichtungAuswaehlenButtonStartphase = page.locator(
      '#buttonStartphase[label="Einrichtung auswählen"]',
    );
    this.einrichtungAuswaehlenTraingsphase = page.locator(
      '#buttonTrainingsphase[label="Einrichtung auswählen"]',
    );

    this.sachverhalt = page.locator('#sachverhalt');
    this.bescheid = page.locator('#bescheid');
    this.bescheidAnsicht = page.locator('');
    this.sachverhaltAnsicht = page.locator('');
    //Informationsspalte
    this.information = page.locator('#info');
    this.antragsart = page.locator('#antragsart');
    this.datum = page.locator('#eingansdatum');
    this.bemerkung = page.locator('#freitext');
    this.phase13 = page.locator('#einrichtung-start-auf');
    this.phase2 = page.locator('#einrichtung-training');
    //Einrichtungsspalte
    this.einrichtungenAuswählenText = page.locator('#einrichungsauswahl');
    this.einrichtungenAllePhasenText = page.locator('#einrichtungsinfo');
    this.einrichtungStartphase = page.locator('#titleStartphase');
    this.einrichtungTrainingsphase = page.locator('#titleTrainingsphase');
    this.einrichtungAuffrischungsphase = page.locator('#titleAuffrischungsphase');
    this.einrichtungStartphaseAdresse = page.locator('#einrichtung0 > p > span');
    this.einrichtungStartphaseAmbulanteText = page.locator('#durchfuehrungsart0 > p > span');
    this.einrichtungStartphasefreiePlätze = page.locator('#freiePlaetze0');
    this.einrichtungStartphaseStandortSymbol = page.locator('#einrichtung0 > p > drv-icon');
    this.einrichtungStartphaseUhrSymbol = page.locator('#durchfuehrungsart0 > p > drv-icon');
    this.einrichtungStartphasefehlendeAuswahlText = page.locator(
      '#fehlerMeldungNotExistStartphase > p > span',
    );
    this.einrichtungTrainingphasefehlendeAuswahlText = page.locator(
      '#fehlerMeldungNotExistTrainingsphase > p > span',
    );

    this.einrichtungTrainingphaseAdresse = page.locator('#einrichtung1 > p > span');
    this.einrichtungTrainingphaseAmbulanteText = page.locator('#durchfuehrungsart1 > p > span');
    this.einrichtungTrainingphasefreiePlätze = page.locator('#freiePlaetze1');
    this.einrichtungTrainingStandortSymbol = page.locator('#durchfuehrungsart1 > p > drv-icon');
    this.einrichtungTrainingphaseUhrSymbol = page.locator('#einrichtung1 > p > drv-icon');
    this.einrichtungAuffrischungsAdresse = page.locator('#einrichtung2 > p > span');
    this.einrichtungAuffrischungsAmbulanteText = page.locator('#durchfuehrungsart2 > p > span');
    this.einrichtungAuffrischungfreiePlätze = page.locator('#freiePlaetze2');
    this.einrichtungAuffrischungsphaseStandortSymbol = page.locator('#einrichtung2 > p > drv-icon');
    this.einrichtungAuffrischungsphaseUhrSymbol = page.locator(
      '#durchfuehrungsart2 > p > drv-icon',
    );
    this.hinweisStartphase = page.locator(
      '#main > div:nth-child(3) > div > div.drv-col-sm-12.drv-col-md-12.drv-col-lg-8 > app-einrichtungsliste > div:nth-child(4) > div > div > app-einrichtungsitem > div > div.drv-col-sm-12.drv-col-md-12.drv-col-lg-9.drv--no-padding > div > drv-icontext > p > span',
    );
    this.hinweisTrainingsphase = page.locator(
      '#main > div:nth-child(3) > div > div.drv-col-sm-12.drv-col-md-12.drv-col-lg-8 > app-einrichtungsliste > div:nth-child(5) > div > div > app-einrichtungsitem > div > div.drv-col-sm-12.drv-col-md-12.drv-col-lg-9.drv--no-padding > div > drv-icontext > p > span',
    );
    this.hinweisAuffrischungsphase = page.locator(
      '#main > div:nth-child(3) > div > div.drv-col-sm-12.drv-col-md-12.drv-col-lg-8 > app-einrichtungsliste > div:nth-child(6) > div > div > app-einrichtungsitem > div > div.drv-col-sm-12.drv-col-md-12.drv-col-lg-9.drv--no-padding > div > drv-icontext > p > span',
    );
    //Sidepanel
    this.schliessenStart = page.locator(
      '#sidepanelStartphase > div.drv-sidepanel__wrapper > div.drv-sidepanel__header > drv-button > button',
    );
    this.schliessenTraining = page.locator(
      '#sidepanelTrainingsphase > div.drv-sidepanel__wrapper > div.drv-sidepanel__header > drv-button > button',
    );
    this.plzStartphase = page.locator('#suche0');
    this.plzTraingsphase = page.locator('#suche1');
    this.ergebnisStartphase = page.locator('#suche0-errors');
    this.ergebnisTrainingsphase = page.locator('#suche1-errors');
    this.onlineTrainingsphase = page.locator('#Trainingsphase0-entfernungMeldung');
    this.ergebnisStartphaseListe = page.locator(
      '#sidepanelStartphase > div > drv-sidepanel-content > div > app-einrichtungsauswahl > div > drv-inputgroup > div',
    );
    this.ergebnisTrainingsphaseListe = page.locator(
      '#sidepanelTrainingsphase > div > drv-sidepanel-content > div > app-einrichtungsauswahl > div > drv-inputgroup > div',
    );
    this.umkreisStartphase = page.locator('');
    this.umkreisTraingsphase = page.locator('');
    this.sucheStartphase = page.locator(
      '#sidepanelStartphase > div > drv-sidepanel-content > div > app-einrichtungsauswahl > div > drv-searchbar > drv-formitem > div > drv-button > button',
    );
    this.sucheTraingsphase = page.locator(
      '#sidepanelTrainingsphase > div > drv-sidepanel-content > div > app-einrichtungsauswahl > div > drv-searchbar > drv-formitem > div > drv-button > button',
    );
    this.sidePanelStartAdresse = page.locator('#Startphase0-adresse');
    this.sidePanelTrainingAdresse = page.locator('#Trainingsphase0-adresse');
    this.sidePanelStartPhase = page.locator('#Startphase0-angebotenePhase');
    this.sidePanelTrainingPhase = page.locator('#Trainingsphase0-angebotenePhase');
    this.sidePanelStartDauer = page.locator('#Startphase0-durchfuehrungsart');
    this.sidePanelStartDauerDrop = page.locator('#drv-dropdown-btn_Startphase0-dropdownArten');
    this.sidePanelTrainingDauer = page.locator('#Trainingsphase0-durchfuehrungsart');
    this.sidePanelStartPlatz = page.locator('#Startphase0-freieplaetze');
    this.sidePanelTrainingPlatz = page.locator('#Trainingsphase0-freieplaetze');
    this.uebernehmenStart = page.locator(
      '#sidepanelStartphase > div.drv-sidepanel__wrapper > drv-sidepanel-actions > drv-buttonbar > drv-button > button',
    );
    this.uebernehmenTraining = page.locator(
      '#sidepanelTrainingsphase > div.drv-sidepanel__wrapper > drv-sidepanel-actions > drv-buttonbar > drv-button > button',
    );
    this.sidepanelStartEinrichtung = page.locator('#Startphase0-name');
    this.sidePanelTrainingEinrichtung = page.locator('#Trainingsphase0-name');
    this.sidePanelStartHinweis = page.locator(
      // eslint-disable-next-line prettier/prettier
      '#sidepanelStartphase > div.drv-sidepanel__wrapper > drv-sidepanel-actions > div > p',
    );
    this.sidePanelTrainingHinweis = page.locator(
      '#sidepanelTrainingsphase > div.drv-sidepanel__wrapper > drv-sidepanel-actions > div > p',
    );
    this.antragBewilligen = page.getByRole('button', { name: 'Antrag bewilligen' });
    this.antragBewilligenErfolgreich = page.getByText('Antrag bewilligt', { exact: true });
    this.antragBewilligenTechFehler = page.locator('#notification_header_bewilligung-error');
    this.sachverhaltAufklaeren = page.locator('#buttonSachverhalt');
    this.startPhaseBtn = page.getByRole('button', { name: 'Als Startphase übernehmen' });
  }

  public async openEinrichtungen(uuid: string) {
    await this.page?.goto(`${getFrontendUrl()}/antrag/${uuid}/einrichtungen`);
  }

  public async wait() {
    await this.page?.waitForTimeout(2000);
  }

  public async setUUID(uuid: string) {
    this.uuid = uuid;
  }

  public async getUUID() {
    return this.uuid;
  }

  public async checkSeite() {
    return this.page.url();
  }

  public async bescheidNichtAktiv() {
    await this.bescheid.isDisabled();
  }

  public async bescheidAktiv() {
    await this.bescheid.isEnabled();
  }

  public async getHinweisAuswahlStart() {
    return this.hinweisStartphase.innerText();
  }

  public async getHinweisAuswahltraining() {
    return this.hinweisTrainingsphase.innerText();
  }

  public async getHinweisAuswahlAuffrischung() {
    return this.hinweisAuffrischungsphase.innerText();
  }

  public async buttonAuswahlStart() {
    return this.einrichtungAuswaehlenButtonStartphase.getAttribute('label');
  }

  public async buttonAuswahlTraining() {
    return this.einrichtungAuswaehlenTraingsphase.getAttribute('label');
  }

  public async visibleSachverhalt() {
    await this.sachverhalt.isVisible();
  }

  public async einrichtungAendernStart() {
    await this.aendernButtonStartphase.click();
  }

  public async einrichtungAendernTraining() {
    await this.aendernButtonTraingsphase.click();
  }

  public async einrichtungAuswaehlenStart() {
    await this.einrichtungAuswaehlenButtonStartphase.click();
  }

  public async einrichtungAuswaehlenTraining() {
    await this.einrichtungAuswaehlenTraingsphase.click();
  }

  public async isSidepanel() {
    await this.sucheStartphase.isVisible();
  }

  public async isSidepanelTraining() {
    await this.sucheTraingsphase.isVisible();
  }

  public async isSite() {
    await this.einrichtungenAuswählenText.isVisible();
  }

  public async sidePanelSearchEnter() {
    await this.page.keyboard.press('Enter');
  }

  public async deletePostleitzahlStart() {
    await this.plzStartphase.clear();
  }

  public async setSuchbegriffStart(input: string) {
    await this.plzStartphase.type(input);
  }

  public async getSidepanelStartPostleitzahl() {
    return this.plzStartphase.inputValue();
  }

  public async getSidepanelStartPlaceholder() {
    return this.plzStartphase.getAttribute('placeholder');
  }

  public async getSidepanelStartErgebnisse() {
    return this.ergebnisStartphase.innerText();
  }

  public async getSidepanelStartErgebnisseListe() {
    const list_elements = this.ergebnisStartphaseListe.locator('[type="radio"]');
    return (await list_elements.count()).toString();
  }

  public async setUmkreisStart(input: string) {
    await this.umkreisStartphase.type(input);
  }

  public async sidePanelSearchStart() {
    await this.sucheStartphase.click();
  }

  public async getSidepanelStartEinrichtung() {
    return this.sidepanelStartEinrichtung.innerHTML();
  }

  public async getSidepanelStartAdresse() {
    return this.sidePanelStartAdresse.innerText();
  }

  public async getSidepanelStartPhase() {
    return this.sidePanelStartPhase.innerText();
  }
  public async sidePanelAuswahlDurchfuehrungsartStart() {
    await this.sidePanelStartDauerDrop.click();
    await this.page
      .getByRole('option', { name: '3 Tage ganztägig ambulant' })
      .locator('span')
      .click();
  }

  public async getSidepanelStartDauer() {
    return this.sidePanelStartDauer.innerText();
  }

  public async getSidepanelStartDauerDrop() {
    return this.sidePanelStartDauerDrop.innerText();
  }

  public async getSidepanelStartPlatz() {
    return this.sidePanelStartPlatz.innerText();
  }

  public async getHinweisEinrichtung() {
    return this.sidePanelStartHinweis.innerText();
  }

  public async sidePanelAuswahlStart(einrichtung: string) {
    switch (einrichtung) {
      case 'Rehamed':
        await this.page
          .getByLabel('Einrichtung für Start- und Auffrischungsphase ändern')
          .getByText('Rehamed', { exact: true })
          .setChecked(true);
        break;
      case 'ZAR Wilhelmsplatz':
        await this.page
          .getByLabel('Einrichtung für Start- und Auffrischungsphase ändern')
          .getByText('ZAR Wilhelmsplatz', { exact: true })
          .setChecked(true);
        break;
    }
  }

  public async sidePanelUebernehmenStart() {
    await this.uebernehmenStart.click();
  }

  public async sidePanelUebernehmenTraining() {
    await this.uebernehmenTraining.click();
  }

  public async sidePanelDisabledUebernehmenStart() {
    return await this.uebernehmenStart.isDisabled();
  }

  public async sidePanelDisabledUebernehmenTraining() {
    return await this.uebernehmenTraining.isDisabled();
  }

  public async sidePanelAusgewaehltStart(einrichtung: string) {
    let phaseIndex;
    switch (einrichtung) {
      case 'Rehamed':
        phaseIndex = 0;
        break;
      case 'ZAR Wilhelmsplatz':
        phaseIndex = 1;
        break;
    }
    this.auswahlStart = this.page.locator(`//*[@id="radioButtonStartphase${phaseIndex}"]`);
    return this.auswahlStart.isChecked();
  }

  public async deletePostleitzahlTraining() {
    await this.plzTraingsphase.clear();
  }

  public async setSuchbegriffTraining(input: string) {
    await this.plzTraingsphase.type(input);
  }

  public async getSidepanelTrainingPostleitzahl() {
    return this.plzTraingsphase.inputValue();
  }

  public async getSidepanelTrainingPlaceholder() {
    return this.plzTraingsphase.getAttribute('placeholder');
  }

  public async getSidepanelTrainingOnlineAngebot() {
    return this.onlineTrainingsphase.innerText();
  }

  public async getSidepanelTrainingErgebnisse() {
    return this.ergebnisTrainingsphase.innerText();
  }

  public async getSidepanelTrainingErgebnisseListe() {
    const list_elements = this.ergebnisTrainingsphaseListe.locator('[type="radio"]');
    return (await list_elements.count()).toString();
  }

  public async setUmkreisTraining(input: string) {
    await this.umkreisTraingsphase.type(input);
  }

  public async sidePanelSearchTraining() {
    await this.sucheTraingsphase.click();
  }

  public async getSidepanelTrainingEinrichtung() {
    return this.sidePanelTrainingEinrichtung.innerHTML();
  }

  public async getSidepanelTrainingAdresse() {
    return this.sidePanelTrainingAdresse.innerText();
  }

  public async getSidepanelTrainingPhase() {
    return this.sidePanelTrainingPhase.innerText();
  }

  public async getSidepanelTrainingDauer() {
    return this.sidePanelTrainingDauer.innerText();
  }

  public async getSidepanelTrainingPlatz() {
    return this.sidePanelTrainingPlatz.innerText();
  }

  public async getHinweisTrainingEinrichtung() {
    return this.sidePanelTrainingHinweis.innerText();
  }

  public async sidePanelAuswahlTraining(einrichtung: string) {
    switch (einrichtung) {
      case 'Rehamed':
        await this.page
          .getByLabel('Einrichtung für Trainingsphase ändern')
          .locator('div')
          .filter({ hasText: /^Rehamed$/ })
          .first()
          .setChecked(true);
        break;
      case 'Testklinik_DF':
        await this.page
          .getByLabel('Einrichtung für Trainingsphase ändern')
          .locator('div')
          .filter({ hasText: /^Testklinik_DF$/ })
          .first()
          .setChecked(true);
        break;
      case 'ZAR Wilhelmsplatz':
        await this.page
          .getByLabel('Einrichtung für Trainingsphase ändern')
          .locator('div')
          .filter({ hasText: /^ZAR Wilhelmsplatz$/ })
          .first()
          .setChecked(true);
        break;
    }
  }

  public async sidePanelAusgewaehltTraining(einrichtung: string) {
    let phaseIndex;
    switch (einrichtung) {
      case 'Testklinik_DF':
        phaseIndex = 0;
        break;
      case 'Rehamed':
        phaseIndex = 1;
        break;
      case 'ZAR Wilhelmsplatz':
        phaseIndex = 3;
        break;
    }
    this.auswahlTraining = this.page.locator(`//*[@id="radioButtonTrainingsphase${phaseIndex}"]`);
    return this.auswahlTraining.isChecked();
  }

  public async sidePanelAusgewaehltTrainingOnline() {
    return this.onlineTrainingsphase.isChecked();
  }

  public async clickSachverhalt() {
    await this.sachverhalt.click();
  }

  public async bescheidErstellen() {
    await this.bescheid.click();
  }

  public async closeStart() {
    await this.schliessenStart.click();
  }

  public async closeTraining() {
    await this.schliessenTraining.click();
  }

  public async isBescheidAnsicht() {
    return await this.bescheidAnsicht.innerHTML();
  }

  public async isSachverhaltAnsicht() {
    return await this.sachverhaltAnsicht.innerHTML();
  }

  public async checkInformationsspalte() {
    return await this.information.innerText();
  }

  public async getAntragsart() {
    return await this.antragsart.innerHTML();
  }

  public async getDatum() {
    return (await this.datum.innerHTML()).trim();
  }

  public async getBemerkung() {
    return await this.bemerkung.innerHTML();
  }

  public async getPhase1() {
    return (await this.phase13.innerHTML()).trim();
  }

  public async getPhase2() {
    return (await this.phase2.innerHTML()).trim();
  }

  public async isGrund(grund: string) {
    this.grund = this.page.getByText(`${grund}`);
    return await this.grund.innerText();
  }

  public async getEinrichtungenAuswählenText() {
    return await this.einrichtungenAuswählenText.innerText();
  }

  public async getEinrichtungenAllePhasenText() {
    return await this.einrichtungenAllePhasenText.innerText();
  }

  public async getEinrichtungStartphase() {
    return await this.einrichtungStartphase.innerText();
  }

  public async getEinrichtungTrainingsphase() {
    return await this.einrichtungTrainingsphase.innerText();
  }

  public async getEinrichtungAuffrischungsphase() {
    return await this.einrichtungAuffrischungsphase.innerText();
  }

  public async getEinrichtungStartphaseAdresse() {
    return await this.einrichtungStartphaseAdresse.innerText();
  }

  public async getEintragungStartphaseAmbulanteText() {
    return await this.einrichtungStartphaseAmbulanteText.innerText();
  }

  public async getEintragungStartphasefreiePlätze() {
    return await this.einrichtungStartphasefreiePlätze.innerText();
  }

  public async geteinrichtungStartphasefehlendeAuswahlText() {
    return await this.einrichtungStartphasefehlendeAuswahlText.innerText();
  }

  public async geteinrichtungTrainingphasefehlendeAuswahlText() {
    return await this.einrichtungTrainingphasefehlendeAuswahlText.innerText();
  }

  public async getEinrichtungTrainingphaseAdresse() {
    return await this.einrichtungTrainingphaseAdresse.innerText();
  }

  public async getEintragungTrainingPhasenAmbulanteText() {
    return await this.einrichtungTrainingphaseAmbulanteText.innerText();
  }

  public async getEintragungTrainingPhasenfreiePlätze() {
    return await this.einrichtungTrainingphasefreiePlätze.innerText();
  }

  public async getEinrichtungAuffrischungsAdresse() {
    return await this.einrichtungAuffrischungsAdresse.innerText();
  }

  public async getEinrichtungAuffrischungsAmbulanteText() {
    return await this.einrichtungAuffrischungsAmbulanteText.innerText();
  }

  public async getEinrichtungAuffrischungfreiePlätze() {
    return await this.einrichtungAuffrischungfreiePlätze.innerText();
  }

  public async getEinrichtungStartphasenStandortSymbol() {
    return await this.einrichtungStartphaseStandortSymbol.isEnabled();
  }

  public async getEinrichtungStartphasenUhrSymbol() {
    return await this.einrichtungStartphaseUhrSymbol.isEnabled();
  }

  public async getEinrichtungTrainingStandortSymbol() {
    return await this.einrichtungTrainingStandortSymbol.isEnabled();
  }

  public async getEinrichtungTrainingphaseUhrSymbol() {
    return await this.einrichtungTrainingphaseUhrSymbol.isEnabled();
  }

  public async getEinrichtungAuffrischungsphaseStandortSymbol() {
    return await this.einrichtungAuffrischungsphaseStandortSymbol.isEnabled();
  }
  public async getEinrichtungAuffrischungsphaseUhrSymbol() {
    return await this.einrichtungAuffrischungsphaseUhrSymbol.isEnabled();
  }

  public async clickOnAntragBewilligen() {
    await this.antragBewilligen.click();
  }

  public async istAntragBewilligt() {
    //await this.page?.waitForTimeout(2000);
    return await this.antragBewilligenErfolgreich.isVisible();
  }

  public async istAntragBewilligtAktiv() {
    return await this.antragBewilligen.isEnabled();
  }

  public async istAntragBewilligtTechFehler() {
    return await this.antragBewilligenTechFehler.isVisible();
  }

  public async clickOnSachverhaltAufklaeren() {
    await this.sachverhaltAufklaeren.click();
  }

  public async clickOnStartPhase() {
    await this.startPhaseBtn.click();
  }
}
