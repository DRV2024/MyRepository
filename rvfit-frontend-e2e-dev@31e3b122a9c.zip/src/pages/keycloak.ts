import { Locator, Page } from '@playwright/test';

export class Keycloak {
  readonly page: Page;
  private readonly keyclockusername: Locator;
  private readonly keyclockpassword: Locator;
  private readonly signin: Locator;
  private readonly testUser: Locator;

  constructor(page: Page) {
    this.page = page;
    this.keyclockusername = page.locator('#username');
    this.keyclockpassword = page.locator('#password');
    this.signin = page.locator('#kc-login');
    this.testUser = page.locator("a[id='social-TESTNUTZER.IDP']");
  }

  public async setBenutzername(username: string) {
    return await this.keyclockusername.fill(username);
  }

  public async setKenntwort(password: string) {
    return await this.keyclockpassword.fill(password);
  }

  public async clickSignIn() {
    return await this.signin.click();
  }

  public async clickOnTestUser() {
    return await this.testUser.click();
  }
}
