import { getFrontendUrl } from '../support/environments';
import { Locator, Page } from '@playwright/test';

export class Aussteurung {
  readonly page: Page;
  //Button
  private readonly button: Locator;
  //Aussteurung
  private readonly ueberschrift: Locator;
  private readonly unterueberschrift: Locator;
  private headerName!: Locator;
  private headerVSRN!: Locator;
  //Info Banner
  private readonly infoheader: Locator;
  private readonly infoIcon: Locator;
  //private readonly infoText: Locator;
  // private infoText!: Locator;
  //AussteurungTabelle
  private name!: Locator;
  private daten!: Locator;
  private perdaten!: Locator;
  private antrdaten!: Locator;

  constructor(page: Page) {
    this.page = page;
    //Button
    this.button = page.locator('#personendaten-button-daten-aktualisieren');
    //Aussteurung
    this.ueberschrift = page.locator('#personendaten-h2');
    this.unterueberschrift = page.locator('#personendaten-h3');
    //Info Banner
    this.infoIcon = page.locator('#undefined drv-icon svg');
    this.infoheader = page.locator('#notification_header_inline-personendaten');
  }

  public async openPersonendaten(uuid: string) {
    await this.page?.goto(`${getFrontendUrl()}/antrag/${uuid}/personendaten`);
  }

  public async getUeberschrift() {
    return await this.ueberschrift.innerText();
  }

  public async getUnterUeberschrift() {
    return await this.unterueberschrift.innerText();
  }

  public async getButton() {
    return await this.button.innerText();
  }

  public async getHeaderVSRN(headerVsrn: string) {
    this.headerVSRN = this.page.locator('#vsnr b').getByText(headerVsrn);
    return await this.headerVSRN.innerText();
  }

  public async getHeaderName(headName: string) {
    this.headerName = this.page.locator('#vsnr b').getByText(headName);
    return await this.headerName.innerText();
  }

  public async getTabelleTitel(titel: string) {
    switch (titel) {
      case 'Feld':
        this.name = this.page.locator('#personendaten-table > table th').getByText(titel);
        break;
      case 'Personendaten':
        this.name = this.page.locator('#personendaten-table > table th').getByText(titel);
        break;
      case 'Antragsdaten':
        this.name = this.page.locator('#personendaten-table > table th').getByText(titel);
        break;
    }
    return await this.name.innerText();
  }

  public async getFelddaten(feldname: string) {
    this.daten = this.page
      .locator('#personendaten-table')
      .locator('tr:has-text("' + feldname + '")');

    switch (feldname) {
      case 'Nachname':
        this.daten = this.page.getByRole('cell', { name: 'nachname', exact: true });
        break;
      case 'Straße':
        this.daten = this.page.getByRole('cell', { name: 'straße', exact: true });
        break;
      case 'Hausnummer':
        this.daten = this.page.getByRole('cell', { name: 'hausnummer', exact: true });
        break;
      case 'Plz':
        this.daten = this.page.getByRole('cell', { name: 'plz', exact: true });
        break;
      case 'Wohnort':
        this.daten = this.page.getByRole('cell', { name: 'wohnort', exact: true });
        break;
      case 'Staatsangehörigkeit':
        this.daten = this.page.getByRole('cell', { name: 'staatsangehörigkeit', exact: true });
        break;
    }
    return await this.daten.innerText();
  }

  public async getPersonenDaten(pdaten: string) {
    switch (pdaten) {
      case 'Rubin':
      case 'Poccistraße':
      case '7':
      case '80336':
      case 'München':
      case 'Sri Lanka':
        this.perdaten = this.page.getByRole('cell', { name: pdaten, exact: true });
    }
    return this.perdaten.innerText();
  }

  public async getAntragDaten(antdaten: string) {
    switch (antdaten) {
      case 'Diamond':
      case 'Hauptstr. 10':
      case '10':
      case '70469':
      case 'Stuttgart':
      case 'Deutschland':
        this.antrdaten = this.page.getByRole('cell', { name: antdaten });
    }
    return this.antrdaten.innerText();
  }

  public async getInfoIcon() {
    return await this.infoIcon.getAttribute('role');
  }
  public async getInfoHeader() {
    return await this.infoheader.innerText();
  }
  public async getInfoText1(infoText: string): Promise<string> {
    const paragraphs = await this.page.locator('.drv-notification__text p').elementHandles();

    for (const paragraph of paragraphs) {
      //Text von jeden paragraph wird gekriegt
      let vollText = (await paragraph.textContent()) || '';
      //uppercase von Span Elemente sind zu überprüfen
      vollText = vollText.trim();
      if (vollText.includes(infoText)) {
        return vollText;
      }
    }
    //falls text nicht gefunden wurde
    throw new Error(`Text "${infoText}" wurde nicht gefunden`);
  }
}
