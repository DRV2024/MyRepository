import { ICustomWorld } from '../support/custom-world';
import { expect } from '@playwright/test';
import { Then } from '@cucumber/cucumber';

Then(
  'muss die Versicherungsnummer {} aus Antragsaufnahme mit der aus dem Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getPersonendaten(vsnr);
    expect(await this.antragaufnahme?.getvsnrTextAnzeigefeld()).toEqual(versicherter?.vsnr);
  },
);

Then(
  'muss die Versicherungsnummer {} aus Antragsaufnahme mit der aus dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.getvsnrTextAnzeigefeld()).toEqual(versicherter?.antrag.vsnr);
  },
);

Then(
  'muss bei der VSNR {} der Nachname aus Antragsaufnahme mit dem aus dem Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getPersonendaten(vsnr);
    // expect(await this.antragaufnahme?.getNachnameFeld()).toEqual(versicherter?.nachname);
    await expect(this.antragaufnahme!.nachnamefeld).toHaveValue(versicherter!.nachname.toString());
  },
);

Then(
  'muss bei der VSNR {} der Nachname aus Antragsaufnahme mit dem aus dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.getNachnameFeld()).toEqual(versicherter?.antrag.nachname);
  },
);

Then(
  'muss bei der VSNR {} der Vorname aus Antragsaufnahme mit dem aus dem Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getPersonendaten(vsnr);
    expect(await this.antragaufnahme?.getVornameFeld()).toEqual(versicherter?.vorname);
  },
);

Then(
  'muss bei der VSNR {} der Vorname aus Antragsaufnahme mit dem aus dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.getVornameFeld()).toEqual(versicherter?.antrag.vorname);
  },
);

Then(
  'muss bei der VSNR {} der Geburtsname aus Antragsaufnahme mit dem aus dem Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getPersonendaten(vsnr);
    expect(await this.antragaufnahme?.getGeburtsnameFeld()).toEqual(versicherter?.geburtsname);
  },
);

Then(
  'muss bei der VSNR {} der Geburtsname aus Antragsaufnahme mit dem aus dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.getGeburtsnameFeld()).toEqual(
      versicherter?.antrag.geburtsname,
    );
  },
);

Then(
  'muss bei der VSNR {} der frühere Name aus Antragsaufnahme mit dem aus dem Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getPersonendaten(vsnr);
    expect(await this.antragaufnahme?.getFruehereNamenFeld()).toEqual(versicherter?.fruehererName);
  },
);

Then(
  'muss bei der VSNR {} der frühere Name aus Antragsaufnahme mit dem aus dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    await this.page?.waitForTimeout(20000);
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.getFruehereNamenFeld()).toEqual(
      versicherter?.antrag.fruehererName,
    );
  },
);

Then(
  'muss bei der VSNR {} das Geburtsdatum aus Antragsaufnahme mit dem aus dem Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getPersonendaten(vsnr);
    expect(await this.antragaufnahme?.getGeburtsdatumFeld()).toEqual(versicherter?.geburtsdatum);
  },
);

Then(
  'muss bei der VSNR {} das Geburtsdatum aus Antragsaufnahme mit dem aus dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.getGeburtsdatumFeld()).toEqual(
      versicherter?.antrag.geburtsdatum,
    );
  },
);

Then(
  'muss bei der VSNR {} der Geburtsort aus Antragsaufnahme mit dem aus dem Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getPersonendaten(vsnr);
    expect(await this.antragaufnahme?.getGeburtsortFeld()).toEqual(versicherter?.geburtsort);
  },
);
Then(
  'muss bei der VSNR {} der Geburtsort aus Antragsaufnahme mit dem aus dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.getGeburtsortFeld()).toEqual(versicherter?.antrag.geburtsort);
  },
);

Then(
  'muss bei der VSNR {} das Vorsatzwort aus Antragsaufnahme mit dem aus dem Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getPersonendaten(vsnr);
    expect(await this.antragaufnahme?.getVorsatzwortDropDown()).toEqual(versicherter?.vorsatzwort);
  },
);

Then(
  'muss bei der VSNR {} das Vorsatzwort aus Antragsaufnahme mit dem aus dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.getVorsatzwortDropDown()).toEqual(
      versicherter?.antrag.vorsatzwort,
    );
  },
);

Then(
  'muss bei der VSNR {} der Namenszusatz aus Antragsaufnahme mit dem aus dem Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getPersonendaten(vsnr);
    expect(await this.antragaufnahme?.getNamenszusatzDropDown()).toEqual(
      versicherter?.namenszusatz,
    );
  },
);

Then(
  'muss bei der VSNR {} der Namenszusatz aus Antragsaufnahme mit dem aus dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.getNamenszusatzDropDown()).toEqual(
      versicherter?.antrag.namenszusatz,
    );
  },
);

Then(
  'muss bei der VSNR {} der Titel aus Antragsaufnahme mit dem aus dem Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getPersonendaten(vsnr);
    expect(await this.antragaufnahme?.getTitelFeld()).toEqual(versicherter?.titel);
  },
);

Then(
  'muss bei der VSNR {} der Titel aus Antragsaufnahme mit dem aus dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.getTitelFeld()).toEqual(versicherter?.antrag.titel);
  },
);

Then(
  'muss bei der VSNR {} das Geschlecht aus Antragsaufnahme mit dem aus dem Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getPersonendaten(vsnr);
    expect(await this.antragaufnahme?.getGeschlechtDropDown()).toEqual(versicherter?.geschlecht);
  },
);

Then(
  'muss bei der VSNR {} das Geschlecht aus Antragsaufnahme mit dem aus dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.getGeschlechtDropDown()).toEqual(
      versicherter?.antrag.geschlecht,
    );
  },
);

Then(
  'muss bei der VSNR {} die Adresse aus Antragsaufnahme mit der aus dem Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getPersonendaten(vsnr);
    expect(await this.antragaufnahme?.getAdresseFeld()).toEqual(versicherter?.strasse);
  },
);

Then(
  'muss bei der VSNR {} die Adresse aus Antragsaufnahme mit der aus dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.getAdresseFeld()).toEqual(versicherter?.antrag.strasse);
  },
);

Then(
  'muss bei der VSNR {} die Staatsangehörigkeit aus Antragsaufnahme mit der aus dem Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getPersonendaten(vsnr);
    expect(await this.antragaufnahme?.getStaatsangehoerigkeitDropDown()).toEqual(
      versicherter?.staatsangehoerigkeit,
    );
  },
);

Then(
  'muss bei der VSNR {} die Postleitzahl aus Antragsaufnahme mit der aus dem Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getPersonendaten(vsnr);
    expect(await this.antragaufnahme?.getPostleitzahlFeld()).toEqual(versicherter?.plz);
  },
);

Then(
  'muss bei der VSNR {} die Postleitzahl aus Antragsaufnahme mit der aus dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.getPostleitzahlFeld()).toEqual(versicherter?.antrag.plz);
  },
);

Then(
  'muss bei der VSNR {} der Wohnort aus Antragsaufnahme mit dem aus dem Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getPersonendaten(vsnr);
    expect(await this.antragaufnahme?.getWohnortFeld()).toEqual(versicherter?.wohnort);
  },
);

Then(
  'muss bei der VSNR {} der Wohnort aus Antragsaufnahme mit dem aus dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.getWohnortFeld()).toEqual(versicherter?.antrag.wohnort);
  },
);

Then(
  'muss bei der VSNR {} die Telefonnummer aus Antragsaufnahme mit der aus dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.getTelefonnummerFeld()).toEqual(versicherter?.antrag.telefon);
  },
);

Then(
  'muss bei der VSNR {} die Telefonnummer aus Antragsaufnahme mit der aus dem Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getPersonendaten(vsnr);
    expect(await this.antragaufnahme?.getTelefonnummerFeld()).toEqual(versicherter?.telefon);
  },
);

Then(
  'muss bei der VSNR {} die Telefaxnummer aus Antragsaufnahme mit der aus dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.getTelefaxFeld()).toEqual(versicherter?.antrag.fax);
  },
);

Then(
  'muss bei der VSNR {} die Telefaxnummer aus Antragsaufnahme mit der aus dem Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getPersonendaten(vsnr);
    expect(await this.antragaufnahme?.getTelefaxFeld()).toEqual(versicherter?.telefax);
  },
);

Then(
  'muss bei der VSNR {} die DE-Mail aus Antragsaufnahme mit der aus dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.getDeMailFeld()).toEqual(versicherter?.antrag.deMailAdresse);
  },
);

Then(
  'muss bei der VSNR {} der Großdruck aus Antragsaufnahme mit dem aus dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.istGroßDruckCBAktiviert()).toEqual(
      versicherter?.antrag.grossdruck,
    );
  },
);

Then(
  'muss bei der VSNR {} die Kurzschrift aus Antragsaufnahme mit der aus dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.istInBrailleKurzCBAktiviert()).toEqual(
      versicherter?.antrag.kurzschrift,
    );
  },
);

Then(
  'muss bei der VSNR {} die Vollschrift aus Antragsaufnahme mit der aus dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.istInBrailleVollCBAktiviert()).toEqual(
      versicherter?.antrag.vollschrift,
    );
  },
);

Then(
  'muss bei der VSNR {} CD aus Antragsaufnahme mit dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.istAlsCDCBAktiviert()).toEqual(versicherter?.antrag.cd);
  },
);

Then(
  'muss bei der VSNR {} das Hörmedium aus Antragsaufnahme mit dem aus dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.istAlsHoermediumCBAktiviert()).toEqual(
      versicherter?.antrag.hoermedium,
    );
  },
);

Then(
  'muss bei der VSNR {} die Reha 1 aus Antragsaufnahme mit der aus dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.getRehaEinR1feld()).toEqual(
      versicherter?.antrag.einrichtungStartAuf,
    );
  },
);

Then(
  'muss bei der VSNR {} die Reha 2 aus Antragsaufnahme mit der aus dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.getRehaEinR2feld()).toEqual(
      versicherter?.antrag.einrichtungTraining,
    );
  },
);

Then(
  'müssen bei der VSNR {} die Bemerkungen aus Antragsaufnahme mit denen aus dem Entwurf-Request-Mocking identisch sein',
  async function (this: ICustomWorld, vsnr: string) {
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    expect(await this.antragaufnahme?.getBemerkungenFeld()).toEqual(
      versicherter?.antrag.bemerkungen,
    );
  },
);
