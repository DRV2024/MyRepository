import { ICustomWorld } from '../support/custom-world';
import { getBackendUrl } from '../support/environments';
import { Given, When } from '@cucumber/cucumber';
import { readFileSync } from 'fs';
import { join } from 'path';

const einrichtungenAutocomplete = readFileSync(
  join(__dirname, '../data/einrichtungen_autocomplete.json'),
  'utf-8',
);

When(
  'die Personendaten abgefragt werden fuer {}',
  async function (this: ICustomWorld, vsnr: string) {
    const { page } = this;
    const versicherter = this.antragaufnahme?.getPersonendaten(vsnr);
    await page?.route(`${getBackendUrl()}/stammdaten/` + vsnr, (route) =>
      route.fulfill({
        status: 200,
        json: versicherter,
      }),
    );
  },
);

When(
  'die Entwurfdaten abgefragt werden fuer {}',
  async function (this: ICustomWorld, vsnr: string) {
    const { page } = this;
    const versicherter = this.antragaufnahme?.getEntwurfdaten(vsnr);
    await page?.route(`${getBackendUrl()}/papierantraege/entwurf/` + vsnr, (route) =>
      route.fulfill({
        status: 200,
        json: versicherter,
      }),
    );
  },
);
When(
  'Einrichtungsdaten fuer Autovervollstaendigung abgefragt werden',
  async function (this: ICustomWorld) {
    const { page } = this;
    await page?.route(`${getBackendUrl()}/rehaeinrichtungen/autovervollstaendigungen`, (route) => {
      return route.fulfill({
        status: 200,
        json: JSON.parse(einrichtungenAutocomplete),
      });
    });
  },
);

When(
  'der Server einen Fehler mit Status-Code {} bei "Antrag verarbeiten" zurück gibt',
  async function (this: ICustomWorld, statusCode: string) {
    const { page } = this;
    await page?.route(`${getBackendUrl()}/papierantraege`, (route) =>
      route.fulfill({
        status: parseInt(statusCode),
      }),
    );
  },
);

When(
  'der Server einen Fehler mit Status-Code {} bei Entwurf speichern zurück gibt',
  async function (this: ICustomWorld, statusCode: string) {
    const { page } = this;
    await page?.route(`${getBackendUrl()}/papierantraege/entwurf`, (route) =>
      route.fulfill({
        status: parseInt(statusCode),
      }),
    );
  },
);

When(
  'der Server einen Fehler mit Status-Code {} auf der Anspruchsprüfung-Seite bei "Antrag bewilligen" zur generierten UUID zurück gibt',
  async function (this: ICustomWorld, statusCode: string) {
    const { page } = this;
    await page?.route(
      `${getBackendUrl()}/bewilligungsbescheid/` + (await this.anspruchspruefung?.getUUID()),
      (route) =>
        route.fulfill({
          status: parseInt(statusCode),
        }),
    );
  },
);

When(
  'der Server einen Fehler mit Status-Code {} auf der Einrichtungsauswahl-Seite bei "Antrag bewilligen" zur generierten UUID zurück gibt',
  async function (this: ICustomWorld, statusCode: string) {
    const { page } = this;
    await page?.route(
      `${getBackendUrl()}/bewilligungsbescheid/` + (await this.einrichtungen?.getUUID()),
      (route) =>
        route.fulfill({
          status: parseInt(statusCode),
        }),
    );
  },
);

When(
  'der Server einen Fehler mit Status-Code {} auf der Anspruchsprüfung-Seite bei "Antrag ablehnen" zur generierten UUID zurück gibt',
  async function (this: ICustomWorld, statusCode: string) {
    await this.page?.route(
      `${getBackendUrl()}/ablehnungsbescheid/iframe/` + (await this.anspruchspruefung?.getUUID()),
      (route) =>
        route.fulfill({
          status: parseInt(statusCode),
        }),
    );
  },
);

//Mocking HTTP Fehlermeldungen von Team Flash

Given(
  'der Server einen Fehler mit Status-Code {} aus der Seite zurück gibt',
  async function (this: ICustomWorld, statusCode: string) {
    //  const { page } = this;
    await this.page?.route(`${getBackendUrl()}/antraege/*`, (route) => {
      route.fulfill({
        status: parseInt(statusCode),
      });
    });
  },
);
