import { ICustomWorld } from '../support/custom-world';
import { Then, Given } from '@cucumber/cucumber';
import { expect } from '@playwright/test';

Given(
  'die Aussteuerungs-Seite für Versicherte mit der UUID = {}',
  async function (this: ICustomWorld, uuid: string) {
    await this.aussteurung?.openPersonendaten(uuid);
    await this.keycloak?.clickOnTestUser();
    await this.keycloak?.setBenutzername('rvfit');
    await this.keycloak?.setKenntwort('fit');
    await this.keycloak?.clickSignIn();
  },
);

Then(
  'wird die VSRNR "{}" zur versicherten Person angezeigt',
  async function (this: ICustomWorld, daten: string) {
    expect(await this.aussteurung?.getHeaderVSRN(daten)).toEqual(daten);
  },
);

Then(
  'wird der Name "{}" zur versicherten Person angezeigt',
  async function (this: ICustomWorld, daten: string) {
    expect(await this.aussteurung?.getHeaderName(daten)).toEqual(daten);
  },
);

Then(
  'wird die Überschrift "{}" auf der Aussteuerungseite angezeigt',
  async function (this: ICustomWorld, ueberschrift: string) {
    expect(await this.aussteurung?.getUeberschrift()).toEqual(ueberschrift);
  },
);

Then(
  'wird ein Text "{}" auf der Aussteuerungseite angezeigt',
  async function (this: ICustomWorld, unterueberschrift: string) {
    expect(await this.aussteurung?.getUnterUeberschrift()).toEqual(unterueberschrift);
  },
);

Then('ein Option für "{}" ist zu sehen', async function (this: ICustomWorld, button: string) {
  expect(await this.aussteurung?.getButton()).toEqual(button);
});

Then(
  'wird eine Reihe mit dem Überschrift "{}" in der Tabelle von Abweichende Angabe zur Person angezeigt',
  async function (this: ICustomWorld, titel: string) {
    expect(await this.aussteurung?.getTabelleTitel(titel)).toEqual(titel);
  },
);
Then('unter Feld ist in der Reihe {} zu sehen', async function (this: ICustomWorld, name: string) {
  expect(await this.aussteurung?.getFelddaten(name)).toEqual(name);
});

Then(
  'unter Personendaten ist in der Reihe {} zu sehen',
  async function (this: ICustomWorld, perdaten: string) {
    expect(await this.aussteurung?.getPersonenDaten(perdaten)).toEqual(perdaten);
  },
);

Then(
  'unter Antragsdaten ist in der Reihe {} zu sehen',
  async function (this: ICustomWorld, antrdaten: string) {
    expect(await this.aussteurung?.getAntragDaten(antrdaten)).toEqual(antrdaten);
  },
);

Then(
  'ist die Info Meldung mit der Überschrift {} auf der Aussteuerungsseite zu sehen',
  async function (this: ICustomWorld, infoheader: string) {
    expect(await this.aussteurung?.getInfoIcon()).toEqual('img');
    expect(await this.aussteurung?.getInfoHeader()).toEqual(infoheader);
  },
);

Then(
  'in der Info Meldung ist der Text {} auf der Aussteuerungsseite zu sehen',
  async function (this: ICustomWorld, infoText1: string) {
    expect(await this.aussteurung?.getInfoText1(infoText1)).toEqual(infoText1);
  },
);
