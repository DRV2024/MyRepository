import { ICustomWorld } from '../support/custom-world';
import { Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { Page as PlaywrightPage } from 'playwright-core';
import AxeBuilder from '@axe-core/playwright';

// eslint-disable-next-line @typescript-eslint/no-var-requires
const htmlValidator = require('html-validator');

Then('muss in der Antragaufnahme Abmeldung angezeigt werden', async function (this: ICustomWorld) {
  await expect(this.antragaufnahme!.abmelden).toBeVisible();
});

Then('muss in der Antragaufnahme Anmeldung angezeigt werden', async function (this: ICustomWorld) {
  await expect(this.antragaufnahme!.anmelden).toBeVisible();
});

Then(
  'erwarte ich keine Barrierefreiheitsfehler für die Antragsdaten',
  async function (this: ICustomWorld) {
    const page = this.page! as PlaywrightPage;
    const excludedRules = [
      'landmark-banner-is-top-level',
      'color-contrast',
      'landmark-contentinfo-is-top-level',
      'landmark-main-is-top-level',
      'landmark-no-duplicate-banner',
      'landmark-no-duplicate-contentinfo',
      'landmark-no-duplicate-main',
      'landmark-unique',
    ];
    await page.locator('body > app-root > main > app-antrag-einrichtungen').waitFor();
    const a11yScans = await new AxeBuilder({ page })
      .include('body > app-root > main > app-antrag-einrichtungen')
      .disableRules(excludedRules)
      .analyze();
    const violations = a11yScans.violations;
    if (violations) {
      this.attach(JSON.stringify(violations), 'application/json');
      for (let i = 0; i < violations.length; i++) {
        const fehlerText = 'Accessibility (WCAG) violation ' + i + ' = ' + violations[i].help;
        this.attach(fehlerText);
      }
    }
    expect(violations.length).toEqual(0);
  },
);

Then('erwarte ich valides HTML für die Antragsdaten', async function (this: ICustomWorld) {
  const page = this.page!;
  const antragsdatenHTML = page.locator(
    '/html/body/app-root/app-antrag-einrichtungen/app-antrag-info',
  );
  const options = {
    validator: 'WHATWG',
    data: antragsdatenHTML,
    isFragment: true,
  };
  const result = await htmlValidator(options);
  if (!result.isValid) {
    this.attach(JSON.stringify(result), 'application/json');
  }
  expect(result.isValid).toBeTruthy();
});

Then(
  'erwarte ich keine Barrierefreiheitsfehler für die Einrichtungendaten',
  async function (this: ICustomWorld) {
    const page = this.page! as PlaywrightPage;
    await page
      .locator(
        '#main > div:nth-child(3) > div > div.drv-col-sm-12.drv-col-md-12.drv-col-lg-8 > app-einrichtungsliste',
      )
      .waitFor();

    const a11yScans = await new AxeBuilder({ page })
      .include(
        '#main > div:nth-child(3) > div > div.drv-col-sm-12.drv-col-md-12.drv-col-lg-8 > app-einrichtungsliste',
      )
      .analyze();
    const violations = a11yScans.violations;
    if (violations) {
      this.attach(JSON.stringify(violations), 'application/json');
    }
    expect(violations.length).toEqual(0);
  },
);

Then('erwarte ich valides HTML für die Einrichtungendaten', async function (this: ICustomWorld) {
  const page = this.page!;
  const einrichtungenHTML = page.locator(
    '/html/body/app-root/app-antrag-einrichtungen/div[2]/div/div[1]/app-einrichtungsliste',
  );
  const options = {
    validator: 'WHATWG',
    data: einrichtungenHTML,
    isFragment: true,
  };
  const result = await htmlValidator(options);
  if (!result.isValid) {
    this.attach(JSON.stringify(result), 'application/json');
  }
  expect(result.isValid).toBeTruthy();
});

Then('erwarte ich keine Barrierefreiheitsfehler im Sidepanel', async function (this: ICustomWorld) {
  const page = this.page! as PlaywrightPage;
  await page.locator('#sidepanelStartphase').waitFor();

  const a11yScans = await new AxeBuilder({ page }).include('#sidepanelStartphase').analyze();
  const violations = a11yScans.violations;
  if (violations) {
    this.attach(JSON.stringify(violations), 'application/json');
  }
  expect(violations.length).toEqual(0);
});

Then('erwarte ich valides HTML im Sidepanel', async function (this: ICustomWorld) {
  const page = this.page!;
  const einrichtungenHTML = page.locator('//*[@id="sidepanelStartphase"]');
  const options = {
    validator: 'WHATWG',
    data: einrichtungenHTML,
    isFragment: true,
  };
  const result = await htmlValidator(options);
  if (!result.isValid) {
    this.attach(JSON.stringify(result), 'application/json');
  }
  expect(result.isValid).toBeTruthy();
});

Then(
  'erwarte ich keine Barrierefreiheitsfehler auf der Seite',
  async function (this: ICustomWorld) {
    const page = this.page! as PlaywrightPage;
    //   await page.waitForNavigation();
    await page.waitForLoadState('networkidle');

    const excludedRules = [
      'landmark-banner-is-top-level',
      'landmark-contentinfo-is-top-level',
      'landmark-main-is-top-level',
      'landmark-no-duplicate-banner',
      'landmark-no-duplicate-contentinfo',
      'landmark-no-duplicate-main',
      'landmark-unique',
      'button-name',
      'region',
    ];

    const a11yScans = await new AxeBuilder({ page }).disableRules(excludedRules).analyze();

    const violations = a11yScans.violations;
    if (violations) {
      this.attach(JSON.stringify(violations), 'application/json');
      for (let i = 0; i < violations.length; i++) {
        const fehlerText = 'Accessibility (WCAG) violation ' + i + ' = ' + violations[i].help;
        this.attach(fehlerText);
      }
    }
    expect(violations.length).toEqual(0);
  },
);

Then('erwarte ich valides HTML auf der Seite', async function (this: ICustomWorld) {
  const page = this.page!;
  // await page.waitForNavigation();
  await page.waitForLoadState('networkidle');
  const completePageHTML = await page.content();
  const options = {
    validator: 'WHATWG',
    data: completePageHTML,
    ignore: [
      'no-unknown-elements',
      'element-required-attributes',
      'no-missing-references',
      'attribute-allowed-values',
      'no-redundant-role',
    ],
  };
  const result = await htmlValidator(options);
  if (!result.isValid) {
    this.attach(JSON.stringify(result), 'application/json');
    for (let i = 0; i < result.errors.length; i++) {
      const fehlerText =
        'HTML Conformance Check (WHATWG) error ' + i + ' = ' + result.errors[i].message;
      this.attach(fehlerText);
    }
  }
  expect(result.isValid).toBeTruthy();
});

Then(
  'erwarte ich keine Barrierefreiheitsfehler im Anspruchprüfung-Sidepanel',
  async function (this: ICustomWorld) {
    const page = this.page! as PlaywrightPage;
    await page.locator('#sidepanel').waitFor();

    const excludedRules = ['color-contrast'];
    const a11yScans = await new AxeBuilder({ page })
      .include('#sidepanel')
      .disableRules(excludedRules)
      .analyze();
    const violations = a11yScans.violations;
    if (violations) {
      this.attach(JSON.stringify(violations), 'application/json');
    }
    expect(violations.length).toEqual(0);
  },
);

Then('erwarte ich valides HTML im Anspruchprüfung-Sidepanel', async function (this: ICustomWorld) {
  const page = this.page!;
  const einrichtungenHTML = page.locator('//*[@id="modal"]');
  const options = {
    validator: 'WHATWG',
    data: einrichtungenHTML,
    isFragment: true,
  };
  const result = await htmlValidator(options);
  if (!result.isValid) {
    this.attach(JSON.stringify(result), 'application/json');
  }
  expect(result.isValid).toBeTruthy();
});

Then(
  'erwarte ich keine Barrierefreiheitsfehler für die Prüfergebnisse',
  async function (this: ICustomWorld) {
    const page = this.page! as PlaywrightPage;
    await page
      .locator(
        '#main > div:nth-child(3) > div > div.drv-col-sm-12.drv-col-md-12.drv-col-lg-8 > app-pruefergebnisse',
      )
      .waitFor();

    const a11yScans = await new AxeBuilder({ page })
      .include(
        '#main > div:nth-child(3) > div > div.drv-col-sm-12.drv-col-md-12.drv-col-lg-8 > app-pruefergebnisse',
      )
      .analyze();
    const violations = a11yScans.violations;
    if (violations) {
      this.attach(JSON.stringify(violations), 'application/json');
    }
    expect(violations.length).toEqual(0);
  },
);

Then('erwarte ich valides HTML auf der Prüfergebnisse', async function (this: ICustomWorld) {
  const page = this.page!;
  const pruefergebnisseHTML = page.locator(
    '/html/body/app-root/app-antrag-anspruchspruefung/div[2]/div/div[1]/app-pruefergebnisse',
  );
  const options = {
    validator: 'WHATWG',
    data: pruefergebnisseHTML,
    isFragment: true,
  };
  const result = await htmlValidator(options);
  if (!result.isValid) {
    this.attach(JSON.stringify(result), 'application/json');
  }
  expect(result.isValid).toBeTruthy();
});
