import { ICustomWorld } from '../support/custom-world';
import { Given, Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';

Given('die Antragaufnahme-Seite', async function (this: ICustomWorld) {
  await this.antragaufnahme?.openAntragaufnahme();
});

When('die Sachbearbeitung Anmelden klickt', async function (this: ICustomWorld) {
  await this.antragaufnahme?.clickAnmelden();
});

When('die Sachbearbeitung auf Abmelden klickt', async function (this: ICustomWorld) {
  await this.antragaufnahme?.clickAbmelden();
});

When('die Sachbearbeitung keine Versicherungnummer eingibt', async function (this: ICustomWorld) {
  await this.antragaufnahme?.loescheVersicherungsnummerTextFeld();
});

When(
  'die Sachbearbeitung die Versicherungnummer {} eingibt',
  async function (this: ICustomWorld, vsnr: string) {
    await this.antragaufnahme?.eingabeVersicherungsnummerTextFeld(vsnr);
  },
);

When(
  'die Sachbearbeitung die korrekte Versicherungsnummer {} eingibt',
  async function (this: ICustomWorld, vsnr: string) {
    await this.antragaufnahme?.eingabeVersicherungsnummerTextFeld(vsnr);
  },
);

When('die Sachbearbeitung auf Weiter klickt', async function (this: ICustomWorld) {
  await this.antragaufnahme?.clickOnWeiter();
});

When(
  'die Sachbearbeitung auf Zurück oder Versicherungsnummer eingeben klickt',
  async function (this: ICustomWorld) {
    //await this.page?.waitForTimeout(2000);
    await this.antragaufnahme!.clickOnZurueck();
  },
);

When('die Sachbearbeitung auf Tab drückt', async function (this: ICustomWorld) {
  await this.antragaufnahme?.clickOnTab();
});

When(
  'die Sachbearbeitung auf Tab drückt bis Dokumenenzugang aktiviert ist',
  async function (this: ICustomWorld) {
    let len = 0;
    do {
      await this.antragaufnahme?.clickOnTab();
      len++;
    } while (len < 45);
  },
);
When(
  'die Sachbearbeitung das Eingangsdatum {} eingibt',
  async function (this: ICustomWorld, datum: string) {
    await this.antragaufnahme!.typeEingangsDatum(datum);
  },
);

When(
  'die Sachbearbeitung das Antragsdatum {} eingibt',
  async function (this: ICustomWorld, datum: string) {
    await this.antragaufnahme!.typeAntragsDatum(datum);
  },
);

When(
  'die Sachbearbeitung fuellt Geburtsortfeld als {} aus',
  async function (this: ICustomWorld, geburtsort: string) {
    await this.antragaufnahme!.typeGeburtsortFeld(geburtsort);
  },
);

When(
  'die Sachbearbeitung fuellt Straße und Hausnummerfeld als {} aus',
  async function (this: ICustomWorld, adressefeld: string) {
    await this.antragaufnahme!.typeAdresseFeld(adressefeld);
  },
);

When(
  'die Sachbearbeitung fuellt Postleitzahl als {} aus',
  async function (this: ICustomWorld, postleitzahlfeld: string) {
    await this.antragaufnahme!.typePostleitzahlFeld(postleitzahlfeld);
  },
);

When(
  'die Sachbearbeitung fuellt Wohnort als {} aus',
  async function (this: ICustomWorld, wohnortfeld: string) {
    await this.antragaufnahme!.typeWohnortFeld(wohnortfeld);
  },
);

When('die Sachbearbeitung hat den Antrag verarbeitet', async function (this: ICustomWorld) {
  await this.antragaufnahme!.clickOnAntragVerarbeiten();
});

When(
  'die Sachbearbeitung die Eingangsdatum "{}" eingibt',
  async function (this: ICustomWorld, eingangsdatum: string) {
    await this.antragaufnahme!.typeEingangsDatum(eingangsdatum);
  },
);

When(
  'die Sachbearbeitung gibt das Eingangsdatum {} ein',
  async function (this: ICustomWorld, eingangsdatum: string) {
    await this.antragaufnahme!.typeEingangsDatum(eingangsdatum);
  },
);

When(
  'die Sachbearbeitung das Antragsdatum auf {} ändert',
  async function (this: ICustomWorld, datum: string) {
    await this.antragaufnahme?.typeAntragsDatum(datum);
  },
);

When('die Sachbearbeitung aktiviert die Checkbox', async function (this: ICustomWorld) {
  await this.antragaufnahme!.checkEingangsDatumCheckbox();
});

When('die Sachbearbeitung deaktiviert die Checkbox', async function (this: ICustomWorld) {
  await this.antragaufnahme!.unCheckEingangsDatumCheckbox();
});

When('der Vorname von der Sachbearbeitung geändert wird', async function (this: ICustomWorld) {
  await this.antragaufnahme?.setVornameFeld('Vorname_geändert');
});

When('der Nachname von der Sachbearbeitung geändert wird', async function (this: ICustomWorld) {
  await this.antragaufnahme?.setNachnameFeld('Nachname_geändert');
});

When('der Geburtsname von der Sachbearbeitung geändert wird', async function (this: ICustomWorld) {
  await this.antragaufnahme?.setGeburtsnameFeld('Geburtsname_geändert');
});

When(
  'der frühere Namen von der Sachbearbeitung geändert wird',
  async function (this: ICustomWorld) {
    await this.antragaufnahme?.setFruehereNamenFeld('Frühere_Namen_geändert');
  },
);

When('der Titel von der Sachbearbeitung geändert wird', async function (this: ICustomWorld) {
  await this.antragaufnahme?.setTitelfeld('Titel_geändert');
});

When('das Geburtsdatum von der Sachbearbeitung geändert wird', async function (this: ICustomWorld) {
  await this.antragaufnahme?.setGeburtsdatumFeld('1900-01-01');
});

When('das Geburtsort von der Sachbearbeitung geändert wird', async function (this: ICustomWorld) {
  await this.antragaufnahme?.setGeburtsortFeld('Geburtsort_geändert');
});

When(
  'die Straße und Hausnummer von der Sachbearbeitung geändert wird',
  async function (this: ICustomWorld) {
    await this.antragaufnahme?.setAdresseFeld('Adresse_geändert');
  },
);

When('die Postleitzahl von der Sachbearbeitung geändert wird', async function (this: ICustomWorld) {
  await this.antragaufnahme?.setPostleitzahlFeld('12345');
});

When('das Wohnort von der Sachbearbeitung geändert wird', async function (this: ICustomWorld) {
  await this.antragaufnahme?.setWohnortFeld('Wohnort_geändert');
});

When(
  'die Telefonnummer von der Sachbearbeitung geändert wird',
  async function (this: ICustomWorld) {
    await this.antragaufnahme?.setTelefonnummerFeld('12345');
  },
);

When(
  'die Telefaxnummer von der Sachbearbeitung geändert wird',
  async function (this: ICustomWorld) {
    await this.antragaufnahme?.setTelefaxFeld('54321');
  },
);
When(
  'die Checkbox der De-Mail von der Sachbearbeitung aktiviert wird',
  async function (this: ICustomWorld) {
    await this.antragaufnahme?.checkDeMailCB();
  },
);

When('die De-Mail von der Sachbearbeitung geändert wird', async function (this: ICustomWorld) {
  await this.antragaufnahme?.setdeMailFeld('musterman.max@web.de-mail.de');
});

When('die Sachbearbeitung auf Abbrechen klickt', async function (this: ICustomWorld) {
  await this.antragaufnahme?.clickAbbrechen();
});

When('die Sachbearbeitung auf Fortfahren klickt', async function (this: ICustomWorld) {
  await this.antragaufnahme?.clickfortfahren();
});

When(
  'die Sachbearbeitung den Text "{}" im Feld Bemerkungen eingibt',
  async function (this: ICustomWorld, bemerkungentext: string) {
    await this.antragaufnahme?.eingabeBemerkungenFeld(bemerkungentext);
  },
);

When(
  'die Sachbearbeitung {} Zeichen im Feld Bemerkungen eingibt',
  async function (this: ICustomWorld, gesLaenge: string) {
    await this.antragaufnahme?.eingabeBemerkungenFeldFuellen(gesLaenge);
  },
);

When(
  'die Sachbearbeitung versucht noch zusätzlich das Wort "{}" im Feld Bemerkungen einzugeben',
  async function (this: ICustomWorld, wort: string) {
    await this.antragaufnahme?.eingabeBemerkungenFeldAnhaengen(wort);
  },
);

When(
  'die Sachbearbeitung den Text {} im Feld Telefon eingibt',
  async function (this: ICustomWorld, Telefon: string) {
    await this.antragaufnahme?.setTelefonnummerFeld(Telefon);
  },
);

When(
  'die Sachbearbeitung den Text {} im Feld Telefax eingibt',
  async function (this: ICustomWorld, Telefax: string) {
    await this.antragaufnahme?.setTelefaxFeld(Telefax);
  },
);

When(
  'die Sachbearbeitung den Text {} im Feld De-Mail eingibt',
  async function (this: ICustomWorld, DeMail: string) {
    if (!this.antragaufnahme?.istDeMailCBAktiviert()) {
      await this.antragaufnahme?.setdeMailFeld(DeMail);
    }
  },
);

When(
  'die Sachbearbeitung den Text {string} im Feld Rehabilitationseinrichtung Eins eingibt',
  async function (this: ICustomWorld, Rehabilitationseinrichtung: string) {
    await this.page?.waitForTimeout(1000);
    await this.antragaufnahme?.setRehaEinR1feld(Rehabilitationseinrichtung);
  },
);

When(
  'die Sachbearbeitung den Text {string} im Feld Rehabilitationseinrichtung Zwei eingibt',
  async function (this: ICustomWorld, Rehabilitationseinrichtung: string) {
    await this.page?.waitForTimeout(1000);
    await this.antragaufnahme?.setRehaEinR2feld(Rehabilitationseinrichtung);
  },
);

When(
  'die Sachbearbeitung beim Label zu den Bemerkungen auf Info klickt',
  async function (this: ICustomWorld) {
    await this.antragaufnahme?.clickOnBemerkungenInfoLabel();
  },
);

When('die Sachbearbeitung den Nachnamen löscht', async function (this: ICustomWorld) {
  await this.antragaufnahme?.clearNachnameFeld();
});

When('die Sachbearbeitung auf Entwurf speichern klickt', async function (this: ICustomWorld) {
  await this.antragaufnahme?.clickOnEntwurfSpeichern();
});

When('die Sachbearbeitung auf Antrag verarbeiten klickt', async function (this: ICustomWorld) {
  await this.antragaufnahme?.clickOnAntragVerarbeiten();
});

When(
  'die Sachbearbeitung das Eingangsdatum auf {} ändert',
  async function (this: ICustomWorld, datum: string) {
    await this.antragaufnahme?.typeEingangsDatum(datum);
  },
);

When(
  'die Sachbearbeitung explizit das Eingangs- und Antragsdatum löscht',
  async function (this: ICustomWorld) {
    await this.antragaufnahme?.unCheckEingangsDatumCheckbox();
    await this.antragaufnahme?.loescheEingangsDatum();
    await this.antragaufnahme?.loescheAntragsDatum();
  },
);

When(
  'der Nachname von der Sachbearbeitung auf {} geändert wird',
  async function (this: ICustomWorld, GespeicherterNachname: string) {
    await this.antragaufnahme?.clearNachnameFeld();
    await this.antragaufnahme?.setNachnameFeld(GespeicherterNachname);
  },
);

When('die Sachbearbeitung auf Antrag verarbeiteten klickt', async function (this: ICustomWorld) {
  await this.antragaufnahme?.clickOnAntragVerarbeiten();
});

When('die Sachbearbeitung auf Abschluss klickt', async function (this: ICustomWorld) {
  await this.antragaufnahme?.clickOnAbschlussNavigationLeiste();
});

When('die Sachbearbeitung auf Daten aktualisieren klickt', async function (this: ICustomWorld) {
  await this.antragaufnahme!.clickDatenAktualisieren();
});

When(
  'die Sachbearbeitung zwischenzeitlich mit der Versicherungsnummer {} weiterarbeitet',
  async function (this: ICustomWorld, vsnr: string) {
    await this.page?.waitForTimeout(1000);
    await this.antragaufnahme!.clickOnZurueck();
    await this.antragaufnahme?.eingabeVersicherungsnummerTextFeld(vsnr);
    await this.antragaufnahme?.clickOnWeiter();
    await this.antragaufnahme?.clickfortfahren();
    await this.page?.waitForTimeout(1000);
    await this.antragaufnahme!.clickOnZurueck();
  },
);

When(
  'die Sachbearbeitung für die VSNR {} einen Entwurf speichert',
  async function (this: ICustomWorld, vsnr: string) {
    await this.page?.waitForTimeout(1000);
    await this.antragaufnahme!.erzeugeNeuenEntwurf(vsnr);
  },
);

Then(
  'wird das korrekte gespeicherte Eingangsdatum "{}" angezeigt',
  async function (this: ICustomWorld, datum: string) {
    expect(await this.antragaufnahme?.getEingangsDatum()).toEqual(datum);
  },
);

Then(
  'ist die Überschrift im oberen Feld für die Eingabemaske aufzunehmen und gemäß Wire Frame',
  async function (this: ICustomWorld) {
    expect(await this.antragaufnahme!.getUeberschriftText()).toEqual(
      'Papierantrag auf Leistungen zur Prävention erfassen',
    );
  },
);

Then(
  'sind die Bezeichnungen des Eingabefelders des Antrags identisch zur Eingabemaske',
  async function (this: ICustomWorld) {
    expect(await this.antragaufnahme!.getEingabefelderCount()).toEqual(21);
    expect(await this.antragaufnahme!.getEingabefelderText()).toEqual([
      'Versicherungsnummer',
      'Eingangsdatum Bei dem Eingangsdatum handelt es sich um das Datum des Eingangsstempels auf dem Papierantrag.',
      'Antragsdatum  Bei dem Antragsdatum handelt es sich um das Datum, an dem der Antrag bei einer zur Annahme des Antrags befugten Stelle wirksam gestellt worden ist.',
      '1. Rehabilitationseinrichtung (Name, Anschrift) (optional)',
      '2. Rehabilitationseinrichtung (Name, Anschrift) (optional)',
      'Name',
      'Vorname (Rufname)',
      'Geburtsname (optional)',
      'Frühere Namen (optional)',
      'Geburtsdatum',
      'Geschlecht (optional)',
      'Vorsatzwort (optional)',
      'Namenszusatz (optional)',
      'Titel (optional)',
      'Geburtsort (Kreis, Land)',
      'Staatsangehörigkeit (optional)',
      'Straße, Hausnummer',
      'Postleitzahl',
      'Wohnort',
      'Telefon (telefonisch tagsüber zu erreichen) (optional)',
      'Telefax (optional)',
    ]);
  },
);

Then(
  'sind die Bezeichnungen des Checkboxfelders des Antrags identisch zur Eingabemaske',
  async function (this: ICustomWorld) {
    expect(await this.antragaufnahme!.getCheckBoxfelderCount()).toEqual(7);
    expect(await this.antragaufnahme!.getCheckBoxfelderText()).toEqual([
      'Eingangsdatum als Antragsdatum übernehmen',
      'Ich bitte ausschließlich um Übermittlung der Dokumente in elektronischer Form an mein De-Mail-Postfach. Damit entfällt eine Übersendung der Dokumente in Papierform. Meine De-Mail-Adresse lautet:',
      'als Großdruck',
      'in Braille (Kurzschrift)',
      'in Braille (Vollschrift)',
      'als CD (Schriftdatei oder Textdatei im ".doc"- Format)',
      'als Hörmedium (CD-DAISY Format)',
    ]);
  },
);

Then(
  'sind die Eingabefelder Bescheidschreibung erforderlichen Daten zur Verfügung',
  async function (this: ICustomWorld) {
    expect(await this.antragaufnahme!.istVersicherungsnummerEditable());
  },
);

Then('wird die Fehler Meldung "{}" angezeigt', async function (this: ICustomWorld, error: string) {
  expect(await this.antragaufnahme?.getFehlerText()).toEqual(error);
});

Then(
  'ist die Zwischenüberschriften der Eingabemaske identisch zur Wire Frame',
  async function (this: ICustomWorld) {
    expect(await this.antragaufnahme!.getAllZwischenschriftsCount()).toEqual(4);
    expect(await this.antragaufnahme!.getAllZwischenschrifts()).toEqual([
      'Antragsinformationen',
      'Vorgesehene Rehabilitationseinrichtungen',
      'Angaben zur Person',
      'Dokumentenzugang',
    ]);
  },
);

Then(
  'ist ein Feld für die Aufnahme von Vorsatzwörtern vorzusehen',
  async function (this: ICustomWorld) {
    expect(await this.antragaufnahme?.isVorsatzwortFeldEditable());
  },
);

Then(
  'ist ein Feld für die Aufnahme von NamenszusatzFeld vorzusehen',
  async function (this: ICustomWorld) {
    expect(await this.antragaufnahme?.isNamenszusatzFeldEditable());
  },
);

Then(
  'ist ein Feld für die Aufnahme von Titelfield vorzusehen',
  async function (this: ICustomWorld) {
    expect(await this.antragaufnahme?.istitelfeldEditable());
  },
);

Then(
  'sind die Eingabefelder identisch zur Reihenfolge im Papierantrag abgefragt werden',
  async function (this: ICustomWorld) {
    expect(await this.antragaufnahme!.getEingabeFelderCount()).toEqual(21);
  },
);

Then(
  'ist Eingabe in das Feld Eingangsdatum hinsichtlich Datumsformat korrekt',
  async function (this: ICustomWorld) {
    expect(await this.antragaufnahme!.getEingangsDatumFormat()).toEqual('date');
  },
);

Then(
  'ist Eingabe in das Feld Antragsdatum hinsichtlich Datumsformat korrekt',
  async function (this: ICustomWorld) {
    expect(await this.antragaufnahme!.getAntragsDatumFormat()).toEqual('date');
  },
);

Then(
  'wird die Fehler Meldung des Eingangsdatums "{}" angezeigt',
  async function (this: ICustomWorld, datumsfehlerText: string) {
    expect(await this.antragaufnahme!.getEingangsDatumsFehlerText()).toEqual(datumsfehlerText);
  },
);

Then(
  'wird die Fehler Meldung des Antragsdatums "{}" angezeigt',
  async function (this: ICustomWorld, datumsfehlerText: string) {
    expect(await this.antragaufnahme!.getAntragsDatumsFehlerText()).toEqual(datumsfehlerText);
  },
);

Then('ist die Checkbox nicht aktiviert', async function (this: ICustomWorld) {
  expect(await this.antragaufnahme!.isCheckboxAktiviert()).toBeFalsy();
});

Then(
  'wird des Feldes erfolgt bei Verlassen und "{}" angezeigt',
  async function (this: ICustomWorld) {
    expect(await this.antragaufnahme!.getErfolgreichtGespeichertText()).toContain(
      'Erfolgreich gespeichert',
    );
  },
);

Then('wird das Antragsdatum gesetzt', async function (this: ICustomWorld) {
  expect(await this.antragaufnahme!.isAntragsDatumEditable()).toBeFalsy();
});

Then('sind das Antragsdatum und Eingangsdatum gleich', async function (this: ICustomWorld) {
  expect(await this.antragaufnahme!.getEingangsDatum()).toEqual(
    await this.antragaufnahme!.getAntragsDatum(),
  );
});

Then(
  'wird das vorbefüllte Datum verworfen und das Antragsdatumfeld ist wieder editierbar',
  async function (this: ICustomWorld) {
    expect(await this.antragaufnahme!.isAntragsDatumEditable()).toBeTruthy();
  },
);

// Then('entsprechen die Überschriften dem Wireframe', async function (this: ICustomWorld) {
//   //await this.page?.waitForTimeout(2000);
//   expect(await this.antragaufnahme!.getAllZwischenschriftsCount()).toEqual(3);
//   expect(await this.antragaufnahme!.getAllZwischenschrifts()).toEqual([
//     'Papierantrag auf Leistungen zur Prävention erfassen',
//     'Versicherungsnummer eingeben',
//   ]);
// });

Then(
  'wird das Navigationselement Versicherungsnummer eingeben in der Navigationsleiste angezeigt',
  async function (this: ICustomWorld) {
    await expect(this.antragaufnahme!.vsnrNavigationLeiste).toContainText(
      'Versicherungsnummer eingeben',
    );
  },
);

Then(
  'wird das Navigationselement Antragsdaten eingeben in der Navigationsleiste angezeigt',
  async function (this: ICustomWorld) {
    await expect(this.antragaufnahme!.antrDatenEingNavigationLeiste).toContainText(
      'Antragsdaten eingeben',
    );
  },
);

Then(
  'wird die Überschrift Versicherungnummer eingeben auf der Startseite Papierantrag angezeigt',
  async function (this: ICustomWorld) {
    await expect(this.antragaufnahme!.vsnrEingebenUeberschrift).toBeVisible();
  },
);

Then(
  'wird der Text Geben sie die Versicherungsnummer ein auf der Startseite Papierantrag angezeigt',
  async function (this: ICustomWorld) {
    await expect(this.antragaufnahme!.vsnrTextFeldInfo).toBeVisible();
  },
);

Then(
  'wird das Label Versicherungsnummer auf der Startseite Papierantrag angezeigt',
  async function (this: ICustomWorld) {
    await expect(this.antragaufnahme!.vsnrTextFeldLabel).toBeVisible();
  },
);

Then(
  'wird das Eingabefeld für die Versicherungsnummer auf der Startseite Papierantrag angezeigt',
  async function (this: ICustomWorld) {
    await expect(this.antragaufnahme!.vsnrTextFeld).toBeVisible();
  },
);

Then(
  'die Versicherungsnummer im Eingabefeld kann nicht überschrieben werden',
  async function (this: ICustomWorld) {
    expect(await this.antragaufnahme!.istVersicherungsnummerEditable()).toBeFalsy();
  },
);

Then('wird die Fehlermeldung {} angezeigt', async function (this: ICustomWorld, error: string) {
  expect(await this.antragaufnahme?.getvsnrFehlermeldung()).toEqual(error);
});

Then('wird Antragsdaten eingeben angezeigt', async function (this: ICustomWorld) {
  await expect(this.antragaufnahme!.antragsDatenEingebenUeberschrift).toBeVisible();
});

Then('wird Antragsinformationen angezeigt', async function (this: ICustomWorld) {
  await expect(this.antragaufnahme!.antragsDatenEingebenUeberschrift).toBeVisible();
});

Then(
  'wird Vorgesehene Rehabilitationseinrichtungen angezeigt',
  async function (this: ICustomWorld) {
    await expect(this.antragaufnahme!.vorRehaEin).toBeVisible();
  },
);

Then('wird Angaben zur Person angezeigt', async function (this: ICustomWorld) {
  await expect(this.antragaufnahme!.angabenzurPerson).toBeVisible();
});

Then('wird Dokumentenzugang angezeigt', async function (this: ICustomWorld) {
  await expect(this.antragaufnahme!.dokumentenzugang).toBeVisible();
});

Then('wird Bemerkungen angezeigt', async function (this: ICustomWorld) {
  await expect(this.antragaufnahme!.bemerkungenUeberschrift).toBeVisible();
});

Then(
  'die zuvor eingegebene Versicherungnummer ist identisch zur angezeigten Versicherungsnummer',
  async function (this: ICustomWorld) {
    await expect(this.antragaufnahme!.vsnrTextFeld).toHaveValue('03080800B018');
  },
);

Then(
  'wird {} aus den Stammdaten als Vorname vorbelegt',
  async function (this: ICustomWorld, vorname: string) {
    if (expect(this.antragaufnahme?.getVornameFeldLaenge())) {
      expect(await this.antragaufnahme?.getVornameFeld()).toEqual(vorname);
    }
  },
);

Then(
  'muss der {} dazu beim Feld Vorname angezeigt werden',
  async function (this: ICustomWorld, hinweis: string) {
    if (expect(this.antragaufnahme?.getVornameFeldLaenge())) {
      expect(await this.antragaufnahme?.getVornameFeldHinweis()).toEqual(hinweis);
    }
  },
);

Then('wird Ergebnis Autocomplete Einrichtung 1 angezeigt', async function (this: ICustomWorld) {
  await this.antragaufnahme?.page.waitForTimeout(3000);
  expect(await this.antragaufnahme?.istAutocompleteErgebnis1Sichtbar()).toBeTruthy();
});

Then('wird Ergebnis Autocomplete Einrichtung 2 angezeigt', async function (this: ICustomWorld) {
  await this.antragaufnahme?.page.waitForTimeout(3000);
  expect(await this.antragaufnahme?.istAutocompleteErgebnis2Sichtbar()).toBeTruthy();
});

Then(
  'die Anzahl der Ergebnisse Autocomplete ist {}',
  async function (this: ICustomWorld, anzahl: number) {
    expect(await this.antragaufnahme?.anzahlAutocompleteErgebnis()).toBe(anzahl);
  },
);

Then(
  'die Anzahl der Ergebnisse Autocomplete Feld 2 ist {}',
  async function (this: ICustomWorld, anzahl: number) {
    expect(await this.antragaufnahme?.anzahlAutocompleteErgebnisZwei()).toBe(anzahl);
  },
);

Then('wird der Hinweis beim Feld Vorname nicht angezeigt', async function (this: ICustomWorld) {
  if (expect(this.antragaufnahme?.getVornameFeldLaenge())) {
    expect(await this.antragaufnahme?.istVornameFeldHinweisSichtbar()).toBeFalsy();
  }
});

Then(
  'wird {} aus den Stammdaten als Nachname vorbelegt',
  async function (this: ICustomWorld, nachname: string) {
    if (expect(this.antragaufnahme?.getNachnameFeldLaenge())) {
      expect(await this.antragaufnahme?.getNachnameFeld()).toEqual(nachname);
    }
  },
);

Then(
  'muss der {} dazu beim Feld Nachname angezeigt werden',
  async function (this: ICustomWorld, hinweis: string) {
    if (expect(this.antragaufnahme?.getNachnameFeldLaenge())) {
      expect(await this.antragaufnahme?.getNachnameFeldHinweis()).toEqual(hinweis);
    }
  },
);

Then('wird der Hinweis beim Feld Nachname nicht angezeigt', async function (this: ICustomWorld) {
  if (expect(this.antragaufnahme?.getNachnameFeldLaenge())) {
    expect(await this.antragaufnahme?.istNachnameFeldHinweisSichtbar()).toBeFalsy();
  }
});

Then(
  'wird {} aus den Stammdaten als Geburtsname vorbelegt',
  async function (this: ICustomWorld, geburtsname: string) {
    if (expect(this.antragaufnahme?.getGeburtsnameFeldLaenge())) {
      expect(await this.antragaufnahme?.getGeburtsnameFeld()).toEqual(geburtsname);
    }
  },
);

Then(
  'muss der {} dazu beim Feld Geburtsname angezeigt werden',
  async function (this: ICustomWorld, hinweis: string) {
    if (expect(this.antragaufnahme?.getGeburtsnameFeldLaenge())) {
      expect(await this.antragaufnahme?.getGeburtsnameFeldHinweis()).toEqual(hinweis);
    }
  },
);

Then('wird der Hinweis beim Feld Geburtsname nicht angezeigt', async function (this: ICustomWorld) {
  if (expect(this.antragaufnahme?.getGeburtsnameFeldLaenge())) {
    expect(await this.antragaufnahme?.istGeburtsnameFeldHinweisSichtbar()).toBeFalsy();
  }
});

Then(
  'wird {} aus den Stammdaten als frühere Namen vorbelegt',
  async function (this: ICustomWorld, frueherenamen: string) {
    if (expect(this.antragaufnahme?.getFruehereNamenFeldLaenge())) {
      expect(await this.antragaufnahme?.getFruehereNamenFeld()).toEqual(frueherenamen);
    }
  },
);

Then(
  'muss der {} dazu beim Feld Frühere Namen angezeigt werden',
  async function (this: ICustomWorld, hinweis: string) {
    if (expect(this.antragaufnahme?.getFruehereNamenFeldLaenge())) {
      expect(await this.antragaufnahme?.getFruehereNamenFeldHinweis()).toEqual(hinweis);
    }
  },
);

Then(
  'wird der Hinweis beim Feld Frühere Namen nicht angezeigt',
  async function (this: ICustomWorld) {
    if (expect(this.antragaufnahme?.getFruehereNamenFeldLaenge())) {
      expect(await this.antragaufnahme?.istFruehereNamenFeldHinweisSichtbar()).toBeFalsy();
    }
  },
);

Then(
  'wird {} aus den Stammdaten als Vorsatzwort vorbelegt',
  async function (this: ICustomWorld, vorsatzwort: string) {
    if (expect(this.antragaufnahme?.getVorsatzwortFeldLaenge())) {
      expect(await this.antragaufnahme?.getVorsatzwortFeld()).toEqual(vorsatzwort);
    }
  },
);

Then(
  'muss der {} dazu beim Feld Vorsatzwort angezeigt werden',
  async function (this: ICustomWorld, hinweis: string) {
    if (expect(this.antragaufnahme?.getVorsatzwortFeldLaenge())) {
      expect(await this.antragaufnahme?.getVorsatzwortFeldHinweis()).toEqual(hinweis);
    }
  },
);

Then('wird der Hinweis beim Feld Vorsatzwort nicht angezeigt', async function (this: ICustomWorld) {
  if (expect(this.antragaufnahme?.getVorsatzwortFeldLaenge())) {
    expect(await this.antragaufnahme?.istVorsatzwortFeldHinweisSichtbar()).toBeFalsy();
  }
});

Then(
  'wird {} aus den Stammdaten als Namenszusatz vorbelegt',
  async function (this: ICustomWorld, namenszusatz: string) {
    if (expect(this.antragaufnahme?.getNamenszusatzFeldLaenge())) {
      expect(await this.antragaufnahme?.getNamenszusatzFeld()).toEqual(namenszusatz);
    }
  },
);

Then(
  'muss der {} dazu beim Feld Namenszusatz angezeigt werden',
  async function (this: ICustomWorld, hinweis: string) {
    if (expect(this.antragaufnahme?.getNamenszusatzFeldLaenge())) {
      expect(await this.antragaufnahme?.getNamenszusatzFeldHinweis()).toEqual(hinweis);
    }
  },
);

Then(
  'wird der Hinweis beim Feld Namenszusatz nicht angezeigt',
  async function (this: ICustomWorld) {
    if (expect(this.antragaufnahme?.getNamenszusatzFeldLaenge())) {
      expect(await this.antragaufnahme?.istNamenszusatzFeldHinweisSichtbar()).toBeFalsy();
    }
  },
);

Then(
  'wird {} aus den Stammdaten als Titel vorbelegt',
  async function (this: ICustomWorld, titel: string) {
    if (expect(this.antragaufnahme?.getTitelfeldLaenge())) {
      expect(await this.antragaufnahme?.getTitelFeld()).toEqual(titel);
    }
  },
);

Then(
  'muss der {} dazu beim Feld Titel angezeigt werden',
  async function (this: ICustomWorld, hinweis: string) {
    if (expect(this.antragaufnahme?.getTitelfeldLaenge())) {
      expect(await this.antragaufnahme?.getTitelfeldHinweis()).toEqual(hinweis);
    }
  },
);

Then('wird der Hinweis beim Feld Titel nicht angezeigt', async function (this: ICustomWorld) {
  if (expect(this.antragaufnahme?.getTitelfeldLaenge())) {
    expect(await this.antragaufnahme?.istTitelFeldHinweisSichtbar()).toBeFalsy();
  }
});

Then(
  'wird {} aus den Stammdaten als Geburtsdatum vorbelegt',
  async function (this: ICustomWorld, geburtsdatum: string) {
    if (expect(this.antragaufnahme?.getGeburtsdatumFeldLaenge())) {
      expect(await this.antragaufnahme?.getGeburtsdatumFeld()).toEqual(geburtsdatum);
    }
  },
);

Then(
  'muss der {} dazu beim Feld Geburtsdatum angezeigt werden',
  async function (this: ICustomWorld, hinweis: string) {
    if (expect(this.antragaufnahme?.getGeburtsdatumFeldLaenge())) {
      expect(await this.antragaufnahme?.getGeburtsdatumFeldHinweis()).toEqual(hinweis);
    }
  },
);

Then(
  'wird der Hinweis beim Feld Geburtsdatum nicht angezeigt',
  async function (this: ICustomWorld) {
    if (expect(this.antragaufnahme?.getGeburtsdatumFeldLaenge())) {
      await this.page?.waitForTimeout(1000);
      expect(await this.antragaufnahme?.istGeburtsnameFeldHinweisSichtbar()).toBeFalsy();
    }
  },
);

Then(
  'wird {} aus den Stammdaten als Geschlecht vorbelegt',
  async function (this: ICustomWorld, geschlecht: string) {
    if (expect(this.antragaufnahme?.getGeschlechtFeldLaenge())) {
      expect(await this.antragaufnahme?.getGeschlechtFeld()).toEqual(geschlecht);
    }
  },
);

Then(
  'muss der {} dazu beim Feld Geschlecht angezeigt werden',
  async function (this: ICustomWorld, hinweis: string) {
    if (expect(this.antragaufnahme?.getGeschlechtFeldLaenge())) {
      expect(await this.antragaufnahme?.getGeschlechtFeldHinweis()).toEqual(hinweis);
    }
  },
);

Then('wird der Hinweis beim Feld Geschlecht nicht angezeigt', async function (this: ICustomWorld) {
  if (expect(this.antragaufnahme?.getGeschlechtFeldLaenge())) {
    expect(await this.antragaufnahme?.istGeschlechtFeldHinweisSichtbar()).toBeFalsy();
  }
});

Then(
  'wird {} aus den Stammdaten als Geburtsort vorbelegt',
  async function (this: ICustomWorld, geburtsort: string) {
    if (expect(this.antragaufnahme?.getGeburtsortFeldLaenge())) {
      expect(await this.antragaufnahme?.getGeburtsortFeld()).toEqual(geburtsort);
    }
  },
);

Then(
  'muss der {} dazu beim Feld Geburtsort angezeigt werden',
  async function (this: ICustomWorld, hinweis: string) {
    if (expect(this.antragaufnahme?.getGeburtsortFeldLaenge())) {
      expect(await this.antragaufnahme?.getGeburtsortFeldHinweis()).toEqual(hinweis);
    }
  },
);

Then('wird der Hinweis beim Feld Geburtsort nicht angezeigt', async function (this: ICustomWorld) {
  if (expect(this.antragaufnahme?.getGeburtsortFeldLaenge())) {
    expect(await this.antragaufnahme?.istGeburtsortFeldHinweisSichtbar()).toBeFalsy();
  }
});

Then(
  'wird {} aus den Stammdaten als Staatsangehörigkeit vorbelegt',
  async function (this: ICustomWorld, staatsangehoerigkeit: string) {
    if (expect(this.antragaufnahme?.getStaatsangehoerigkeitFeldLaenge())) {
      expect(await this.antragaufnahme?.getStaatsangehoerigkeitDropDown()).toEqual(
        staatsangehoerigkeit,
      );
    }
  },
);

Then(
  'muss der {} dazu beim Feld Staatsangehörigkeit angezeigt werden',
  async function (this: ICustomWorld, hinweis: string) {
    if (expect(this.antragaufnahme?.getStaatsangehoerigkeitFeldLaenge())) {
      expect(await this.antragaufnahme?.getStaatsangehoerigkeitFeldHinweis()).toEqual(hinweis);
    }
  },
);

Then(
  'wird der Hinweis beim Feld Staatsangehörigkeit nicht angezeigt',
  async function (this: ICustomWorld) {
    if (expect(this.antragaufnahme?.getStaatsangehoerigkeitFeldLaenge())) {
      expect(await this.antragaufnahme?.istStaatsangehoerigkeitFeldHinweisSichtbar()).toBeFalsy();
    }
  },
);

Then(
  'wird {} aus den Stammdaten als Straße und Hausnummer vorbelegt',
  async function (this: ICustomWorld, adresse: string) {
    if (expect(this.antragaufnahme?.getAdresseFeldLaenge())) {
      expect(await this.antragaufnahme?.getAdresseFeld()).toEqual(adresse);
    }
  },
);

Then(
  'muss der {} dazu beim Feld Straße und Hausnummer angezeigt werden',
  async function (this: ICustomWorld, hinweis: string) {
    if (expect(this.antragaufnahme?.getAdresseFeldLaenge())) {
      expect(await this.antragaufnahme?.getAdresseFeldHinweis()).toEqual(hinweis);
    }
  },
);

Then(
  'wird der Hinweis beim Feld Straße und Hausnummer nicht angezeigt',
  async function (this: ICustomWorld) {
    if (expect(this.antragaufnahme?.getAdresseFeldLaenge())) {
      expect(await this.antragaufnahme?.istAdresseFeldHinweisSichtbar()).toBeFalsy();
    }
  },
);

Then(
  'wird {} aus den Stammdaten als Postleitzahl vorbelegt',
  async function (this: ICustomWorld, postleitzahl: string) {
    if (expect(this.antragaufnahme?.getPostleitzahlFeldLaenge())) {
      expect(await this.antragaufnahme?.getPostleitzahlFeld()).toEqual(postleitzahl);
    }
  },
);

Then(
  'muss der {} dazu beim Feld Postleitzahl angezeigt werden',
  async function (this: ICustomWorld, hinweis: string) {
    if (expect(this.antragaufnahme?.getPostleitzahlFeldLaenge())) {
      expect(await this.antragaufnahme?.getPostleitzahlFeldHinweis()).toEqual(hinweis);
    }
  },
);

Then(
  'wird der Hinweis beim Feld Postleitzahl nicht angezeigt',
  async function (this: ICustomWorld) {
    if ((await this.antragaufnahme?.getPostleitzahlFeld()) !== '') {
      expect(await this.antragaufnahme?.istPostleitzahlFeldHinweisSichtbar()).toBeFalsy();
    }
  },
);

Then(
  'wird {} aus den Stammdaten als Wohnort vorbelegt',
  async function (this: ICustomWorld, wohnort: string) {
    if (expect(this.antragaufnahme?.getWohnortFeldLaenge())) {
      expect(await this.antragaufnahme?.getWohnortFeld()).toEqual(wohnort);
    }
  },
);

Then(
  'muss der {} dazu beim Feld Wohnort angezeigt werden',
  async function (this: ICustomWorld, hinweis: string) {
    if (expect(this.antragaufnahme?.getWohnortFeldLaenge())) {
      expect(await this.antragaufnahme?.getWohnortFeldHinweis()).toEqual(hinweis);
    }
  },
);

Then('wird der Hinweis beim Feld Wohnort nicht angezeigt', async function (this: ICustomWorld) {
  if (expect(this.antragaufnahme?.getWohnortFeldLaenge())) {
    expect(await this.antragaufnahme?.istWohnortFeldHinweisSichtbar()).toBeFalsy();
  }
});

Then(
  'wird {} aus den Stammdaten als Telefonnummer vorbelegt',
  async function (this: ICustomWorld, telefonnummer: string) {
    if (expect(this.antragaufnahme?.getTelefonnummerFeldLaenge())) {
      expect(await this.antragaufnahme?.getTelefonnummerFeld()).toEqual(telefonnummer);
    }
  },
);

Then(
  'muss der {} dazu beim Feld Telefonnummer angezeigt werden',
  async function (this: ICustomWorld, hinweis: string) {
    if (expect(this.antragaufnahme?.getTelefonnummerFeldLaenge())) {
      expect(await this.antragaufnahme?.getTelefonnummerFeldHinweis()).toEqual(hinweis);
    }
  },
);

Then(
  'wird der Hinweis beim Feld Telefonnummer nicht angezeigt',
  async function (this: ICustomWorld) {
    if (expect(this.antragaufnahme?.getTelefonnummerFeldLaenge())) {
      expect(await this.antragaufnahme?.istTelefonnummerFeldHinweisSichtbar()).toBeFalsy();
    }
  },
);

Then(
  'wird {} aus den Stammdaten als Telefaxnummer vorbelegt',
  async function (this: ICustomWorld, telefaxnummer: string) {
    if (expect(this.antragaufnahme?.getTelefaxFeldLaenge())) {
      expect(await this.antragaufnahme?.getTelefaxFeld()).toEqual(telefaxnummer);
    }
  },
);

Then(
  'muss der {} dazu beim Feld Telefaxnummer angezeigt werden',
  async function (this: ICustomWorld, hinweis: string) {
    if (expect(this.antragaufnahme?.getTelefaxFeldLaenge())) {
      expect(await this.antragaufnahme?.getTelefaxFeldHinweis()).toEqual(hinweis);
    }
  },
);

Then(
  'wird der Hinweis beim Feld Telefaxnummer nicht angezeigt',
  async function (this: ICustomWorld) {
    if (expect(this.antragaufnahme?.getTelefaxFeldLaenge())) {
      expect(await this.antragaufnahme?.istTelefaxFeldHinweisSichtbar()).toBeFalsy();
    }
  },
);

Then(
  'wird {} aus den Stammdaten als De-Mail vorbelegt',
  async function (this: ICustomWorld, demail: string) {
    if (expect(this.antragaufnahme?.getDeMailFeldLaenge())) {
      expect(await this.antragaufnahme?.getDeMailFeld()).toEqual(demail);
    }
  },
);

Then(
  'muss der {} dazu beim Feld De-Mail angezeigt werden',
  async function (this: ICustomWorld, hinweis: string) {
    if (expect(this.antragaufnahme?.getDeMailFeldLaenge())) {
      expect(await this.antragaufnahme?.getDeMailFeldHinweis()).toEqual(hinweis);
    }
  },
);

Then('wird der Hinweis beim Feld De-Mail nicht angezeigt', async function (this: ICustomWorld) {
  if (expect(this.antragaufnahme?.getDeMailFeldLaenge())) {
    expect(await this.antragaufnahme?.istDeMailFeldHinweisSichtbar()).toBeFalsy();
  }
});

Then('erscheint die Sicherheitsabfrage', async function (this: ICustomWorld) {
  expect(await this.antragaufnahme?.istAndereVsnrSidepanelSichtbar()).toBeTruthy();
});

Then(
  'bleibt die neue Versicherungsnummer {} eingetragen',
  async function (this: ICustomWorld, vsnr: number) {
    expect(await this.antragaufnahme?.getvsnrTextFeld()).toEqual(vsnr);
  },
);

Then(
  'werden die Daten der ürsprünglichen Versicherungsnummer {} gelöscht',
  async function (this: ICustomWorld, vsnr: number) {
    expect(await this.antragaufnahme?.getvsnrTextAnzeigefeld()).not.toEqual(vsnr);
  },
);

Then(
  'werden die Stammdaten der neuen Versicherungsnummer {} geladen',
  async function (this: ICustomWorld, vsnr: number) {
    expect(await this.antragaufnahme?.getvsnrTextAnzeigefeld()).toEqual(vsnr);
  },
);

Then('wird der Navigationstext Bemerkungen angezeigt', async function (this: ICustomWorld) {
  await this.antragaufnahme?.clickOnBemerkungenFeld();
  expect(await this.antragaufnahme!.istbemerkungenSichtbar()).toBeTruthy();
});

Then('wird das Feld Bemerkungen angezeigt', async function (this: ICustomWorld) {
  await this.antragaufnahme?.clickOnBemerkungenFeld();
  expect(await this.antragaufnahme!.istBemerkungenFeldSichtbar()).toBeTruthy();
});

Then('wird die Überschrift Bemerkungen angezeigt', async function (this: ICustomWorld) {
  await this.antragaufnahme?.clickOnBemerkungenFeld();
  expect(await this.antragaufnahme!.istBemerkungenUeberschriftSichtbar()).toBeTruthy();
});

Then('wird das Label zu den Bemerkungen angezeigt', async function (this: ICustomWorld) {
  await this.antragaufnahme?.clickOnBemerkungenFeld();
  expect(await this.antragaufnahme!.istBemerkungenLabelSichtbar()).toBeTruthy();
});

Then('wird ein Infotext mit zusätzlichen Hinweisen angezeigt', async function (this: ICustomWorld) {
  await this.antragaufnahme?.clickOnBemerkungenFeld();
  expect(await this.antragaufnahme!.istBemerkungenInfotextSichtbar());
});

Then('wird das Info-Label zu den Bemerkungen angezeigt', async function (this: ICustomWorld) {
  await this.antragaufnahme?.clickOnBemerkungenFeld();
  expect(await this.antragaufnahme!.istBemerkungenInfoLabelSichtbar()).toBeTruthy();
});

Then('wird der Inhalt im Feld Bemerkungen gelöscht', async function (this: ICustomWorld) {
  await this.antragaufnahme!.loescheBemerkungenFeld();
});

Then(
  'wird der Zeichen-Zähler {} zu den Bemerkungen angezeigt',
  async function (this: ICustomWorld, zaehler: string) {
    expect((await this.antragaufnahme!.getBemerkungenZaehler()).toString()).toContain(zaehler);
  },
);

Then('steht der Zähler auf {}', async function (this: ICustomWorld, zaehler: string) {
  expect((await this.antragaufnahme!.getBemerkungenZaehler()).toString()).toContain(zaehler);
});

Then(
  'fehlt im Feld Bemerkungen an Ende des Textes das Wort "{}"',
  async function (this: ICustomWorld, wort: string) {
    expect(await this.antragaufnahme!.getStringRechtsImBemerkungenFeld(wort.length)).not.toEqual(
      wort,
    );
  },
);

Then(
  'ist im Feld Bemerkungen der Text {} nicht vorhanden!',
  async function (this: ICustomWorld, bemerkungen: string) {
    await this.antragaufnahme?.clickOnBemerkungenFeld();
    // await expect(this.antragaufnahme!.bemerkungenfeld).to
    expect(await this.antragaufnahme!.getBemerkungenFeld()).not.toEqual(bemerkungen);
  },
);

Then(
  'ist der zuvor eingegebene Text "{}" im Feld Bemerkungen noch vorhanden',
  async function (this: ICustomWorld, bemerkungenText: string) {
    await this.antragaufnahme?.clickOnBemerkungenFeld();
    expect(await this.antragaufnahme!.getBemerkungenFeld()).toEqual(bemerkungenText);
  },
);

Then('wird Entwurf speichern angezeigt', async function (this: ICustomWorld) {
  expect(await this.antragaufnahme!.istEntwurfSpeichernSichtbar()).toBeTruthy;
});

Then('wird weiterhin die Eingabemaske angezeigt', async function (this: ICustomWorld) {
  expect(await this.antragaufnahme!.istAntragsDatenEingebenUeberschriftSichtbar()).toBeTruthy;
});

Then(
  'wird die Statusmeldung für die erfolgreiche Speicherung des Entwurfs angezeigt',
  async function (this: ICustomWorld) {
    expect(await this.antragaufnahme!.istUeberschriftInfoTextGespeichertSichtbar());
  },
);

Then(
  'wird die Fehler-Überschrift "{}" angezeigt',
  async function (this: ICustomWorld, infoText: string) {
    expect(await this.antragaufnahme!.getUeberschriftinfoTextTechProblem()).toContain(infoText);
  },
);

Then(
  'wird die Statusmeldung nach Ablauf einer gewissen Zeit wieder ausgeblendet',
  async function (this: ICustomWorld) {
    await this.page?.waitForTimeout(12000);
    expect(await this.antragaufnahme!.istUeberschriftInfoTextGespeichertSichtbar()).toBeFalsy();
  },
);

Then(
  'wird die Information "{}" im UI angezeigt',
  async function (this: ICustomWorld, infoTextZwischengespeichert: string) {
    expect(await this.antragaufnahme?.getInfoTextZwischengespeichert()).toEqual(
      infoTextZwischengespeichert,
    );
  },
);

Then('ist Entwurf speichern inaktiv', async function (this: ICustomWorld) {
  expect(await this.antragaufnahme?.istEntwurfSpeichernAktiviert()).toBeFalsy();
});

Then('ist Entwurf speichern aktiv', async function (this: ICustomWorld) {
  expect(await this.antragaufnahme?.istEntwurfSpeichernAktiviert()).toBeTruthy();
});

Then(
  'wird die Statusmeldung für die erfolgreiche Übermittlung der Antragsdaten angezeigt',
  async function (this: ICustomWorld) {
    expect(await this.antragaufnahme?.istinfoTextAntragVerarbeitetSichtbar());
  },
);

Then(
  'wird die Statusmeldung für die abweichenden Personendaten angezeigt',
  async function (this: ICustomWorld) {
    expect(await this.antragaufnahme!.istUeberschriftInfoTextDateninkonsistenzFehlerSichtbar());
  },
);

Then(
  'wird das Navigationselement Abschluss in der Navigationsleiste angezeigt',
  async function (this: ICustomWorld) {
    await expect(this.antragaufnahme!.abschlussNavigationLeiste).toContainText('Abschluss');
  },
);

Then(
  'wird die Statusmeldung für die fehlerhafte Weiterverarbeitung der Antragsdaten angezeigt',
  async function (this: ICustomWorld) {
    expect(await this.antragaufnahme!.istUeberschriftInfoTextAntragVerarbeitetFehlerSichtbar());
  },
);

Then(
  'wird die Statusmeldung für die fehlerhafte Speicherung des Entwurfs angezeigt',
  async function (this: ICustomWorld) {
    expect(await this.antragaufnahme!.istUeberschriftinfoTextTechProblemSichtbar());
  },
);

Then(
  'wird die Hinweismeldung für die Aufforderung zur Überprüfung der Personendaten angezeigt',
  async function (this: ICustomWorld) {
    expect(await this.antragaufnahme!.istUeberschriftPersonenDatenHinweisSichtbar());
  },
);

Then('wird Zu den Personendaten angezeigt', async function (this: ICustomWorld) {
  await this.page?.waitForTimeout(1000);
  expect(await this.antragaufnahme!.istZudenPersonendatenVerfuegbar()).toBeTruthy();
});

Then('wird Daten aktualisieren angezeigt', async function (this: ICustomWorld) {
  await this.page?.waitForTimeout(1000);
  expect(await this.antragaufnahme!.istDatenAktualisierenVerfuegbar()).toBeTruthy();
});

Then(
  'wird die Hinweismeldung für die erfolgreiche Aktualisierung der Personendaten angezeigt',
  async function (this: ICustomWorld) {
    expect(await this.antragaufnahme!.istTextPersonenDatenAktuellUeberschriftSichtbar());
  },
);

Then('ist das Eingabefeld Vorname schreibgeschützt', async function (this: ICustomWorld) {
  expect(await this.antragaufnahme!.istVornameFeldAenderbar()).not.toBeTruthy();
});

Then('ist das Eingabefeld Nachname schreibgeschützt', async function (this: ICustomWorld) {
  expect(await this.antragaufnahme!.istNachnameFeldAenderbar()).not.toBeTruthy();
});

Then('ist das Eingabefeld Geburtsname schreibgeschützt', async function (this: ICustomWorld) {
  expect(await this.antragaufnahme!.istGeburtsnameFeldEditable()).not.toBeTruthy();
});
Then('ist das Eingabefeld Frühere Namen schreibgeschützt', async function (this: ICustomWorld) {
  expect(await this.antragaufnahme!.istFruehereNamenAenderbar()).not.toBeTruthy();
});

Then('ist das Eingabefeld Vorsatzwort schreibgeschützt', async function (this: ICustomWorld) {
  expect(await this.antragaufnahme!.istVorsatzwortAenderbar()).not.toBeTruthy();
});

Then('ist das Eingabefeld Namenszusatz schreibgeschützt', async function (this: ICustomWorld) {
  expect(await this.antragaufnahme!.istNamenszusatzAenderbar()).not.toBeTruthy();
});

Then('ist das Eingabefeld Titel schreibgeschützt', async function (this: ICustomWorld) {
  expect(await this.antragaufnahme!.istTitelAenderbar()).not.toBeTruthy();
});

Then('ist das Eingabefeld Geburtsdatum schreibgeschützt', async function (this: ICustomWorld) {
  expect(await this.antragaufnahme!.istGeburtdatumAenderbar()).not.toBeTruthy();
});

Then('ist das Eingabefeld Geschlecht schreibgeschützt', async function (this: ICustomWorld) {
  expect(await this.antragaufnahme!.istGeschlechtAenderbar()).not.toBeTruthy();
});

Then('ist das Eingabefeld Geburtsort schreibgeschützt', async function (this: ICustomWorld) {
  expect(await this.antragaufnahme!.istGeburtsortAenderbar()).not.toBeTruthy();
});

Then(
  'ist das Eingabefeld Staatsangehörigkeit schreibgeschützt',
  async function (this: ICustomWorld) {
    expect(await this.antragaufnahme!.istStaatsangehoerigAenderbar()).not.toBeTruthy();
  },
);

Then('ist das Eingabefeld Adresse schreibgeschützt', async function (this: ICustomWorld) {
  expect(await this.antragaufnahme!.istAdresseAenderbar()).not.toBeTruthy();
});

Then('ist das Eingabefeld Postleitzahl schreibgeschützt', async function (this: ICustomWorld) {
  expect(await this.antragaufnahme!.istPostleitzahlAenderbar()).not.toBeTruthy();
});

Then('ist das Eingabefeld Wohnort schreibgeschützt', async function (this: ICustomWorld) {
  expect(await this.antragaufnahme!.istWohnortAenderbar()).not.toBeTruthy();
});

Then('ist das Eingabefeld Telefon schreibgeschützt', async function (this: ICustomWorld) {
  expect(await this.antragaufnahme!.istTelefonnummerAenderbar()).not.toBeTruthy();
});

Then('ist das Eingabefeld Telefax schreibgeschützt', async function (this: ICustomWorld) {
  expect(await this.antragaufnahme!.istTelefaxAenderbar()).not.toBeTruthy();
});
