import { ICustomWorld } from '../support/custom-world';
import { usersMap } from '../support/users';
import { expect } from '@playwright/test';
import { Given, Then, When } from '@cucumber/cucumber';
import { readFileSync } from 'fs';
import { join } from 'path';

const antrag_02496532A000 = readFileSync(
  join(__dirname, '../data/eAntrag_Einrichtung_02496532A000_ERFUELLT.xml'),
  'utf-8',
);
const antrag_12010156S020 = readFileSync(
  join(__dirname, '../data/eAntrag_12010156S020_NICHT_ERFUELLT.xml'),
  'utf-8',
);
const antrag_13010156S020 = readFileSync(
  join(__dirname, '../data/eAntrag_13010156S020_AUSSTEUERN.xml'),
  'utf-8',
);
const antrag_14010156S020 = readFileSync(
  join(__dirname, '../data/eAntrag_Einrichtung_14010156S020_AUSSTEUERN.xml'),
  'utf-8',
);
const antrag_15010156S020 = readFileSync(
  join(__dirname, '../data/eAntrag_Einrichtung_15010156S020_AUSSTEUERN.xml'),
  'utf-8',
);
const antrag_16010156S020 = readFileSync(
  join(__dirname, '../data/eAntrag_Einrichtung_16010156S020_AUSSTEUERN.xml'),
  'utf-8',
);
const antrag_17010156S020 = readFileSync(
  join(__dirname, '../data/eAntrag_Einrichtung_17010156S020_AUSSTEUERN.xml'),
  'utf-8',
);
const antrag_00168708A000 = readFileSync(
  join(__dirname, '../data/eAntrag_Einrichtung_00168708A000_AUSSTEUERN.xml'),
  'utf-8',
);
const antrag_02302738A000 = readFileSync(
  join(__dirname, '../data/eAntrag_Einrichtung_02302738A000_AUSSTEUERN.xml'),
  'utf-8',
);
const antrag_09586269A000 = readFileSync(
  join(__dirname, '../data/eAntrag_Einrichtung_09586269A000_AUSSTEUERN.xml'),
  'utf-8',
);

const antrag_13060857P466 = readFileSync(
  join(__dirname, '../data/eAntrag_Anspruch_13060857P466_AUSSTEUERN.xml'),
  'utf-8',
);

const antrag_02220697M981 = readFileSync(
  join(__dirname, '../data/eAntrag_Anspruch_02220697M981_AUSSTEUERN.xml'),
  'utf-8',
);

const antrag_24200202S483 = readFileSync(
  join(__dirname, '../data/eAntrag_Anspruch_24200202S483_AUSSTEUERN.xml'),
  'utf-8',
);

const antrag_24010101T236 = readFileSync(
  join(__dirname, '../data/eAntrag_Anspruch_24010101T236_AUSSTEUERN.xml'),
  'utf-8',
);
const antrag_15010191A388 = readFileSync(
  join(__dirname, '../data/eAntrag_Anspruch_15010191A388_NICHT_ERFUELLT.xml'),
  'utf-8',
);
const antrag_15020478H296 = readFileSync(
  join(__dirname, '../data/eAntrag_Anspruch_15020478H296_NICHT_ERMITTELBAR.xml'),
  'utf-8',
);
const antrag_15280982D041 = readFileSync(
  join(__dirname, '../data/eAntrag_Anspruch_15280982D041_ERFUELLT.xml'),
  'utf-8',
);
const antrag_15171186R598 = readFileSync(
  join(__dirname, '../data/eAntrag_PersonenDaten_15171186R598_Name.xml'),
  'utf-8',
);
const antrag_15011295R334 = readFileSync(
  join(__dirname, '../data/eAntrag_PersonenDaten_15011295R334_Adresse.xml'),
  'utf-8',
);
const antrag_15190230P015 = readFileSync(
  join(__dirname, '../data/eAntrag_PersonenDaten_15190230P015_Staatsangehörigkeit.xml'),
  'utf-8',
);
const antrag_48210470M496 = readFileSync(
  join(__dirname, '../data/eAntrag_PersonenDaten_48210470M496_KEIN_INFOMELDUNG.xml'),
  'utf-8',
);

const antrag_sva_15010191A388 = readFileSync(
  join(__dirname, '../data/eAntrag_15010191A388_SachverhaltAufklaeren.xml'),
  'utf-8',
);

const antrag_ab_12010156S020 = readFileSync(
  join(__dirname, '../data/eAntrag_12010156S020_AntragBewilligen.xml'),
  'utf-8',
);

Given('ein Request für das Anlegen von Anträgen', async function (this: ICustomWorld) {
  this.requestPath = `/antraege/eantrag`;
});

Given(
  'die Einrichtungen-Seite für Versicherte mit der generierten UUID zur VSNR = {}',
  async function (this: ICustomWorld, vsnr: string) {
    let antrag;
    switch (vsnr) {
      case '12010156S020':
        antrag = antrag_12010156S020;
        break;
      case '13010156S020':
        antrag = antrag_13010156S020;
        break;
      case '14010156S020':
        antrag = antrag_14010156S020;
        break;
      case '15010156S020':
        antrag = antrag_15010156S020;
        break;
      case '16010156S020':
        antrag = antrag_16010156S020;
        break;
      case '17010156S020':
        antrag = antrag_17010156S020;
        break;
      case '02302738A000':
        antrag = antrag_02302738A000;
        break;
      case '09586269A000':
        antrag = antrag_09586269A000;
        break;
    }

    this.requestResponse = await this.requestContext?.post('/antraege/eantrag', {
      headers: {
        'Content-Type': 'application/xml',
        authorization: `Bearer ${this.accessToken}`,
      },
      data: antrag,
    });

    const response = await this.requestResponse?.text();
    const index = response?.indexOf('uuid') || 0;
    this.uuid = response?.substring(index + 7, index + 43) ?? '';
    const user = usersMap['benutzer_Ktan_70'];
    await this.einrichtungen?.openEinrichtungen(this.uuid);
    // await this.keycloak?.clickOnTestUser();
    await this.keycloak?.setBenutzername(user.userName);
    await this.keycloak?.setKenntwort(user.password);
    await this.keycloak?.clickSignIn();
    //TODO: entfernen, wenn nicht mehr auf Antragsaufnahme-Seite weitergeleitet wird
    await this.einrichtungen?.wait();
    await this.einrichtungen?.openEinrichtungen(this.uuid);
  },
);

Given(
  'die Anspruchsprüfung-Seite für Versicherte mit der generierten UUID zur VSNR = {}',
  async function (this: ICustomWorld, vsnr: string) {
    let antrag;
    switch (vsnr) {
      case '13060857P466':
        antrag = antrag_13060857P466;
        break;
      case '12010156S020':
        antrag = antrag_12010156S020;
        break;
      case '02496532A000':
        antrag = antrag_02496532A000;
        break;
      case '13010156S020':
        antrag = antrag_13010156S020;
        break;
      case '02220697M981':
        antrag = antrag_02220697M981;
        break;
      case '24200202S483':
        antrag = antrag_24200202S483;
        break;
      case '24010101T236':
        antrag = antrag_24010101T236;
        break;
      case '15010191A388':
        antrag = antrag_15010191A388;
        break;
    }

    this.requestResponse = await this.requestContext?.post('/antraege/eantrag', {
      headers: {
        'Content-Type': 'application/xml',
        authorization: `Bearer ${this.accessToken}`,
      },
      data: antrag,
    });

    const response = await this.requestResponse?.text();
    const index = response?.indexOf('uuid') || 0;
    this.uuid = response?.substring(index + 7, index + 43) ?? '';
    const user = usersMap['benutzer_Ktan_70'];
    await this.einrichtungen?.setUUID(this.uuid);
    await this.anspruchspruefung?.openAnspruchspruefung(this.uuid);
    //// await this.keycloak?.clickOnTestUser();
    await this.keycloak?.setBenutzername(user.userName);
    await this.keycloak?.setKenntwort(user.password);
    await this.keycloak?.clickSignIn();
    //TODO: entfernen, wenn nicht mehr auf Antragsaufnahme-Seite weitergeleitet wird
    await this.einrichtungen?.wait();
    await this.anspruchspruefung?.openAnspruchspruefung(this.uuid);
  },
);

Given(
  'die Anspruchsprüfung-Seite für Versicherte mit der generierten UUID zur Versicherung Nummer = {}',
  async function (this: ICustomWorld, vsnr: string) {
    let antrag;
    switch (vsnr) {
      case '15010191A388':
        antrag = antrag_15010191A388;
        break;
      case '15020478H296':
        antrag = antrag_15020478H296;
        break;
      case '15280982D041':
        antrag = antrag_15280982D041;
        break;
      case '13060857P466':
        antrag = antrag_13060857P466;
        break;
    }

    this.requestResponse = await this.requestContext?.post('/antraege/eantrag', {
      headers: {
        'Content-Type': 'application/xml',
        authorization: `Bearer ${this.accessToken}`,
      },
      data: antrag,
    });

    const response = await this.requestResponse?.text();
    const index = response?.indexOf('uuid') || 0;
    this.uuid = response?.substring(index + 7, index + 43) ?? '';
    const user = usersMap['benutzer_Ktan_15'];
    await this.einrichtungen?.setUUID(this.uuid);
    await this.anspruchspruefung?.openAnspruchspruefung(this.uuid);
    // await this.keycloak?.clickOnTestUser();
    await this.keycloak?.setBenutzername(user.userName);
    await this.keycloak?.setKenntwort(user.password);
    await this.keycloak?.clickSignIn();
    await this.einrichtungen?.wait();
    await this.anspruchspruefung?.openAnspruchspruefung(this.uuid);
  },
);
Given(
  'ein Request für das Speichern einer Einrichtung für die "{}"',
  async function (this: ICustomWorld, phase: string) {
    this.requestResponse = await this.requestContext?.post('/antraege/eantrag', {
      headers: {
        'Content-Type': 'application/xml',
        authorization: `Bearer ${this.accessToken}`,
      },
      data: antrag_12010156S020,
    });

    const response = await this.requestResponse?.text();
    const index = response?.indexOf('uuid') || 0;
    this.uuid = response?.substring(index + 7, index + 43) ?? '';

    switch (phase) {
      case 'STARTPHASE':
        this.requestPath = `/antraege/${this.uuid}/einrichtung/phasen/STARTPHASE`;
        break;
      case 'TRAININGSPHASE':
        this.requestPath = `/antraege/${this.uuid}/einrichtung/phasen/TRAININGSPHASE`;
        break;
    }
  },
);

Given(
  'ein Request mit dem falschen Parameter = {} für das Speichern einer Einrichtung',
  async function (this: ICustomWorld, param: string) {
    this.requestResponse = await this.requestContext?.post('/antraege/eantrag', {
      headers: {
        'Content-Type': 'application/xml',
        authorization: `Bearer ${this.accessToken}`,
      },
      data: antrag_12010156S020,
    });

    const response = await this.requestResponse?.text();
    const index = response?.indexOf('uuid') || 0;
    this.uuid = response?.substring(index + 7, index + 43) ?? '';

    switch (param) {
      case '550e8400-e29b-11d4-a716-44665544000':
        this.requestPath = `/antraege/${param}/einrichtung/phasen/STARTPHASE`;
        break;
      case 'einrichtungen':
        this.requestPath = `/antraege/${this.uuid}/${param}/phasen/STARTPHASE`;
        break;
      case 'phase':
        this.requestPath = `/antraege/${this.uuid}/einrichtung/${param}/STARTPHASE`;
        break;
      case 'STARTPHASEN':
        this.requestPath = `/antraege/${this.uuid}/einrichtung/phasen/${param}`;
        break;
      case 'TRAININGSPHASEN':
        this.requestPath = `/antraege/${this.uuid}/einrichtung/phasen/${param}`;
        break;
    }
  },
);

Given(
  'ein Request für das Speichern des Ergebnisses zur Sidepanel Anspruchsprüfung',
  async function (this: ICustomWorld) {
    this.requestResponse = await this.requestContext?.post('/antraege/eantrag', {
      headers: {
        'Content-Type': 'application/xml',
        authorization: `Bearer ${this.accessToken}`,
      },
      data: antrag_13060857P466,
    });

    const response = await this.requestResponse?.text();
    const index = response?.indexOf('uuid') || 0;
    this.uuid = response?.substring(index + 7, index + 43) ?? '';
    this.requestPath = `/antraege/${this.uuid}/pruefergebnis`;
  },
);

Given(
  'die Anspruchsprüfung-Seite für Benutzer "{}" für die generierte UUID zur VSNR = {}',
  async function (this: ICustomWorld, benutzer: string, vsnr: string) {
    let antrag;
    switch (vsnr) {
      case '15010191A388':
        antrag = antrag_sva_15010191A388;
        break;
      case '12010156S020':
        antrag = antrag_ab_12010156S020;
        break;
    }

    this.requestResponse = await this.requestContext?.post('/antraege/eantrag', {
      headers: {
        'Content-Type': 'application/xml',
        authorization: `Bearer ${this.accessToken}`,
      },
      data: antrag,
    });

    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());

    this.uuid = result['uuid'] as string;
    if (typeof this.uuid === 'string') {
      await this.anspruchspruefung?.openAnspruchspruefung(this.uuid);
    } else {
      throw new Error('UUID ist nicht definiert');
    }

    const user = usersMap['benutzer_Ktan_' + benutzer];
    // await this.keycloak?.clickOnTestUser();
    await this.keycloak?.setBenutzername(user.userName);
    await this.keycloak?.setKenntwort(user.password);
    await this.keycloak?.clickSignIn();
    return await this.anspruchspruefung?.setUUID(this.uuid);
  },
);

Given(
  'die Einrichtungsauswahl-Seite für Benutzer "{}" für die generierte UUID zur VSNR = {}',
  async function (this: ICustomWorld, benutzer: string, vsnr: string) {
    let antrag;
    switch (vsnr) {
      case '15010191A388':
        antrag = antrag_sva_15010191A388;
        break;
      case '12010156S020':
        antrag = antrag_ab_12010156S020;
        break;
    }

    this.requestResponse = await this.requestContext?.post('/antraege/eantrag', {
      headers: {
        'Content-Type': 'application/xml',
        authorization: `Bearer ${this.accessToken}`,
      },
      data: antrag,
    });

    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());

    this.uuid = result['uuid'] as string;
    if (typeof this.uuid === 'string') {
      await this.einrichtungen?.openEinrichtungen(this.uuid);
    } else {
      throw new Error('UUID ist nicht definiert');
    }

    const user = usersMap['benutzer_Ktan_' + benutzer];
    // await this.keycloak?.clickOnTestUser();
    await this.keycloak?.setBenutzername(user.userName);
    await this.keycloak?.setKenntwort(user.password);
    await this.keycloak?.clickSignIn();
    return await this.einrichtungen?.setUUID(this.uuid);
  },
);

Given(
  'die Aussteuerungseite für Versicherte mit der generierten UUID zur Versicherung Nummer = {}',
  async function (this: ICustomWorld, vsnr: string) {
    let antrag;
    switch (vsnr) {
      case '15171186R598':
        antrag = antrag_15171186R598;
        break;
      case '15011295R334':
        antrag = antrag_15011295R334;
        break;
      case '15190230P015':
        antrag = antrag_15190230P015;
        break;
      case '48210470M496':
        antrag = antrag_48210470M496;
        break;
    }

    this.requestResponse = await this.requestContext?.post('/antraege/eantrag', {
      headers: {
        'Content-Type': 'application/xml',
        authorization: `Bearer ${this.accessToken}`,
      },
      data: antrag,
    });

    const response = await this.requestResponse?.text();
    const index = response?.indexOf('uuid') || 0;
    this.uuid = response?.substring(index + 7, index + 43) ?? '';
    const user = usersMap['benutzer_Ktan_15'];
    await this.einrichtungen?.setUUID(this.uuid);
    await this.aussteurung?.openPersonendaten(this.uuid);
    // await this.keycloak?.clickOnTestUser();
    await this.keycloak?.setBenutzername(user.userName);
    await this.keycloak?.setKenntwort(user.password);
    await this.keycloak?.clickSignIn();
    await this.einrichtungen?.wait();
    await this.aussteurung?.openPersonendaten(this.uuid);
  },
);

Given(
  'die Aussteuerungseite für Versicherte mit der generierten UUID zur VSRN = {}',
  async function (this: ICustomWorld, vsnr: string) {
    let antrag;
    switch (vsnr) {
      case '48210470M496':
        antrag = antrag_48210470M496;
        break;
    }

    this.requestResponse = await this.requestContext?.post('/antraege/eantrag', {
      headers: {
        'Content-Type': 'application/xml',
        authorization: `Bearer ${this.accessToken}`,
      },
      data: antrag,
    });

    const response = await this.requestResponse?.text();
    const index = response?.indexOf('uuid') || 0;
    this.uuid = response?.substring(index + 7, index + 43) ?? '';
    const user = usersMap['benutzer_Ktan_70'];
    await this.einrichtungen?.setUUID(this.uuid);
    await this.aussteurung?.openPersonendaten(this.uuid);
    // await this.keycloak?.clickOnTestUser();
    await this.keycloak?.setBenutzername(user.userName);
    await this.keycloak?.setKenntwort(user.password);
    await this.keycloak?.clickSignIn();
    await this.einrichtungen?.wait();
    await this.aussteurung?.openPersonendaten(this.uuid);
  },
);

When(
  'ich den Request mit der VSNR = {} absende',
  async function (this: ICustomWorld, vsnr: string) {
    let antrag;
    switch (vsnr) {
      case '12010156S020':
        antrag = antrag_12010156S020;
        break;
      case '13010156S020':
        antrag = antrag_13010156S020;
        break;
      case '16010156S020':
        antrag = antrag_16010156S020;
        break;
      case '02496532A000':
        antrag = antrag_02496532A000;
        break;
      case '00168708A000':
        antrag = antrag_00168708A000;
        break;
      case '02302738A000':
        antrag = antrag_02302738A000;
        break;
      case '09586269A000':
        antrag = antrag_09586269A000;
        break;
    }
    this.requestResponse = await this.requestContext?.post(this.requestPath!, {
      headers: {
        'Content-Type': 'application/xml',
        authorization: `Bearer ${this.accessToken}`,
      },
      data: antrag,
    });

    const response = await this.requestResponse?.text();

    const index = response?.indexOf('uuid') || 0;
    this.uuid = response?.substring(index + 7, index + 43) ?? '';
  },
);

When('ich den Request für die Anspruchsprüfung absende', async function (this: ICustomWorld) {
  const options = {
    headers: {
      authorization: `Bearer ${this.accessToken}`,
    },
    json: true,
  };
  this.requestResponse = await this.requestContext?.get(
    // `/antraege/${this.uuid}/pruefergebnis`,
    '/antraege/' + this.uuid + '/pruefergebnis',
    options,
  );
});

When(
  'ich die Dokumentation das Ergebnisses in der Datenbank überprüfe',
  async function (this: ICustomWorld) {
    const options = {
      headers: {
        authorization: `Bearer ${this.accessToken}`,
      },
      json: true,
    };
    this.requestResponse = await this.requestContext?.get(`/antraege/${this.uuid}`, options);
  },
);

When('die Bescheiderstellung angestoßen wird', async function (this: ICustomWorld) {
  const response = await this.requestResponse?.text();
  const index = response?.indexOf('uuid') || 0;
  this.uuid = response?.substring(index + 7, index + 43) ?? '';

  this.requestResponse = await this.requestContext?.post(`/antraege/${this.uuid}/einrichtungen`, {
    headers: {
      authorization: `Bearer ${this.accessToken}`,
    },
    data: [
      {
        angebotId: 10216,
        durchfuehrungsart: 'ganztägig ambulant',
      },
      {
        angebotId: 17624,
        durchfuehrungsart: 'online',
      },
    ],
  });
});

When(
  'die Bescheiderstellung mit fehlerhaften Daten = {} angestoßen wird',
  async function (this: ICustomWorld, data: string) {
    const response = await this.requestResponse?.text();
    const index = response?.indexOf('uuid') || 0;
    this.uuid = response?.substring(index + 7, index + 43) ?? '';

    switch (data) {
      case '10316':
        this.requestResponse = await this.requestContext?.post(
          `/antraege/${this.uuid}/einrichtungen`,
          {
            headers: {
              authorization: `Bearer ${this.accessToken}`,
            },
            data: [
              {
                angebotId: 10316,
                durchfuehrungsart: 'ganztägig ambulant',
              },
              {
                angebotId: 17624,
                durchfuehrungsart: 'online',
              },
            ],
          },
        );
        break;
      case '3':
        this.requestResponse = await this.requestContext?.post(
          `/antraege/${this.uuid}/einrichtungen`,
          {
            headers: {
              authorization: `Bearer ${this.accessToken}`,
            },
            data: [
              {
                angebotId: 10216,
                durchfuehrungsart: 'ganztägig ambulant',
              },
              {
                angebotId: 3,
                durchfuehrungsart: 'online',
              },
            ],
          },
        );
        break;
      case 'online':
        this.requestResponse = await this.requestContext?.post(
          `/antraege/${this.uuid}/einrichtungen`,
          {
            headers: {
              authorization: `Bearer ${this.accessToken}`,
            },
            data: [
              {
                angebotId: 10216,
                durchfuehrungsart: 'online',
              },
              {
                angebotId: 17624,
                durchfuehrungsart: 'online',
              },
            ],
          },
        );
        break;
      case '3 Tage stationär':
        this.requestResponse = await this.requestContext?.post(
          `/antraege/${this.uuid}/einrichtungen`,
          {
            headers: {
              authorization: `Bearer ${this.accessToken}`,
            },
            data: [
              {
                angebotId: 10216,
                durchfuehrungsart: 'ganztägig ambulant',
              },
              {
                angebotId: 17624,
                durchfuehrungsart: '3 Tage stationär',
              },
            ],
          },
        );
        break;
    }
  },
);

When(
  'ich den Request zum Speichern für die "{}" absende',
  async function (this: ICustomWorld, phase: string) {
    switch (phase) {
      case 'STARTPHASE':
        this.requestResponse = await this.requestContext?.post(this.requestPath!, {
          headers: {
            authorization: `Bearer ${this.accessToken}`,
          },
          data: {
            angebotId: 10216,
            durchfuehrungsart: 'ganztägig ambulant',
          },
        });
        break;
      case 'TRAININGSPHASE':
        this.requestResponse = await this.requestContext?.post(this.requestPath!, {
          headers: {
            authorization: `Bearer ${this.accessToken}`,
          },
          data: {
            angebotId: 17624,
            durchfuehrungsart: 'online',
          },
        });
        break;
    }
  },
);

When(
  'ich den Request mit falschem angebotKey für die "{}" absende',
  async function (this: ICustomWorld, phase: string) {
    switch (phase) {
      case 'STARTPHASE':
        this.requestResponse = await this.requestContext?.post(this.requestPath!, {
          headers: {
            authorization: `Bearer ${this.accessToken}`,
          },
          data: [
            {
              angebotId: 2,
              durchfuehrungsart: 'ganztägig ambulant',
            },
          ],
        });
        break;
      case 'TRAININGSPHASE':
        this.requestResponse = await this.requestContext?.post(this.requestPath!, {
          headers: {
            authorization: `Bearer ${this.accessToken}`,
          },
          data: [
            {
              angebotId: 3,
              durchfuehrungsart: 'online',
            },
          ],
        });
        break;
    }
  },
);

When(
  'ich den Request mit falscher durchfuehrungsart für die "{}" absende',
  async function (this: ICustomWorld, phase: string) {
    switch (phase) {
      case 'STARTPHASE':
        this.requestResponse = await this.requestContext?.post(this.requestPath!, {
          headers: {
            authorization: `Bearer ${this.accessToken}`,
          },
          data: [
            {
              angebotId: 10216,
              durchfuehrungsart: 'online',
            },
          ],
        });
        break;
      case 'TRAININGSPHASE':
        this.requestResponse = await this.requestContext?.post(this.requestPath!, {
          headers: {
            authorization: `Bearer ${this.accessToken}`,
          },
          data: [
            {
              angebotId: 17624,
              durchfuehrungsart: '3 Tage stationär',
            },
          ],
        });
        break;
    }
  },
);

When('die "{}" angestoßen wird', async function (this: ICustomWorld, status: string) {
  this.requestPath = `/antraege/${this.uuid}/status`;
  switch (status) {
    case 'Bewilligung':
      this.requestResponse = await this.requestContext?.put(this.requestPath!, {
        headers: {
          authorization: `Bearer ${this.accessToken}`,
        },
        data: {
          status: 'BEWILLIGUNG_MANUELL',
        },
      });
      break;
    case 'Ablehnung':
      this.requestResponse = await this.requestContext?.put(this.requestPath!, {
        headers: {
          authorization: `Bearer ${this.accessToken}`,
        },
        data: {
          status: 'ABLEHNUNG_MANUELL',
        },
      });
      break;
  }
});

When(
  'die "{}" mit fehlerhaften Daten angestoßen wird',
  async function (this: ICustomWorld, status: string) {
    this.requestPath = `/antraege/${this.uuid}/status`;
    switch (status) {
      case 'Bewilligung':
        this.requestResponse = await this.requestContext?.put(this.requestPath!, {
          headers: {
            authorization: `Bearer ${this.accessToken}`,
          },
          data: {
            status: 'BEWILLIGUNG',
          },
        });
        break;
      case 'Ablehnung':
        this.requestResponse = await this.requestContext?.put(this.requestPath!, {
          headers: {
            authorization: `Bearer ${this.accessToken}`,
          },
          data: {
            status: 'ABLEHNUNG',
          },
        });
        break;
    }
  },
);

When(
  'ich den Request zum Speichern mit erfolgreichem Ergebnis zum "{}" absende',
  async function (this: ICustomWorld, ergebnis: string) {
    switch (ergebnis) {
      case 'Antrag auf Altersrente':
        this.requestResponse = await this.requestContext?.put(this.requestPath!, {
          headers: {
            authorization: `Bearer ${this.accessToken}`,
          },
          data: {
            regelName: 'ANTRAGALTERSRENTE',
            antragPruefergebnis: 'ERFUELLT',
            begruendung: 'Text',
          },
        });
        break;
      case 'Laufenden Rechtsbehelfsverfahren':
        this.requestResponse = await this.requestContext?.put(this.requestPath!, {
          headers: {
            authorization: `Bearer ${this.accessToken}`,
          },
          data: {
            regelName: 'LAUFENDERREHAANTRAG',
            antragPruefergebnis: 'NICHT_ERFUELLT_ABLEHNEN',
            begruendung: 'Text',
          },
        });
        break;
    }
  },
);

When(
  'ich den Request zum Speichern mit ungültigem Ergebnis zum "{}" absende',
  async function (this: ICustomWorld, ergebnis: string) {
    switch (ergebnis) {
      case 'Antrag auf Altersrente':
        this.requestResponse = await this.requestContext?.put(this.requestPath!, {
          headers: {
            authorization: `Bearer ${this.accessToken}`,
          },
          data: {
            regelName: 'ANTRAGALTERSRENTE',
            antragPruefergebnis: 'ERFUELT',
            begruendung: 'Text',
          },
        });
        break;
      case 'Laufenden Rechtsbehelfsverfahren':
        this.requestResponse = await this.requestContext?.put(this.requestPath!, {
          headers: {
            authorization: `Bearer ${this.accessToken}`,
          },
          data: {
            regelName: 'LAUFENDERREHAANTRAG',
            antragPruefergebnis: 'NICHT_ERFUELLT',
            begruendung: 'Text',
          },
        });
        break;
    }
  },
);

When(
  'ich den Request zum Speichern ohne Bemerkung zum "{}" absende',
  async function (this: ICustomWorld, ergebnis: string) {
    switch (ergebnis) {
      case 'Antrag auf Altersrente':
        this.requestResponse = await this.requestContext?.put(this.requestPath!, {
          headers: {
            authorization: `Bearer ${this.accessToken}`,
          },
          data: {
            regelName: 'ANTRAGALTERSRENTE',
            antragPruefergebnis: 'ERFUELLT',
            begruendung: '',
          },
        });
        break;
      case 'Laufenden Rechtsbehelfsverfahren':
        this.requestResponse = await this.requestContext?.put(this.requestPath!, {
          headers: {
            authorization: `Bearer ${this.accessToken}`,
          },
          data: {
            regelName: 'LAUFENDERREHAANTRAG',
            antragPruefergebnis: 'NICH_ERFUELLT',
            begruendung: '',
          },
        });
        break;
    }
  },
);

Then('erwarte ich eine erfolgreiche Prüfung', async function (this: ICustomWorld) {
  this.requestResponse = await this.requestContext?.get(
    '/antraege/' + this.uuid + '/pruefergebnis',
    {
      headers: {
        authorization: `Bearer ${this.accessToken}`,
      },
    },
  );
  const result = await this.requestResponse?.text();
  const expectedResult = '"ERFUELLT"';
  expect(result).toEqual(expectedResult);
});

Then('erwarte ich eine nicht erfolgreiche Prüfung', async function (this: ICustomWorld) {
  this.requestResponse = await this.requestContext?.get(
    '/antraege/' + this.uuid + '/pruefergebnis',
    {
      headers: {
        authorization: `Bearer ${this.accessToken}`,
      },
    },
  );

  const result = await this.requestResponse?.text();

  const expectedResult = '"AUSSTEUERN"';
  expect(result).toEqual(expectedResult);
});

Then('erwarte ich Aussteuerung als Ergebnis der Prüfung', async function (this: ICustomWorld) {
  this.requestResponse = await this.requestContext?.get(
    '/antraege/' + this.uuid + '/pruefergebnis',
    {
      headers: {
        authorization: `Bearer ${this.accessToken}`,
      },
    },
  );
  const result = await this.requestResponse?.text();
  const expectedResult = '"AUSSTEUERN"';
  expect(result).toContain(expectedResult);
});

Then(
  'erwarte ich dass das Ergebnis der Prüfung gespeichert ist',
  async function (this: ICustomWorld) {
    this.requestResponse = await this.requestContext?.get(
      '/antraege/' + this.uuid + '/pruefergebnis',
      {
        headers: {
          authorization: `Bearer ${this.accessToken}`,
        },
      },
    );
    const result = await this.requestResponse?.text();
    const expectedResult = '"AUSSTEUERN"';
    expect(result).toContain(expectedResult);
  },
);

Then(
  'sind alle Phasen der angegebenen Einrichtung gespeichert',
  async function (this: ICustomWorld) {
    this.requestResponse = await this.requestContext?.get(`/antraege/${this.uuid}`, {
      headers: {
        authorization: `Bearer ${this.accessToken}`,
      },
    });
    const result = await this.requestResponse?.text();
    const expectedResult = '"ergebnis":"ERFUELLT"';
    expect(result).toContain(expectedResult);
  },
);

Then('sind die Einrichtungsdaten identisch', async function (this: ICustomWorld) {
  this.requestResponse = await this.requestContext?.get(`/antraege/${this.uuid}`, {
    headers: {
      authorization: `Bearer ${this.accessToken}`,
    },
  });
  const result = await this.requestResponse?.text();
  const expectedResult =
    '"REGEL_EINRICHTUNGVORHANDENUNDIDENTISCH","begruendung":"Die Einrichtungsdaten für Startphase und die Trainingsphase sind identisch."';
  expect(result).toContain(expectedResult);
});

Then('sind für eine Phase keine Daten angegeben', async function (this: ICustomWorld) {
  this.requestResponse = await this.requestContext?.get(`/antraege/${this.uuid}/`, {
    headers: {
      authorization: `Bearer ${this.accessToken}`,
    },
  });
  const result = await this.requestResponse?.text();
  const expectedResult =
    '"REGEL_EINRICHTUNGVORHANDENUNDIDENTISCH","begruendung":"Es wurden keine Daten für die Einrichtung der Start- oder Trainingsphase angegeben."';
  expect(result).toContain(expectedResult);
});

Then('sind die Einrichtungsdaten nicht identisch', async function (this: ICustomWorld) {
  this.requestResponse = await this.requestContext?.get(`/antraege/${this.uuid}`, {
    headers: {
      authorization: `Bearer ${this.accessToken}`,
    },
  });
  const result = await this.requestResponse?.text();
  const expectedResult =
    '"REGEL_EINRICHTUNGVORHANDENUNDIDENTISCH","begruendung":"Die Einrichtungsdaten für Startphase und die Trainingsphase sind nicht identisch."';
  expect(result).toContain(expectedResult);
});

Then('sind mehrere Angebote verfügbar', async function (this: ICustomWorld) {
  this.requestResponse = await this.requestContext?.get(`/antraege/${this.uuid}`, {
    headers: {
      authorization: `Bearer ${this.accessToken}`,
    },
  });
  const result = await this.requestResponse?.text();
  const expectedResult =
    '"REGEL_EINRICHTUNGANGEBOTEINDEUTIG","begruendung":"Es gibt mehrere Angebote in der Einrichtung der Start- oder Trainingsphase."';
  expect(result).toContain(expectedResult);
});

Then(
  'erwarte ich einen erfolglosen Abruf der Einrichtungsdaten für eine Phase',
  async function (this: ICustomWorld) {
    this.requestResponse = await this.requestContext?.get(`/antraege/${this.uuid}`, {
      headers: {
        authorization: `Bearer ${this.accessToken}`,
      },
    });
    const result = await this.requestResponse?.text();
    const expectedResult =
      '"REGEL_EINRICHTUNGVORHANDENUNDIDENTISCH","begruendung":"Die Einrichtung der Start- oder Trainingsphase wurde nicht gefunden."';
    expect(result).toContain(expectedResult);
  },
);

Then('gibt es keine freien Plätze', async function (this: ICustomWorld) {
  this.requestResponse = await this.requestContext?.get(`/antraege/${this.uuid}`, {
    headers: {
      authorization: `Bearer ${this.accessToken}`,
    },
  });
  const result = await this.requestResponse?.text();
  const expectedResult =
    '"REGEL_EINRICHTUNGFREIEPLAETZE","begruendung":"Die Einrichtung der Start- oder Trainingsphase hat keine freien Plätze."';
  expect(result).toContain(expectedResult);
});

Then('erwarte ich einen erfolgreichen Anstoß', async function (this: ICustomWorld) {
  const result = await this.requestResponse?.ok();
  expect(result).toBeTruthy();
});

Then(
  'erwarte ich einen Internal Server Error beim Anstoß der Bescheiderstellung',
  async function (this: ICustomWorld) {
    const status = this.requestResponse?.status();
    let result;
    if (status == 404 || status == 500) {
      result = false;
      expect(result).toBeFalsy();
    }
  },
);

Then(
  'wird bei einem Bad Request die Fehler-Notification "{}" angezeigt',
  async function (this: ICustomWorld, error: string) {
    const statusText = await this.requestResponse?.statusText();
    const status = await this.requestResponse?.status();
    if (statusText == 'Bad Request' || status == 400) {
      expect(await this.versichertenHeader?.getErrorNotification()).toBeTruthy();
      expect(await this.versichertenHeader?.getErrorText()).toEqual(error);
    }
  },
);

Then('erhalte ich eine erfolgreiche Speicherung', async function (this: ICustomWorld) {
  const result = await this.requestResponse?.ok();
  expect(result).toBeTruthy;
});

Then('erhalte ich einen Client Error Status Code', async function (this: ICustomWorld) {
  const result = await this.requestResponse?.status();
  expect(result).toBeGreaterThan(399);
});

Then('erwarte ich einen fehlerhaften Anstoß', async function (this: ICustomWorld) {
  const status = this.requestResponse?.status();
  let result;
  if (status == 400) {
    result = false;
    expect(result).toBeFalsy();
  }
});

Then('wird Header überprüft', async function (this: ICustomWorld) {
  const securityHeader = this.requestResponse?.headers();
  expect(JSON.stringify(securityHeader)).toContain(
    '{"absender":"rvsm-2fa-43-rvfit","api_version":"3.0.3","cache-control":"no-cache, no-store, must-revalidate","content-disposition":"attachment; filename=\\"api.json\\"","content-security-policy":"default-src \'self\'","content-type":"application/json, application/json","drv_mandant":"70","feature-policy":"geolocation \'none\'; midi \'none\'; notifications \'none\'; push \'none\'; sync-xhr \'none\'; microphone \'none\'; camera \'none\'; magnetometer \'none\'; gyroscope \'none\'; speaker \'none\'; vibrate \'none\'; fullscreen \'self\'; payment \'none\';","referrer-policy":"strict-origin-when-cross-origin","strict-transport-security":"max-age=31536000; includeSubDomains","x-content-type-options":"nosniff"',
  );
});
