import { ICustomWorld } from '../support/custom-world';
import { getClientID, getClientSecret, getKeycloakUrl } from '../support/config';
import { usersMap } from '../support/users';
import { Given, When } from '@cucumber/cucumber';

Given(
  'die Sachbearbeitung hat die Berechtigung auf die Ressource zuzugreifen',
  async function (this: ICustomWorld) {
    const params = new URLSearchParams();
    const user = usersMap['benutzer_Ktan_70'];
    params.append('client_id', getClientID());
    params.append('grant_type', 'password');
    params.append('client_secret', getClientSecret());
    params.append('username', user.userName);
    params.append('password', user.password);
    const response = await fetch(getKeycloakUrl(), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: params,
    });

    const data = await response.json();
    this.accessToken = data.access_token;
    await this.antragaufnahme?.openAntragaufnahme();
    // await this.keycloak?.clickOnTestUser();
    await this.keycloak?.setBenutzername(user.userName);
    await this.keycloak?.setKenntwort(user.password);
    await this.keycloak?.clickSignIn();
    await this.page?.waitForTimeout(1000);
  },
);

Given(
  'die Sachbearbeitung hat die Berechtigung für 70, um auf die Ressource zuzugreifen',
  async function (this: ICustomWorld) {
    const params = new URLSearchParams();
    const user = usersMap['benutzer_Ktan_70'];
    params.append('client_id', getClientID());
    params.append('grant_type', 'password');
    params.append('client_secret', getClientSecret());
    params.append('username', user.userName);
    params.append('password', user.password);
    const response = await fetch(getKeycloakUrl(), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: params,
    });

    const data = await response.json();
    this.accessToken = data.access_token;
  },
);

Given(
  'die Sachbearbeitung hat die Berechtigung für 15, um auf die Ressource zuzugreifen',
  async function (this: ICustomWorld) {
    const params = new URLSearchParams();
    const user = usersMap['benutzer_Ktan_15'];
    params.append('client_id', getClientID());
    params.append('grant_type', 'password');
    params.append('client_secret', getClientSecret());
    params.append('username', user.userName);
    params.append('password', user.password);
    const response = await fetch(getKeycloakUrl(), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: params,
    });

    const data = await response.json();
    this.accessToken = data.access_token;
  },
);

Given(
  'die Sachbearbeitung greift mit dem Benutzer "{}" auf die Ressource zu',
  async function (this: ICustomWorld, benutzer: string) {
    const params = new URLSearchParams();
    const user = usersMap['benutzer_Ktan_' + benutzer];
    params.append('client_id', getClientID());
    params.append('grant_type', 'password');
    params.append('client_secret', getClientSecret());
    params.append('username', user.userName);
    params.append('password', user.password);
    const response = await fetch(getKeycloakUrl(), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: params,
    });

    const data = await response.json();
    this.accessToken = data.access_token;
  },
);

When('ich den Request absende', async function (this: ICustomWorld) {
  this.requestResponse = await this.requestContext?.get(this.requestPath!, {
    headers: {
      authorization: `Bearer ${this.accessToken}`,
    },
  });
});

When(
  'der Request für die Personendaten der entsprechenden Versicherungsnummer {} abgesendet wird',
  async function (this: ICustomWorld, vsnr: string) {
    const path = '/stammdaten/' + vsnr;
    const options = {
      headers: {
        authorization: `Bearer ${this.accessToken}`,
      },
      json: true,
    };
    try {
      this.requestResponse = await this.requestContext?.get(path, options);
    } catch (error) {
      console.error('Fehler bei der API-GET-Anfrage:', error);
      throw error;
    }
  },
);

When(
  'der Request für die Entwurfsdaten der entsprechenden Versicherungsnummer {} abgesendet wird',
  async function (this: ICustomWorld, vsnr: string) {
    const path = '/papierantraege/entwurf/' + vsnr;
    const options = {
      headers: {
        authorization: `Bearer ${this.accessToken}`,
      },
      json: true,
    };
    try {
      this.requestResponse = await this.requestContext?.get(path, options);
    } catch (error) {
      console.error('Fehler bei der API-GET-Anfrage:', error);
      throw error;
    }
  },
);
