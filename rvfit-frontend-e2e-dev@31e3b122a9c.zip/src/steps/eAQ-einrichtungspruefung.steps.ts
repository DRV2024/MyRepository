import { Sachverhaltsaufklaerung } from '../pages/sachverhaltaufklaerung';
import { ICustomWorld } from '../support/custom-world';
import { usersMap } from '../support/users';
import { Given, Then, When } from '@cucumber/cucumber';

import { expect } from '@playwright/test';

Given(
  'die Einrichtungen-Seite für Versicherte mit der UUID = {}',
  async function (this: ICustomWorld, uuid: string) {
    const user = usersMap['benutzer_Ktan_70'];
    await this.einrichtungen?.openEinrichtungen(uuid);
    await this.keycloak?.setBenutzername(user.userName);
    await this.keycloak?.setKenntwort(user.password);
    await this.keycloak?.clickSignIn();
  },
);

When(
  'die Sachbearbeitung die Änderungsansicht für die Startphase öffnet',
  async function (this: ICustomWorld) {
    await this.einrichtungen?.einrichtungAendernStart();
  },
);

When(
  'die Sachbearbeitung die Änderungsansicht für die Trainingsphase öffnet',
  async function (this: ICustomWorld) {
    await this.einrichtungen?.einrichtungAendernTraining();
  },
);

When(
  'die Sachbearbeitung zum ersten mal eine Einrichtung für die Trainingsphase auswaehlt',
  async function (this: ICustomWorld) {
    await this.einrichtungen?.einrichtungAuswaehlenTraining();
  },
);
When(
  'die Sachbearbeitung die Änderungsansicht für die Startphase wieder schließt',
  async function (this: ICustomWorld) {
    await this.einrichtungen?.closeStart();
  },
);

When(
  'die Sachbearbeitung die Änderungsansicht für die Trainingsphase wieder schließt',
  async function (this: ICustomWorld) {
    await this.einrichtungen?.closeTraining();
  },
);

When(
  'die Sachbearbeitung den Suchbegriff "{}" für die Startphase eingibt',
  async function (this: ICustomWorld, plz: string) {
    await this.einrichtungen?.setSuchbegriffStart(plz);
  },
);

When(
  'die Sachbearbeitung die Suche für die Startphase startet',
  async function (this: ICustomWorld) {
    await this.einrichtungen?.sidePanelSearchStart();
  },
);

When('die Sachbearbeitung die Suche mit Enter startet', async function (this: ICustomWorld) {
  await this.einrichtungen?.sidePanelSearchEnter();
});

When(
  'die Sachbearbeitung die vorbelegte Postleitzahl für die Startphase entfernt',
  async function (this: ICustomWorld) {
    await this.einrichtungen?.deletePostleitzahlStart();
  },
);

When(
  'die Sachbearbeitung die vorbelegte Postleitzahl für die Trainingsphase entfernt',
  async function (this: ICustomWorld) {
    await this.einrichtungen?.deletePostleitzahlTraining();
  },
);

When(
  'die Sachbearbeitung den Suchbegriff "{}" für die Trainingsphase eingibt',
  async function (this: ICustomWorld, plz: string) {
    await this.einrichtungen?.setSuchbegriffTraining(plz);
  },
);

When(
  'die Sachbearbeitung die Suche für die Trainingsphase startet',
  async function (this: ICustomWorld) {
    await this.einrichtungen?.sidePanelSearchTraining();
  },
);

When(
  'die Sachbearbeitung "{}" für die Startphase auswählt',
  async function (this: ICustomWorld, einrichtung: string) {
    await this.einrichtungen?.sidePanelAuswahlStart(einrichtung);
  },
);

When(
  'die Sachbearbeitung die Durchführungsart 3 Tage stationär für die Startphase auswählt',
  async function (this: ICustomWorld) {
    await this.einrichtungen?.sidePanelAuswahlDurchfuehrungsartStart();
  },
);

When(
  'die Sachbearbeitung "{}" für die Trainingsphase auswählt',
  async function (this: ICustomWorld, einrichtung: string) {
    await this.einrichtungen?.sidePanelAuswahlTraining(einrichtung);
  },
);

When(
  'die "{}" Adresse für die Startphase eingetragen ist',
  async function (this: ICustomWorld, einrichtung: string) {
    expect(await this.einrichtungen?.getEinrichtungStartphaseAdresse()).toContain(einrichtung);
  },
);

When(
  'eine angegebene Einrichtung für die Startphase nicht angezeigt wird',
  async function (this: ICustomWorld) {
    expect(await this.einrichtungen?.getPhase1()).toEqual('-');
  },
);

When(
  'eine angegebene Einrichtung für die Trainingsphase nicht angezeigt wird',
  async function (this: ICustomWorld) {
    expect(await this.einrichtungen?.getPhase2()).toEqual('-');
  },
);

When(
  'die Einrichtung für die Startphase nicht eingetragen wurde',
  async function (this: ICustomWorld) {
    expect(await this.einrichtungen?.getEinrichtungStartphaseAdresse()).toEqual('');
  },
);

When(
  'die Einrichtung für die Trainingsphase nicht eingetragen wurde',
  async function (this: ICustomWorld) {
    expect(await this.einrichtungen?.getEinrichtungTrainingphaseAdresse()).toEqual('');
  },
);

When('alle Einrichtungen eingetragen wurden', async function (this: ICustomWorld) {
  expect(await this.einrichtungen?.getEinrichtungStartphaseAdresse()).toEqual(
    'ZAR Wilhelmsplatz, Wilhelmsplatz 11, 70182 Stuttgart',
  );
  expect(await this.einrichtungen?.getEinrichtungTrainingphaseAdresse()).toEqual(
    'ZAR im Mineralbad Bad Cannstatt, Sulzerrainstr. 2, 70372 Stuttgart',
  );
});

When(
  'die Sachbearbeitung die Adresse für die Startphase auf "{}" ändert',
  async function (this: ICustomWorld, einrichtung: string) {
    await this.einrichtungen?.einrichtungAendernStart();
    await this.einrichtungen?.deletePostleitzahlStart();
    await this.einrichtungen?.setSuchbegriffStart('70469');
    await this.einrichtungen?.sidePanelSearchStart();
    await this.einrichtungen?.sidePanelAuswahlStart(einrichtung);
  },
);

When(
  'die Sachbearbeitung die Adresse für die Trainingsphase auf "{}" ändert',
  async function (this: ICustomWorld, einrichtung: string) {
    await this.einrichtungen?.einrichtungAendernTraining();
    await this.einrichtungen?.deletePostleitzahlTraining();
    await this.einrichtungen?.setSuchbegriffTraining('70469');
    await this.einrichtungen?.sidePanelSearchTraining();
    await this.einrichtungen?.sidePanelAuswahlTraining(einrichtung);
  },
);

When('die Einrichtung für die Trainingsphase übernimmt', async function (this: ICustomWorld) {
  await this.einrichtungen?.sidePanelUebernehmenTraining();
});

When('die Sachbearbeitung einen Sachverhalt abgeruft', async function (this: ICustomWorld) {
  await this.einrichtungen?.clickSachverhalt();
});

When(
  'die Sachbearbeitung auf der Einrichtungsauswahl-Seite Antrag bewilligen klickt',
  async function (this: ICustomWorld) {
    //await this.page?.waitForTimeout(2000);
    await this.einrichtungen?.clickOnAntragBewilligen();
  },
);

When(
  'die Sachbearbeitung auf der Einrichtungsauswahl-Seite auf Sachverhalt aufklären klickt',
  async function (this: ICustomWorld) {
    const pagePromise = this.page?.waitForEvent('popup');
    await this.einrichtungen?.clickOnSachverhaltAufklaeren();
    const page2 = await pagePromise;
    this.sachverhaltsaufklaerung = new Sachverhaltsaufklaerung(page2!);
  },
);

Then('ist die Änderungsansicht für die Startphase sichtbar', async function (this: ICustomWorld) {
  expect(await this.einrichtungen?.isSidepanel()).toBeTruthy;
});

Then(
  'ist die Änderungsansicht für die Trainingsphase sichtbar',
  async function (this: ICustomWorld) {
    expect(await this.einrichtungen?.isSidepanelTraining()).toBeTruthy;
  },
);

Then('ist die Änderungsansicht nicht sichtbar', async function (this: ICustomWorld) {
  expect(await this.einrichtungen?.isSite).toBeTruthy;
});

Then(
  'wird der Hinweis "{}" für die Startphase angezeigt',
  async function (this: ICustomWorld, einrichtung: string) {
    expect(await this.einrichtungen?.getHinweisEinrichtung()).toEqual(einrichtung);
  },
);

Then(
  'ist die Postleitzahl mit "{}" für die Startphase vorbelegt',
  async function (this: ICustomWorld, plz: string) {
    expect(await this.einrichtungen?.getSidepanelStartPostleitzahl()).toEqual(plz);
  },
);

Then(
  'wird der Platzhalter im Suchfeld "{}" für die Startphase angezeigt',
  async function (this: ICustomWorld, hinweis: string) {
    expect(await this.einrichtungen?.getSidepanelStartPlaceholder()).toEqual(hinweis);
  },
);

Then(
  'werden "{}" Ergebnisse im Umkreis von 50 km für die Startphase angezeigt',
  async function (this: ICustomWorld, result: string) {
    await this.einrichtungen?.wait();
    expect(await this.einrichtungen?.getSidepanelStartErgebnisse()).toContain(result);
    expect(await this.einrichtungen?.getSidepanelStartErgebnisseListe()).toEqual(result);
  },
);

Then(
  'wird der Einrichtungsname "{}" für die Startphase angezeigt',
  async function (this: ICustomWorld, name: string) {
    expect(await this.einrichtungen?.getSidepanelStartEinrichtung()).toEqual(name);
  },
);

Then(
  'wird die Adresse "{}" für die Startphase angezeigt',
  async function (this: ICustomWorld, adresse: string) {
    expect(await this.einrichtungen?.getSidepanelStartAdresse()).toContain(adresse);
  },
);

Then(
  'werden die Angebotene Phasen "{}" für die Startphase angezeigt',
  async function (this: ICustomWorld, phase: string) {
    expect(await this.einrichtungen?.getSidepanelStartPhase()).toEqual(phase);
  },
);

Then(
  'wird die Durchführungsart der Startphase "{}" angezeigt',
  async function (this: ICustomWorld, dauer: string) {
    expect(await this.einrichtungen?.getSidepanelStartDauer()).toEqual(dauer);
  },
);

Then(
  'ist 3 Tage stationär als Durchführungsart der Startphase ausgewählt',
  async function (this: ICustomWorld) {
    expect(await this.einrichtungen?.getSidepanelStartDauerDrop()).toEqual(
      '3 Tage ganztägig ambulant',
    );
  },
);

Then(
  'werden die freien Plätze "{}" für die Startphase angezeigt',
  async function (this: ICustomWorld, platz: string) {
    expect(await this.einrichtungen?.getSidepanelStartPlatz()).toEqual(platz);
  },
);

Then(
  'ist die Einrichtung "{}" für die Startphase ausgewählt',
  async function (this: ICustomWorld, einrichtung: string) {
    expect(await this.einrichtungen?.sidePanelAusgewaehltStart(einrichtung)).toBeTruthy;
  },
);

Then(
  'werden keine Einrichtungen mit dem Hinweis "{}" für die Startphase angezeigt',
  async function (this: ICustomWorld, hinweis: string) {
    expect(await this.einrichtungen?.getSidepanelStartErgebnisse()).toEqual(hinweis);
  },
);

Then('ist eine Übernahme für die Startphase nicht möglich', async function (this: ICustomWorld) {
  expect(await this.einrichtungen?.sidePanelDisabledUebernehmenStart()).toBeTruthy();
});

Then(
  'ist eine Übernahme für die Trainingsphase nicht möglich',
  async function (this: ICustomWorld) {
    expect(await this.einrichtungen?.sidePanelDisabledUebernehmenTraining()).toBeTruthy();
  },
);

Then(
  'wird der Hinweis "{}" für die Trainingsphase angezeigt',
  async function (this: ICustomWorld, einrichtung: string) {
    expect(await this.einrichtungen?.getHinweisTrainingEinrichtung()).toEqual(einrichtung);
  },
);

Then(
  'ist die Postleitzahl mit "{}" für die Trainingsphase vorbelegt',
  async function (this: ICustomWorld, plz: string) {
    expect(await this.einrichtungen?.getSidepanelTrainingPostleitzahl()).toEqual(plz);
  },
);

Then(
  'wird der Platzhalter im Suchfeld "{}" für die Trainingsphase angezeigt',
  async function (this: ICustomWorld, hinweis: string) {
    expect(await this.einrichtungen?.getSidepanelTrainingPlaceholder()).toEqual(hinweis);
  },
);

Then(
  'werden "{}" Ergebnisse im Umkreis von 50 km für die Trainingsphase angezeigt',
  async function (this: ICustomWorld, result: string) {
    await this.einrichtungen?.wait();
    expect(await this.einrichtungen?.getSidepanelTrainingErgebnisse()).toContain(result);
    expect(await this.einrichtungen?.getSidepanelTrainingErgebnisseListe()).toEqual(result);
  },
);

Then(
  'wird der Einrichtungsname "{}" für die Trainingsphase angezeigt',
  async function (this: ICustomWorld, name: string) {
    expect(await this.einrichtungen?.getSidepanelTrainingEinrichtung()).toEqual(name);
  },
);

Then(
  'wird die Adresse "{}" für die Trainingsphase angezeigt',
  async function (this: ICustomWorld, adresse: string) {
    expect(await this.einrichtungen?.getSidepanelTrainingAdresse()).toContain(adresse);
  },
);

Then(
  'werden die Angebotene Phasen "{}" für die Trainingsphase angezeigt',
  async function (this: ICustomWorld, phase: string) {
    expect(await this.einrichtungen?.getSidepanelTrainingPhase()).toEqual(phase);
  },
);

Then(
  'wird die Durchführungsart der Trainingsphase "{}" angezeigt',
  async function (this: ICustomWorld, dauer: string) {
    expect(await this.einrichtungen?.getSidepanelTrainingDauer()).toEqual(dauer);
  },
);

Then(
  'werden die freien Plätze "{}" für die Trainingsphase angezeigt',
  async function (this: ICustomWorld, platz: string) {
    expect(await this.einrichtungen?.getSidepanelTrainingPlatz()).toEqual(platz);
  },
);

Then(
  'ist die Einrichtung "{}" für die Trainingsphase ausgewählt',
  async function (this: ICustomWorld, einrichtung: string) {
    expect(await this.einrichtungen?.sidePanelAusgewaehltTraining(einrichtung)).toBeTruthy;
  },
);

Then(
  'werden Online-Angeboten beginnend mit der Einrichtung aus der Startphase angezeigt',
  async function (this: ICustomWorld) {
    await this.einrichtungen?.wait();
    expect(await this.einrichtungen?.getSidepanelTrainingOnlineAngebot()).toEqual('Online');
    expect(await this.einrichtungen?.getEinrichtungStartphaseAdresse()).toContain(
      await this.einrichtungen?.getSidepanelTrainingEinrichtung(),
    );
  },
);

Then(
  'ist das erste Online-Angebot für die Trainingsphase ausgewählt',
  async function (this: ICustomWorld) {
    expect(await this.einrichtungen?.sidePanelAusgewaehltTrainingOnline()).toBeTruthy;
  },
);

Then(
  'werden keine Einrichtungen mit dem Hinweis "{}" für die Trainingsphase angezeigt',
  async function (this: ICustomWorld, hinweis: string) {
    expect(await this.einrichtungen?.getSidepanelTrainingErgebnisse()).toEqual(hinweis);
  },
);

Then('kann die Sachbearbeitung keinen Bescheid erstellen', async function (this: ICustomWorld) {
  expect(await this.einrichtungen?.bescheidNichtAktiv()).toBeTruthy;
});

Then('kann die Sachbearbeitung einen Bescheid erstellen', async function (this: ICustomWorld) {
  expect(await this.einrichtungen?.bescheidAktiv()).toBeTruthy;
});

Then(
  'wird der Hinweis zur Auswahl "{}" für die Startphase angezeigt',
  async function (this: ICustomWorld, hinweis: string) {
    expect(await this.einrichtungen?.getHinweisAuswahlStart()).toEqual(hinweis);
  },
);

Then(
  'wird der Hinweis zur Auswahl "{}" für die Trainingsphase angezeigt',
  async function (this: ICustomWorld, hinweis: string) {
    expect(await this.einrichtungen?.getHinweisAuswahltraining()).toEqual(hinweis);
  },
);

Then('wird der Hinweis "{}" angezeigt', async function (this: ICustomWorld, hinweis: string) {
  expect(await this.einrichtungen?.getHinweisAuswahlAuffrischung()).toEqual(hinweis);
});

Then(
  'wird der Sachbearbeiter aufgefordert eine Einrichtung für die Startphase auszuwählen',
  async function (this: ICustomWorld) {
    expect(await this.einrichtungen?.buttonAuswahlStart()).toEqual('Einrichtung auswählen');
  },
);

Then(
  'wird der Sachbearbeiter aufgefordert eine Einrichtung für die Trainingsphase auszuwählen',
  async function (this: ICustomWorld) {
    expect(await this.einrichtungen?.buttonAuswahlTraining()).toEqual('Einrichtung auswählen');
  },
);

Then('kann ein Sachverhalt abgerufen werden', async function (this: ICustomWorld) {
  expect(await this.einrichtungen?.visibleSachverhalt());
});

Then('öffnet sich der Sachverhalt', async function (this: ICustomWorld) {
  expect(await this.einrichtungen?.isSachverhaltAnsicht()).toEqual('');
});

Then(
  'lautet die Adresse für die Startphase "{}"',
  async function (this: ICustomWorld, adresse: string) {
    await this.einrichtungen?.wait();
    expect(await this.einrichtungen?.getEinrichtungStartphaseAdresse()).toContain(adresse);
  },
);

Then(
  'lautet die Adresse für die Trainingsphase "{}"',
  async function (this: ICustomWorld, adresse: string) {
    await this.einrichtungen?.wait();
    expect(await this.einrichtungen?.getEinrichtungTrainingphaseAdresse()).toContain(adresse);
  },
);

Then(
  'lautet die Adresse für die Auffrischungsphase "{}"',
  async function (this: ICustomWorld, adresse: string) {
    await this.einrichtungen?.wait();
    expect(await this.einrichtungen?.getEinrichtungAuffrischungsAdresse()).toContain(adresse);
  },
);

Then('wird der Block zu den Antragsdaten angezeigt', async function (this: ICustomWorld) {
  expect(await this.einrichtungen?.checkInformationsspalte()).toEqual('Informationen zum Antrag');
});

Then(
  'wird die dem Antrag entsprechende Antragsart = {} zur versicherten Person angezeigt',
  async function (this: ICustomWorld, antragsart: string) {
    await this.einrichtungen?.wait();
    expect(await this.einrichtungen?.getAntragsart()).toEqual(antragsart);
  },
);

Then(
  'wird die dem Antrag entsprechende Eingangsdatum = {} zur versicherten Person angezeigt',
  async function (this: ICustomWorld, datum: string) {
    await this.einrichtungen?.wait();
    expect(await this.einrichtungen?.getDatum()).toEqual(datum);
  },
);

Then(
  'wird die dem Antrag entsprechende Bemerkungen = {} zur versicherten Person angezeigt',
  async function (this: ICustomWorld, bemerkung: string) {
    await this.einrichtungen?.wait();
    expect(await this.einrichtungen?.getBemerkung()).toEqual(bemerkung);
  },
);

Then(
  'wird die dem Antrag entsprechende Einrichtung zur Start- und Auffrischungssphase = {} zur versicherten Person angezeigt',
  async function (this: ICustomWorld, phase1: string) {
    expect(await this.einrichtungen?.getPhase1()).toEqual(phase1);
  },
);

Then(
  'wird die dem Antrag entsprechende Einrichtung zur Trainingsphase = {} zur versicherten Person angezeigt',
  async function (this: ICustomWorld, phase2: string) {
    expect(await this.einrichtungen?.getPhase2()).toEqual(phase2);
  },
);

Then(
  'wird der entsprechende Aussteuerungsgrund = {} zur versicherten Person angezeigt',
  async function (this: ICustomWorld, grund: string) {
    expect(await this.einrichtungen?.isGrund(grund)).toEqual(grund);
  },
);

Then(
  'wird im Einrichtungen-Block die Überschrift "{}" angezeigt',
  async function (this: ICustomWorld, text: string) {
    expect(await this.einrichtungen?.getEinrichtungenAuswählenText()).toEqual(text);
  },
);

Then(
  'wird im Einrichtungen-Block der Text "{}" angezeigt',
  async function (this: ICustomWorld, text: string) {
    expect(await this.einrichtungen?.getEinrichtungenAllePhasenText()).toEqual(text);
  },
);

Then('werden alle 3 Phasen angezeigt', async function (this: ICustomWorld) {
  expect(await this.einrichtungen?.getEinrichtungStartphase()).toEqual('Startphase');
  expect(await this.einrichtungen?.getEinrichtungTrainingsphase()).toEqual('Trainingsphase');
  expect(await this.einrichtungen?.getEinrichtungAuffrischungsphase()).toEqual(
    'Auffrischungsphase',
  );
});

Then(
  'wird der Startphasen Einrichtungsname Text "{}" angezeigt',
  async function (this: ICustomWorld, text: string) {
    expect(await this.einrichtungen?.getEinrichtungStartphaseAdresse()).toContain(text);
  },
);

Then(
  'wird die StartPhasen Adresse Text "{}" angezeigt',
  async function (this: ICustomWorld, text: string) {
    expect(await this.einrichtungen?.getEinrichtungStartphaseAdresse()).toContain(text);
  },
);

Then(
  'wird die Startphasen Durchführungsdauer Text "{}" angezeigt',
  async function (this: ICustomWorld, text: string) {
    expect(await this.einrichtungen?.getEintragungStartphaseAmbulanteText()).toContain(text);
  },
);

Then(
  'wird der Startphasen freie Plätze Text "{}" angezeigt',
  async function (this: ICustomWorld, text: string) {
    expect(await this.einrichtungen?.getEintragungStartphasefreiePlätze()).toContain(text);
  },
);

Then(
  'wird der Trainingsphasen Einrichtungsname Text "{}" angezeigt',
  async function (this: ICustomWorld, text: string) {
    expect(await this.einrichtungen?.getEinrichtungTrainingphaseAdresse()).toContain(text);
  },
);

Then(
  'wird die Trainingsphasen Adresse Text "{}" angezeigt',
  async function (this: ICustomWorld, text: string) {
    expect(await this.einrichtungen?.getEinrichtungTrainingphaseAdresse()).toContain(text);
  },
);

Then(
  'wird die Trainingsphasen Durchführungsdauer "{}" angezeigt',
  async function (this: ICustomWorld, text: string) {
    expect(await this.einrichtungen?.getEintragungTrainingPhasenAmbulanteText()).toContain(text);
  },
);

Then(
  'wird der Trainingsphasen freie Plätze Text "{}" angezeigt',
  async function (this: ICustomWorld, text: string) {
    expect(await this.einrichtungen?.getEintragungTrainingPhasenfreiePlätze()).toContain(text);
  },
);

Then(
  'wird der Auffrischungsphasen Einrichtungsname Text "{}" angezeigt',
  async function (this: ICustomWorld, text: string) {
    expect(await this.einrichtungen?.getEinrichtungAuffrischungsAdresse()).toContain(text);
  },
);

Then(
  'wird die Auffrischungsphasen Adresse Text "{}" angezeigt',
  async function (this: ICustomWorld, text: string) {
    expect(await this.einrichtungen?.getEinrichtungAuffrischungsAdresse()).toContain(text);
  },
);

Then(
  'wird die Auffrischungsphasen Durchführungsdauer "{}" angezeigt',
  async function (this: ICustomWorld, text: string) {
    expect(await this.einrichtungen?.getEinrichtungAuffrischungsAmbulanteText()).toContain(text);
  },
);

Then(
  'wird der Auffrischungsphasen freie Plätze Text "{}" angezeigt',
  async function (this: ICustomWorld, text: string) {
    expect(await this.einrichtungen?.getEinrichtungAuffrischungfreiePlätze()).toContain(text);
  },
);

Then('wird das Startphasen Standortsymbol angezeigt', async function (this: ICustomWorld) {
  expect(await this.einrichtungen?.getEinrichtungStartphasenStandortSymbol()).toBeTruthy();
});

Then('wird das Startphasen Uhrsymbol angezeigt', async function (this: ICustomWorld) {
  expect(await this.einrichtungen?.getEinrichtungStartphasenUhrSymbol()).toBeTruthy();
});

Then('wird das Trainingsphasen Standortsymbol angezeigt', async function (this: ICustomWorld) {
  expect(await this.einrichtungen?.getEinrichtungTrainingphaseUhrSymbol()).toBeTruthy();
});

Then('wird das Trainingsphasen Uhrsymbol angezeigt', async function (this: ICustomWorld) {
  expect(await this.einrichtungen?.getEinrichtungTrainingphaseUhrSymbol()).toBeTruthy();
});

Then('wird das Auffrischungsphasen Standortsymbol angezeigt', async function (this: ICustomWorld) {
  expect(await this.einrichtungen?.getEinrichtungAuffrischungsphaseStandortSymbol()).toBeTruthy();
});

Then('wird das Auffrischungsphasen Uhrsymbol angezeigt', async function (this: ICustomWorld) {
  expect(await this.einrichtungen?.getEinrichtungAuffrischungsphaseUhrSymbol()).toBeTruthy();
});

Then(
  'wird nach der Einrichtungsauswahl-Seite der Hinweis auf eine erfolgreiche Bewilligung des Antrags angezeigt',
  async function (this: ICustomWorld) {
    expect(await this.einrichtungen?.istAntragBewilligt()).toBeTruthy();
  },
);

Then(
  'wird nach der Einrichtungsauswahl-Seite die Statusmeldung für die fehlerhafte Weiterverarbeitung der Antragsbewillingung angezeigt',
  async function (this: ICustomWorld) {
    //await this.page?.waitForTimeout(2000);
    expect(await this.einrichtungen?.istAntragBewilligtTechFehler()).toBeTruthy();
  },
);

Then('ist der Antrag bewilligen Button aktiv', async function (this: ICustomWorld) {
  expect(await this.einrichtungen?.istAntragBewilligtAktiv()).toBeTruthy();
});

Then(
  'wird unterhalb der Startphase angezeigt {}',
  async function (this: ICustomWorld, errorTextStartphase: string) {
    expect(await this.einrichtungen?.geteinrichtungStartphasefehlendeAuswahlText()).toEqual(
      errorTextStartphase,
    );
  },
);

Then(
  'wird unterhalb der Trainingsphase angezeigt {}',
  async function (this: ICustomWorld, errorTextTrainingsphase: string) {
    expect(await this.einrichtungen?.geteinrichtungTrainingphasefehlendeAuswahlText()).toEqual(
      errorTextTrainingsphase,
    );
  },
);

Then(
  'wird unterhalb der Startphase keine fehlende Auswahl Fehlermeldung angezeigt',
  async function (this: ICustomWorld) {
    // expect(await this.einrichtungen?.geteinrichtungStartphasefehlendeAuswahlVisible()).toBeFalsy();
    await expect(this.einrichtungen!.einrichtungStartphasefehlendeAuswahlText).toBeHidden();
  },
);

Then(
  'wird unterhalb der Trainingsphase keine fehlende Auswahl Fehlermeldung angezeigt',
  async function (this: ICustomWorld) {
    await expect(this.einrichtungen!.einrichtungTrainingphasefehlendeAuswahlText).toBeHidden();
  },
);

Then('wird eine bekammte Meldung angezeigt', async function (this: ICustomWorld) {
  expect(await this.versichertenHeader?.getErrorNotification()).toBeTruthy;
});

Then(
  'wird das neue Tab mit rvText neben der Einrichtungsauswahl-Seite angezeigt',
  async function (this: ICustomWorld) {
    await expect(this.sachverhaltsaufklaerung!.paperboycomponent).toBeVisible({
      timeout: 10000,
    });
  },
);

Then('die Einrichtung für die Startphase übernimmt', async function (this: ICustomWorld) {
  await this.einrichtungen?.clickOnStartPhase();
});

Then(
  'die Sachbearbeitung zum ersten mal eine Einrichtung für die Startphase auswaehlt',
  async function (this: ICustomWorld) {
    //TODO: Sobald Einrichtungssuche wieder funktioniert
  },
);
