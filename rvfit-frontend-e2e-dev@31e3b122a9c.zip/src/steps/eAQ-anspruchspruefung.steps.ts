import { Sachverhaltsaufklaerung } from '../pages/sachverhaltaufklaerung';
import { ICustomWorld } from '../support/custom-world';
import { getFrontendUrl } from '../support/environments';
import { usersMap } from '../support/users';
import { Given, Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { format } from 'date-fns';

Given(
  'die Anspruchsprüfung-Seite für Versicherte mit der UUID = {}',
  async function (this: ICustomWorld, uuid: string) {
    const user = usersMap['benutzer_Ktan_70'];
    await this.einrichtungen?.openEinrichtungen(uuid);
    await this.keycloak?.setBenutzername(user.userName);
    await this.keycloak?.setKenntwort(user.password);
    await this.keycloak?.clickSignIn();
  },
);

When('die Sachbearbeitung mit Weiter navigiert', async function (this: ICustomWorld) {
  await this.anspruchspruefung?.clickButton();
});

When(
  'die Sachbearbeitung weiter zur Einrichtungsauswahl navigiert',
  async function (this: ICustomWorld) {
    await this.anspruchspruefung?.clickButton();
  },
);

When(
  'die Änderungsansicht von der Sachbearbeitung für die {} unter nicht erfüllt öffnet',
  async function (this: ICustomWorld, regel: string) {
    await this.anspruchspruefung?.openSidepanelNichtErfüllt(regel);
  },
);

When(
  'die Sachbearbeitung die Änderungsansicht für {} unter nicht ermittelbar öffnet',
  async function (this: ICustomWorld, regel: string) {
    await this.anspruchspruefung?.openSidepanelNichtErmittelbar(regel);
  },
);

When(
  'die Sachbearbeitung die Änderungsansicht für "{}" öffnet',
  async function (this: ICustomWorld, regel: string) {
    await this.anspruchspruefung?.openSidepanelEdit(regel);
  },
);

When(
  'die Sachbearbeitung die Änderungsansicht in "{}" öffnet',
  async function (this: ICustomWorld, regel: string) {
    await this.anspruchspruefung?.openSidepanelNichtErmittelbar(regel);
  },
);

When(
  'die Sachbearbeitung die Änderungsansicht für nicht erfüllt wieder schließt',
  async function (this: ICustomWorld) {
    await this.anspruchspruefung?.closeSidepanelNichtErfüllt();
  },
);

When(
  'die Sachbearbeitung die Änderungsansicht für nicht ermittelbar wieder schließt',
  async function (this: ICustomWorld) {
    await this.anspruchspruefung?.closeSidepanelNichtErmittelbar();
  },
);

When('die Sachbearbeitung Nicht erfüllt auswählt', async function (this: ICustomWorld) {
  await this.anspruchspruefung?.setRadioNichtErfülltCheck();
});

When(
  'die Sachbearbeitung als Begründung "{}" eingibt',
  async function (this: ICustomWorld, grund: string) {
    await this.anspruchspruefung?.setBegruedung(grund);
  },
);

When('die Sachbearbeitung keine Begründung einträgt', async function (this: ICustomWorld) {
  await this.anspruchspruefung?.setBegruedung('');
});

When(
  'die Sachbearbeitung das Ergebnis auf Erfüllt für "{}" ändert',
  async function (this: ICustomWorld, auswahl: string) {
    await this.anspruchspruefung?.openSidepanel(auswahl);
    await this.anspruchspruefung?.setRadioErfülltCheck();
  },
);

When(
  'die Sachbearbeitung das Ergebnis auf Nicht Erfüllt für "{}" ändert',
  async function (this: ICustomWorld, auswahl: string) {
    await this.anspruchspruefung?.openSidepanelNichtErmittelbar(auswahl);
    await this.anspruchspruefung?.setRadioNichtErfülltCheck();
  },
);

When(
  'die Sachbearbeitung das Ergebnis in Nicht Erfüllt für "{}" ändert',
  async function (this: ICustomWorld, auswahl: string) {
    await this.anspruchspruefung?.openSidepanelNichtErfüllt(auswahl);
    await this.anspruchspruefung?.setRadioNichtErfülltCheck();
  },
);

When('die Sachbearbeitung das Ergebnis speichert', async function (this: ICustomWorld) {
  await this.anspruchspruefung?.save();
});

When('die Zurücksetzen Option wählt', async function (this: ICustomWorld) {
  await this.anspruchspruefung?.clickReset();
  await this.einrichtungen?.wait();
});

When('die Sachbearbeitung auf Sachverhalt aufklären klickt', async function (this: ICustomWorld) {
  const pagePromise = this.page?.waitForEvent('popup');
  await this.anspruchspruefung?.clickOnSachverhaltAufklaeren();
  const page2 = await pagePromise;
  this.sachverhaltsaufklaerung = new Sachverhaltsaufklaerung(page2!);
});

When(
  'die Sachbearbeitung auf der Anspruchsprüfung-Seite Antrag bewilligen klickt',
  async function (this: ICustomWorld) {
    //await this.page?.waitForTimeout(2000);
    await this.anspruchspruefung?.clickOnAntragBewilligen();
  },
);

When(
  'die Sachbearbeitung auf der Anspruchsprüfung-Seite Antrag ablehnen klickt',
  async function (this: ICustomWorld) {
    await this.anspruchspruefung?.clickOnAntragAblehnen();
  },
);

When(
  'die Sachbearbeitung in rvText Absenden in Antrag Ablehnung page geklickt hat',
  async function (this: ICustomWorld) {
    await this.page?.waitForTimeout(3000);
    await this.anspruchspruefung?.clickOnAbsenden();
  },
);

When(
  'die Sachbearbeitung in rvText in Sachverhalt aufklaeren auf Herunterladen geklickt hat',
  async function (this: ICustomWorld) {
    await this.page?.waitForTimeout(3000);
    await this.sachverhaltsaufklaerung?.clickOnHerunterladen();
    //await this.page?.waitForTimeout(2000);
  },
);

When('die Sachbearbeitung auf Tab im rvText Iframe drückt', async function (this: ICustomWorld) {
  await this.sachverhaltsaufklaerung?.clickOnTabInIframe();
});

When(
  'die Sachbearbeitung auf OK in Antrag Ablehnung page geklickt hat',
  async function (this: ICustomWorld) {
    await this.page?.waitForTimeout(3000);
    await this.anspruchspruefung?.clickOnOK();
  },
);

When(
  'die Sachbearbeitung auf Angaben zum Sachverhalt geklickt hat',
  async function (this: ICustomWorld) {
    await this.page?.waitForTimeout(3000);
    await this.sachverhaltsaufklaerung?.clickonAngabenzumSachverhalt();
  },
);

When(
  'die Sachbearbeitung in dem freien Textfeld2 {} eingeben hat',
  async function (this: ICustomWorld, text: string) {
    //await this.page?.waitForTimeout(2000);
    await this.sachverhaltsaufklaerung?.typetextAngabenzumSachverhalt(text);
  },
);

When(
  'die Sachbearbeitung in rvText versucht den Bescheid trotz technischem Problem zu versenden',
  async function (this: ICustomWorld) {
    const data = {
      code: 'ERROR',
      parameter: {
        errorCode: 'DocumentCompletionFailed',
        message:
          'Fehler bei der Verarbeitung des Dokuments: email  -> Empfänger Adresse: Die angegebene Zeichenfolge besitzt nicht das erforderliche Format; email  -> Empfänger Adresse: Die angegebene Zeichenfolge besitzt nicht das erforderliche Format',
      },
    };
    const eventInit = {
      data: JSON.stringify(data),
    } as MessageEventInit;
    //const event = new MessageEvent('message', eventInit);
    //window.dispatchEvent(event);
    //await this.page?.evaluate(() => window.dispatchEvent(event));
    this.page!.dispatchEvent('#sachverhaltsaufklaerung-iframe', 'message', eventInit);
  },
);

Then('öffnet sich die Einrichtungen-Seite', async function (this: ICustomWorld) {
  const uuid = await this.einrichtungen?.getUUID();
  expect(await this.einrichtungen?.checkSeite()).toEqual(
    `${getFrontendUrl()}/antrag/${uuid}/einrichtungen`,
  );
});

Then('wird die Überschrift "{}" angezeigt', async function (this: ICustomWorld, title: string) {
  expect(await this.anspruchspruefung?.getUeberschrift()).toEqual(title);
});

Then('wird die Unterüberschrift "{}" angezeigt', async function (this: ICustomWorld, text: string) {
  expect(await this.anspruchspruefung?.getUnterueberschrift()).toEqual(text);
});

Then('sind alle Aussteuerunggründe erfüllt', async function (this: ICustomWorld) {
  await this.einrichtungen?.wait();
  const anzahlRegeln = await this.anspruchspruefung?.getErfülltCount();
  expect(anzahlRegeln).toEqual(14);
});

Then(
  'hat die Sachbearbeitung die Möglichkeit den Antrag zu bewilligen',
  async function (this: ICustomWorld) {
    expect(await this.anspruchspruefung?.getButtonName()).toEqual('Antrag bewilligen');
  },
);

Then(
  'hat die Sachbearbeitung die Möglichkeit zur Einrichtungsauswahl weitergeleitet zu werden',
  async function (this: ICustomWorld) {
    expect(await this.anspruchspruefung?.getButtonName()).toEqual('Weiter zur Einrichtungswahl');
  },
);

Then('ist mindestens ein Prüfergebnis Nicht Erfüllt gegeben', async function (this: ICustomWorld) {
  await this.einrichtungen?.wait();
  expect(await this.anspruchspruefung?.getNichtErfülltCount()).toBeGreaterThan(0);
});

Then(
  'hat die Sachbearbeitung die Möglichkeit den Antrag abzulehnen',
  async function (this: ICustomWorld) {
    expect(await this.anspruchspruefung?.getButtonName()).toEqual('Antrag ablehnen');
  },
);

Then('ist kein Prüfergebnis Nicht Erfüllt gegeben', async function (this: ICustomWorld) {
  expect(await this.anspruchspruefung?.getNichtErfülltCount()).toEqual(0);
});

Then(
  'ist mindestens ein Prüfergebnis Nicht Ermitelbar gegeben',
  async function (this: ICustomWorld) {
    expect(await this.anspruchspruefung?.getNichtErmittelbarCount()).toBeGreaterThan(0);
  },
);

Then(
  'hat die Sachbearbeitung die Möglichkeit mit weiter zu navigieren',
  async function (this: ICustomWorld) {
    expect(await this.anspruchspruefung?.getButtonName()).toEqual('Weiter');
  },
);

Then(
  'wird der "{}" bei Antrag auf Altersrente angezeigt',
  async function (this: ICustomWorld, error: string) {
    expect(await this.anspruchspruefung?.isError()).toEqual('attention');
    expect(await this.anspruchspruefung?.getErrorText()).toEqual(error);
  },
);

Then('wird ein X-Symbol angezeigt', async function (this: ICustomWorld) {
  expect(await this.anspruchspruefung?.getNichtErfuelltIcon()).toBeTruthy();
});

Then('wird der X-Text "{}" angezeigt', async function (this: ICustomWorld, text: string) {
  expect(await this.anspruchspruefung?.getNichtErfuelltText()).toEqual(text);
});

Then(
  'wird in Nicht erfüllt die erste Regel "{}" angezeigt',
  async function (this: ICustomWorld, regel: string) {
    expect(await this.anspruchspruefung?.getRegel1()).toEqual(regel);
  },
);

Then(
  'wird in Nicht erfüllt die zweite Regel "{}" angezeigt',
  async function (this: ICustomWorld, regel: string) {
    expect(await this.anspruchspruefung?.getRegel2()).toEqual(regel);
  },
);

Then(
  'wird in Nicht erfüllt die dritte Regel "{}" angezeigt',
  async function (this: ICustomWorld, regel: string) {
    expect(await this.anspruchspruefung?.getRegel3()).toEqual(regel);
  },
);

Then(
  'wird in Nicht erfüllt die neue Regel "{}" angezeigt',
  async function (this: ICustomWorld, regel: string) {
    await this.einrichtungen?.wait();
    //expect(await this.anspruchspruefung?.getRegel3()).toEqual(regel);
    const vierteNichtErfuelltRegel = await this.anspruchspruefung?.getVierteNichtErfuelltRegel();
    expect(vierteNichtErfuelltRegel).toEqual(regel);
  },
);

Then(
  'wird in Nicht erfüllt der erste Grund "{}" angezeigt',
  async function (this: ICustomWorld, grund: string) {
    expect(await this.anspruchspruefung?.getBegründung1()).toEqual(grund);
  },
);

Then(
  'wird in Nicht erfüllt der zweite Grund "{}" angezeigt',
  async function (this: ICustomWorld, grund: string) {
    expect(await this.anspruchspruefung?.getBegründung2()).toEqual(grund);
  },
);

Then(
  'wird in Nicht erfüllt der dritte Grund "{}" angezeigt',
  async function (this: ICustomWorld, grund: string) {
    expect(await this.anspruchspruefung?.getBegründung3()).toContain(grund);
  },
);

Then(
  'wird in Nicht erfüllt der vierte Grund "{}" angezeigt',
  async function (this: ICustomWorld, grund: string) {
    expect(await this.anspruchspruefung?.getNichtErfuelltBegründung04()).toContain(grund);
  },
);

Then('wird ein Fragezeichen-Symbol angezeigt', async function (this: ICustomWorld) {
  expect(await this.anspruchspruefung?.getNichtErmittelbarIcon()).toBeTruthy();
});

Then(
  'wird der Fragezeichen-Text "{}" angezeigt',
  async function (this: ICustomWorld, text: string) {
    expect(await this.anspruchspruefung?.getNichtErmittelbarText()).toEqual(text);
  },
);

Then(
  'wird in Nicht ermittelbar die einzige Regel "{}" angezeigt',
  async function (this: ICustomWorld, grund: string) {
    expect(await this.anspruchspruefung?.getErsteNichtErmittelbarRegel()).toEqual(grund);
  },
);

Then(
  'wird in Nicht ermittelbar der Grund "{}" angezeigt',
  async function (this: ICustomWorld, grund: string) {
    expect(await this.anspruchspruefung?.getBegründung4()).toContain(grund);
  },
);

Then('wird ein Häkchen-Symbol angezeigt', async function (this: ICustomWorld) {
  expect(await this.anspruchspruefung?.getErfülltIcon()).toBeTruthy();
});

Then('wird der Häkchen-Text "{}" angezeigt', async function (this: ICustomWorld, text: string) {
  expect(await this.anspruchspruefung?.getErfülltText()).toEqual(text);
});

Then(
  'wird in Erfüllt die neue Regel "{}" angezeigt',
  async function (this: ICustomWorld, regel: string) {
    await this.einrichtungen?.wait();
    const erfuelltRegel = await this.anspruchspruefung?.getRegel7();
    expect(erfuelltRegel).toEqual(regel);
  },
);

Then(
  'wird durch Klicken auf das + Symbol die Liste der Erfüllt-Regeln angezeigt',
  async function (this: ICustomWorld) {
    await this.anspruchspruefung?.showErfuelltRegelListe();
  },
);

Then(
  'wird in Erfüllt die Regel Kein Antrag auf Altersrente öffnet',
  async function (this: ICustomWorld) {
    expect(await this.anspruchspruefung?.openSidepanelDritteErfuelltRegel());
  },
);

Then(
  'wird in Nicht Erfüllt die Regel Laufendes Rechtsbehelfsverfahren öffnet',
  async function (this: ICustomWorld) {
    expect(await this.anspruchspruefung?.openSidepanelVierteNichtErfuelltRegel());
  },
);

Then(
  'wird in Erfüllt die neue Beschreibung "{}" angezeigt',
  async function (this: ICustomWorld, grund: string) {
    expect(await this.anspruchspruefung?.getBegründung7()).toContain(grund);
  },
);

Then(
  'kann die Sachbearbeitung zwischen Erfüllt und Nicht Erfüllt wählen',
  async function (this: ICustomWorld) {
    expect(await this.anspruchspruefung?.getRadioErfüllt()).toBeTruthy();
    expect(await this.anspruchspruefung?.getRadioNichtErfüllt()).toBeTruthy();
  },
);

Then('ist das Ergebnis "{}" ausgewählt', async function (this: ICustomWorld, auswahl: string) {
  expect(await this.anspruchspruefung?.getRadioChecked(auswahl)).toBeTruthy;
});

Then(
  'wird der Platzhalter im Begründungsfeld "{}" angezeigt',
  async function (this: ICustomWorld, placeholder: string) {
    expect(await this.anspruchspruefung?.getPlaceholder()).toEqual(placeholder);
  },
);

Then(
  'ist die Änderungsansicht des Prüfergebnisses nicht sichtbar',
  async function (this: ICustomWorld) {
    expect(await this.anspruchspruefung?.isSite()).toBeTruthy;
  },
);

Then('ist die Begründung "{}"', async function (this: ICustomWorld, grund: string) {
  expect(await this.anspruchspruefung?.getBegründung()).toEqual(grund);
});

Then('die Sachbearbeitung auf dem Toggletip-Icon klickt', async function (this: ICustomWorld) {
  expect(await this.anspruchspruefung?.clicktToggleTip());
});

Then(
  'ist der Hinweistext in der Pop-up-Fenster "{}"',
  async function (this: ICustomWorld, tipp: string) {
    expect(await this.anspruchspruefung?.getTipp()).toContain(tipp);
  },
);

Then('ist die Infomeldung "{}"', async function (this: ICustomWorld, infomeldung: string) {
  expect(await this.anspruchspruefung?.getInfomeldung()).toEqual(infomeldung);
});

Then(
  'kann die Sachbearbeitung "{}" erneut bearbeiten',
  async function (this: ICustomWorld, regel: string) {
    expect(await this.anspruchspruefung?.isChangeAendern(regel)).toBeTruthy;
  },
);

Then(
  'ist der Text {} für nicht erfüllt zu sehen',
  async function (this: ICustomWorld, auswahl: string) {
    expect(await this.anspruchspruefung?.getRadioNichtErfülltText()).toContain(auswahl);
  },
);

Then(
  'ist eine Zeichenanzahl mit {} neben den Text "{}" zu sehen',
  async function (this: ICustomWorld, auswahl1: string, auswahl2: string) {
    expect(await this.anspruchspruefung?.getZeichen()).toContain(auswahl1);
    expect(await this.anspruchspruefung?.getBegruendungLabel()).toContain(auswahl2);
  },
);
Then(
  'sollte die Zeichenanzahl "{}" oben dem BegründungsFeld angezeigt',
  async function (this: ICustomWorld, auswahl: string) {
    expect(await this.anspruchspruefung?.getZeichen()).toContain(auswahl);
  },
);

Then('wird die Frage {} angezeigt', async function (this: ICustomWorld, frage: string) {
  expect(await this.anspruchspruefung?.getFrage()).toContain(frage);
});

Then(
  'ist die Änderungsansicht immernoch sichtbar bei nicht erfüllt',
  async function (this: ICustomWorld) {
    expect(await this.anspruchspruefung?.getSidepanelTitle()).toEqual(
      'Ergebnis ändern - Antrag auf Altersrente',
    );
  },
);

Then(
  'ist die Änderungsansicht immernoch sichtbar bei nicht ermittelbar',
  async function (this: ICustomWorld) {
    expect(await this.anspruchspruefung?.getSidepanelTitle()).toEqual(
      'Ergebnis ändern - Laufendes Rechtsbehelfsverfahren',
    );
  },
);

Then('wird der "{}" angezeigt', async function (this: ICustomWorld, error: string) {
  expect(await this.anspruchspruefung?.isAlert(error)).toEqual('attention');
  expect(await this.anspruchspruefung?.getFehler(error)).toEqual(error);
});

Then('ist der Text {} für erfüllt zu sehen', async function (this: ICustomWorld, auswahl: string) {
  expect(await this.anspruchspruefung?.getRadioErfülltText()).toEqual(auswahl);
});

Then('ist kein Zurücksetzen Option sichtbar', async function (this: ICustomWorld) {
  expect(await this.anspruchspruefung?.getResetVisible()).toBeFalsy();
});

Then('ist die Zurücksetzen Option sichtbar', async function (this: ICustomWorld) {
  expect(await this.anspruchspruefung?.getResetVisible()).toBeTruthy();
});

Then(
  'ist das Ergebnis "{}" nicht ausgewählt',
  async function (this: ICustomWorld, auswahl: string) {
    expect(await this.anspruchspruefung?.getRadioChecked(auswahl)).toBeFalsy();
  },
);

Then(
  'ist ein Text "{}" unter nicht erfüllt Option zu sehen',
  async function (this: ICustomWorld, prüfergebnis: string) {
    expect(await this.anspruchspruefung?.getMaschinellesErgebnis()).toEqual(prüfergebnis);
  },
);

Then('ist die Meldung "{}" zu sehen', async function (this: ICustomWorld, prüfergebnis: string) {
  expect(await this.anspruchspruefung?.getgGeaenderteMeldung()).toEqual(prüfergebnis);
});

Then(
  'ist ein abgeänderter Status mit dem Text "{}" zu sehen',
  async function (this: ICustomWorld, maschÄndern: string) {
    const aktuellDatum = format(new Date(), 'dd.MM.yyyy');
    const erwarteteText = maschÄndern.replace('<DATUM>', aktuellDatum);
    expect(await this.anspruchspruefung?.getMaschinellesÄndern(maschÄndern)).toEqual(erwarteteText);
  },
);

Then(
  'ist ein abgeänderter Status für Staatsangehörigkeit mit dem Text "{}" zu sehen',
  async function (this: ICustomWorld, maschÄndern: string) {
    const aktuellDatum = format(new Date(), 'dd.MM.yyyy');
    const erwarteteText = maschÄndern.replace('<DATUM>', aktuellDatum);
    expect(await this.anspruchspruefung?.getMaschinellesÄndernStaats()).toEqual(erwarteteText);
  },
);

Then(
  'wird unter Nicht Erfüllt das Ergebniss "{}" angezeigt',
  async function (this: ICustomWorld, regel: string) {
    expect(await this.anspruchspruefung?.getkeinNichtErfuellt()).toEqual(regel);
  },
);

Then(
  'wird unter Nicht Ermittelbar das Ergebniss "{}" angezeigt',
  async function (this: ICustomWorld, regel: string) {
    expect(await this.anspruchspruefung?.getkeinNichtErm()).toEqual(regel);
  },
);

Then(
  'wird unter Erfüllt das Ergebniss "{}" angezeigt',
  async function (this: ICustomWorld, regel: string) {
    expect(await this.anspruchspruefung?.getkeinErfuellt()).toEqual(regel);
  },
);
Then(
  'wird in Nicht Erfüllt die Regel {} angezeigt',
  async function (this: ICustomWorld, regel: string) {
    expect(await this.anspruchspruefung?.getRegelNichtErfuellt(regel)).toEqual(regel);
  },
);

Then(
  'wird in Nicht Erfüllt der Grund {} angezeigt',
  async function (this: ICustomWorld, regel: string) {
    expect(await this.anspruchspruefung?.getBegründungNichtErfuellt(regel)).toEqual(regel);
  },
);

Then('wird in Erfüllt die Regel {} angezeigt', async function (this: ICustomWorld, regel: string) {
  expect(await this.anspruchspruefung?.getRegelErfuellt(regel)).toEqual(regel);
});

Then(
  'wird in Erfüllt die Beschreibung {} angezeigt',
  async function (this: ICustomWorld, regel: string) {
    expect(await this.anspruchspruefung?.getBegründungErfuellt(regel)).toEqual(regel);
  },
);

Then(
  'wird in Nicht Ermittelbar die Regel {} angezeigt',
  async function (this: ICustomWorld, regel: string) {
    expect(await this.anspruchspruefung?.getRegelNichtErmittelbar(regel)).toEqual(regel);
  },
);

Then(
  'wird in Nicht Ermittelbar der Grund {} angezeigt',
  async function (this: ICustomWorld, regel: string) {
    expect(await this.anspruchspruefung?.getBegründungNichtErmittelbar(regel)).toEqual(regel);
  },
);

Then(
  'kann das Ergebnis für Ergebnis ändern - {} geändert werden',
  async function (this: ICustomWorld, regel: string) {
    expect(await this.anspruchspruefung?.getRegelNichtErfuellt(regel)).toEqual(regel);
  },
);

Then(
  'kann Ergebnis für Ergebnis ändern - {} geändert werden',
  async function (this: ICustomWorld, regel: string) {
    expect(await this.anspruchspruefung?.getRegelNichtErmittelbar(regel)).toEqual(regel);
  },
);

Then(
  'wird die Paperboy-Komponente mit der Textverarbeitung angezeigt',
  async function (this: ICustomWorld) {
    await expect(this.sachverhaltsaufklaerung!.paperboycomponent).toBeVisible();
  },
);

Then('ist die Zwischenüberschrift vorhanden', async function (this: ICustomWorld) {
  await expect(this.sachverhaltsaufklaerung!.zwischenÜberschift).toBeVisible();
});

Then('ist der Untertitel mit einer Beschreibung vorhanden', async function (this: ICustomWorld) {
  await expect(this.sachverhaltsaufklaerung!.untertitel).toBeVisible();
});

Then('wird Erfüllt Liste geöffnet', async function (this: ICustomWorld) {
  return await this.anspruchspruefung?.openErfülltList();
});

Then('wird Nicht Erfüllt Liste geöffnet', async function (this: ICustomWorld) {
  return await this.anspruchspruefung?.openNichtErfülltList();
});

Then('wird Nicht Ermittelbar Liste geöffnet', async function (this: ICustomWorld) {
  return await this.anspruchspruefung?.openNichtErmittelbarList();
});

Then(
  'wird in Nicht Erfüllt der Text "{}" angezeigt',
  async function (this: ICustomWorld, begruendung: string) {
    expect(await this.anspruchspruefung?.getListItemNichtErfüllt()).toEqual(begruendung);
  },
);

Then(
  'wird in Erfüllt der Text "{}" angezeigt',
  async function (this: ICustomWorld, begruendung: string) {
    expect(await this.anspruchspruefung?.getListItemErfüllt()).toEqual(begruendung);
  },
);

Then(
  'wird in Nicht Ermittelbar der Text "{}" angezeigt',
  async function (this: ICustomWorld, begruendung: string) {
    expect(await this.anspruchspruefung?.getListItemNichtErmittelbar()).toEqual(begruendung);
  },
);

Then(
  'wird nach der Anspruchsprüfung-Seite der Hinweis auf eine erfolgreiche Bewilligung des Antrags angezeigt',
  async function (this: ICustomWorld) {
    expect(await this.anspruchspruefung?.istAntragBewilligt()).toBeTruthy();
  },
);

Then(
  'wird nach der Anspruchsprüfung-Seite die Statusmeldung für die fehlerhafte Weiterverarbeitung der Antragsbewillingung angezeigt',
  async function (this: ICustomWorld) {
    //await this.page?.waitForTimeout(2000);
    expect(await this.anspruchspruefung?.istAntragBewilligtTechFehler()).toBeTruthy();
  },
);

Then(
  'wird nach der Anspruchsprüfung-Seite die Statusmeldung für die fehlerhafte Weiterverarbeitung der Antragsablehnung angezeigt',
  async function (this: ICustomWorld) {
    await expect(this.anspruchspruefung!.antragAblehnenTechFehler).toBeVisible({ timeout: 10000 });
  },
);

Then('öffnet sich ein IFrame für einen Ablehnungsbescheid', async function (this: ICustomWorld) {
  await expect(this.anspruchspruefung!.iframeAntragAblehnen).toBeVisible({ timeout: 10000 });
});

Then(
  'wird eine entsprechende Überschrift für den Ablehnungsbescheid angezeigt',
  async function (this: ICustomWorld) {
    await expect(this.anspruchspruefung!.antragAblehnenÜberschift).toBeVisible();
  },
);

Then(
  'wird eine entsprechende Zwischenüberschrift für den Ablehnungsbescheid angezeigt',
  async function (this: ICustomWorld) {
    await expect(this.anspruchspruefung!.antragAblehnenZwischenÜberschift).toBeVisible();
  },
);

Then(
  'wird eine entsprechende Beschreibung für den Ablehnungsbescheid angezeigt',
  async function (this: ICustomWorld) {
    await expect(this.anspruchspruefung!.antragAblehnenBeschreibung).toBeVisible();
  },
);

Then('wird die Telefonnummer angezeigt', async function (this: ICustomWorld) {
  await expect(this.anspruchspruefung!.telNummer).toBeVisible();
});

Then(
  'wird eine entsprechende Meldung für die erfolgreiche Antragsablehnung angezeigt',
  async function (this: ICustomWorld) {
    await expect(this.anspruchspruefung!.antragAbelehnenErfolgsmeldung).toBeVisible({
      timeout: 10000,
    });
  },
);

Then('wird Datum der Änderung angezeigt', async function (this: ICustomWorld) {
  await expect(this.anspruchspruefung!.änderungsDatum).toBeVisible();
});

Then('die Sachbearbeitung auf Speichern drückt', async function (this: ICustomWorld) {
  await this.anspruchspruefung?.save();
});

Then('wird eine entsprechende Datei Heruntergeladen', async function (this: ICustomWorld) {
  expect(this.sachverhaltsaufklaerung?.isdownloaded()).toBeTruthy();
});

Then('wird in Tooltip "{}" angezeigt', async function (this: ICustomWorld, tooltip: string) {
  expect(await this.anspruchspruefung?.getRegelTip1()).toEqual(tooltip);
});
