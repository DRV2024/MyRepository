import { ICustomWorld } from '../support/custom-world';
import { expect } from '@playwright/test';
import { Then } from '@cucumber/cucumber';
Then(
  'erwartet die Sachbearbeitung, dass die Versicherungsnummer aus Antragsaufnahme und die VSNR aus Backend identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getvsnrTextAnzeigefeld()).toEqual(result['vsnr']);
  },
);

Then(
  'erwartet die Sachbearbeitung, dass die Versicherungsnummer aus Antragsaufnahme und die aus Entwurf-BE identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getvsnrTextAnzeigefeld()).toEqual(result.antrag['vsnr']);
  },
);

Then(
  'erwartet die Sachbearbeitung, dass der vorbelegte Nachname aus Antragsaufnahme und der Nachname aus Backend identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getNachnameFeld()).toEqual(result['nachname']);
  },
);

Then(
  'erwartet die Sachbearbeitung, dass der vorbelegte Nachname aus Antragsaufnahme und der aus Entwurf-BE identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getNachnameFeld()).toEqual(result.antrag['nachname']);
  },
);

Then(
  'wird der entsprechende Hinweis bzgl. Personendaten für Nachname angezeigt',
  async function (this: ICustomWorld) {
    const nachnameValue = await this.antragaufnahme?.getNachnameFeld();
    if (nachnameValue?.trim().length !== 0) {
      expect(await this.antragaufnahme?.istNachnameFeldHinweisSichtbar()).toBeTruthy();
    }
  },
);

Then(
  'erwartet die Sachbearbeitung, dass der vorbelegte Vorname aus Antragsaufnahme und der Vorname aus Backend identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getVornameFeld()).toEqual(result['vorname']);
  },
);

Then(
  'erwartet die Sachbearbeitung, dass der vorbelegte Vorname aus Antragsaufnahme und der aus Entwurf-BE identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getVornameFeld()).toEqual(result.antrag['vorname']);
  },
);

Then(
  'wird der entsprechende Hinweis bzgl. Personendaten für Vornamen angezeigt',
  async function (this: ICustomWorld) {
    const vornameValue = await this.antragaufnahme?.getVornameFeld();
    if (vornameValue?.trim().length !== 0) {
      expect(await this.antragaufnahme?.istVornameFeldHinweisSichtbar()).toBeTruthy();
    }
  },
);

Then(
  'erwartet die Sachbearbeitung, dass der vorbelegte Geburtsname aus Antragsaufnahme und der Geburtsname aus Backend identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getGeburtsnameFeld()).toEqual(result['geburtsname']);
  },
);

Then(
  'erwartet die Sachbearbeitung, dass das vorbelegte Geburtsname aus Antragsaufnahme und das aus Entwurf-BE identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getGeburtsnameFeld()).toEqual(result.antrag['geburtsname']);
  },
);

Then(
  'wird der entsprechende Hinweis bzgl. Personendaten für Geburtsname angezeigt',
  async function (this: ICustomWorld) {
    const geburtsnameValue = await this.antragaufnahme?.getGeburtsnameFeld();
    if (geburtsnameValue?.trim().length !== 0) {
      expect(await this.antragaufnahme?.istGeburtsnameFeldHinweisSichtbar()).toBeTruthy();
    }
  },
);

Then(
  'erwartet die Sachbearbeitung, dass der vorbelegte frühere Name aus Antragsaufnahme und der frühere Name aus Backend identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getFruehereNamenFeld()).toEqual(result['fruehererName']);
  },
);

Then(
  'wird der entsprechende Hinweis bzgl. Personendaten für früheren Namen angezeigt',
  async function (this: ICustomWorld) {
    const frueherenamenValue = await this.antragaufnahme?.getFruehereNamenFeld();
    if (frueherenamenValue?.trim().length !== 0) {
      expect(await this.antragaufnahme?.istFruehereNamenFeldHinweisSichtbar()).toBeTruthy();
    }
  },
);

Then(
  'erwartet die Sachbearbeitung, dass das vorbelegte Geburtsdatum aus Antragsaufnahme und das Geburtsdatum aus Backend identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getGeburtsdatumFeld()).toEqual(result['geburtsdatum']);
  },
);

Then(
  'erwartet die Sachbearbeitung, dass das vorbelegte Geburtsdatum aus Antragsaufnahme und das aus Entwurf-BE identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getGeburtsdatumFeld()).toEqual(result.antrag['geburtsdatum']);
  },
);

Then(
  'wird der entsprechende Hinweis bzgl. Personendaten für Geburtsdatum angezeigt',
  async function (this: ICustomWorld) {
    const geburtsdatumValue = await this.antragaufnahme?.getGeburtsdatumFeld();
    if (geburtsdatumValue?.trim().length !== 0) {
      expect(await this.antragaufnahme?.istGeburtsdatumFeldHinweisSichtbar()).toBeTruthy();
    }
  },
);
Then(
  'erwartet die Sachbearbeitung, dass der vorbelegte Geburtsort aus Antragsaufnahme und der Geburtsort aus Backend identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getGeburtsortFeld()).toEqual(result['geburtsort']);
  },
);

Then(
  'erwartet die Sachbearbeitung, dass der vorbelegte Geburtsort aus Antragsaufnahme und der aus Entwurf-BE identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getGeburtsortFeld()).toEqual(result.antrag['geburtsort']);
  },
);

Then(
  'wird der entsprechende Hinweis bzgl. Personendaten für Geburtsort angezeigt',
  async function (this: ICustomWorld) {
    const geburtsortValue = await this.antragaufnahme?.getGeburtsortFeld();
    if (geburtsortValue?.trim().length !== 0) {
      expect(await this.antragaufnahme?.istGeburtsortFeldHinweisSichtbar()).toBeTruthy();
    }
  },
);

Then(
  'erwartet die Sachbearbeitung, dass das vorbelegte Vorsatzwort aus Antragsaufnahme und das Vorsatzwort aus Backend identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getVorsatzwortDropDown()).toEqual(result['vorsatzwort']);
  },
);

Then(
  'wird der entsprechende Hinweis bzgl. Personendaten für Vorsatzwort angezeigt',
  async function (this: ICustomWorld) {
    const vorsatzwortValue = await this.antragaufnahme?.getVorsatzwortDropDown();
    if (vorsatzwortValue?.trim().length !== 0) {
      expect(await this.antragaufnahme?.istVorsatzwortFeldHinweisSichtbar()).toBeTruthy();
    }
  },
);

Then(
  'erwartet die Sachbearbeitung, dass der vorbelegte Namenszusatz aus Antragsaufnahme und der Namenszusatz aus Backend identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getNamenszusatzDropDown()).toEqual(
      '' + result['namenszusatz'] + '',
    );
  },
);

Then(
  'wird der entsprechende Hinweis bzgl. Personendaten für Namenszusatz angezeigt',
  async function (this: ICustomWorld) {
    const namenszusatzValue = await this.antragaufnahme?.getNamenszusatzDropDown();
    if (namenszusatzValue?.trim().length !== 0) {
      expect(await this.antragaufnahme?.istNamenszusatzFeldHinweisSichtbar()).toBeTruthy();
    }
  },
);

Then(
  'erwartet die Sachbearbeitung, dass der vorbelegte Titel aus Antragsaufnahme und der Titel aus Backend identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getTitelFeld()).toEqual(result['titel']);
  },
);

Then(
  'wird der entsprechende Hinweis bzgl. Personendaten für Titel angezeigt',
  async function (this: ICustomWorld) {
    const titelValue = await this.antragaufnahme?.getTitelFeld();
    if (titelValue?.trim().length !== 0) {
      expect(await this.antragaufnahme?.istTitelFeldHinweisSichtbar()).toBeTruthy();
    }
  },
);

Then(
  'erwartet die Sachbearbeitung, dass das vorbelegte Geschlecht aus Antragsaufnahme und das Geschlecht aus Backend identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getGeschlechtDropDown()).toEqual(result['geschlecht']);
  },
);

Then(
  'wird der entsprechende Hinweis bzgl. Personendaten für Geschlecht angezeigt',
  async function (this: ICustomWorld) {
    const geschlechtValue = await this.antragaufnahme?.getGeschlechtDropDown();
    if (geschlechtValue?.trim().length !== 0) {
      expect(await this.antragaufnahme?.istGeschlechtFeldHinweisSichtbar()).toBeTruthy();
    }
  },
);

Then(
  'erwartet die Sachbearbeitung, dass die vorbelegte Adresse aus Antragsaufnahme und die Adresse aus Backend identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getAdresseFeld()).toEqual(result['strasse']);
  },
);

Then(
  'erwartet die Sachbearbeitung, dass die vorbelegte Adresse aus Antragsaufnahme und die aus Entwurf-BE identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getAdresseFeld()).toEqual(result.antrag['strasse']);
  },
);

Then(
  'wird der entsprechende Hinweis bzgl. Personendaten für Adresse angezeigt',
  async function (this: ICustomWorld) {
    const adresseValue = await this.antragaufnahme?.getAdresseFeld();
    if (adresseValue?.trim().length !== 0) {
      expect(await this.antragaufnahme?.istAdresseFeldHinweisSichtbar()).toBeTruthy();
    }
  },
);

Then(
  'erwartet die Sachbearbeitung, dass die vorbelegte Postleitzahl aus Antragsaufnahme und die Postleitzahl aus Backend identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getPostleitzahlFeld()).toEqual(result['plz']);
  },
);

Then(
  'erwartet die Sachbearbeitung, dass die vorbelegte Postleitzahl aus Antragsaufnahme und die aus Entwurf-BE identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getPostleitzahlFeld()).toEqual(result.antrag['plz']);
  },
);

Then(
  'wird der entsprechende Hinweis bzgl. Personendaten für Postleitzahl angezeigt',
  async function (this: ICustomWorld) {
    const postleitzahlValue = await this.antragaufnahme?.getPostleitzahlFeld();
    if (postleitzahlValue?.trim().length !== 0) {
      expect(await this.antragaufnahme?.istPostleitzahlFeldHinweisSichtbar()).toBeTruthy();
    }
  },
);

Then(
  'erwartet die Sachbearbeitung, dass der vorbelegte Wohnort aus Antragsaufnahme und der Wohnort aus Backend identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getWohnortFeld()).toEqual(result['wohnort']);
  },
);

Then(
  'erwartet die Sachbearbeitung, dass der vorbelegte Wohnort aus Antragsaufnahme und der aus Entwurf-BE identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getWohnortFeld()).toEqual(result.antrag['wohnort']);
  },
);

Then(
  'wird der entsprechende Hinweis bzgl. Personendaten für Wohnort angezeigt',
  async function (this: ICustomWorld) {
    const wohnortValue = await this.antragaufnahme?.getWohnortFeld();
    if (wohnortValue?.trim().length !== 0) {
      expect(await this.antragaufnahme?.istWohnortFeldHinweisSichtbar()).toBeTruthy();
    }
  },
);

Then(
  'erwartet die Sachbearbeitung, dass die vorbelegte Staatsangehörigkeit aus Antragsaufnahme und die aus Backend identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getStaatsangehoerigkeitDropDown()).toEqual(
      result['staatsangehoerigkeit'],
    );
  },
);

Then(
  'wird der entsprechende Hinweis bzgl. Staatsangehörigkeit angezeigt',
  async function (this: ICustomWorld) {
    const staatsangehoerigkeitValue = await this.antragaufnahme?.getStaatsangehoerigkeitDropDown();
    if (staatsangehoerigkeitValue?.trim().length !== 0) {
      expect(await this.antragaufnahme?.istStaatsangehoerigkeitFeldHinweisSichtbar()).toBeTruthy();
    }
  },
);

Then(
  'erwartet die Sachbearbeitung, dass die vorbelegte Telefonnummer aus Antragsaufnahme und die aus Backend identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getTelefonnummerFeld()).toEqual(result['telefon']);
  },
);

Then(
  'wird der entsprechende Hinweis bzgl. Personendaten für Telefonnummer angezeigt',
  async function (this: ICustomWorld) {
    const telefonnummerValue = await this.antragaufnahme?.getTelefonnummerFeld();
    if (telefonnummerValue?.trim().length !== 0) {
      expect(await this.antragaufnahme?.istTelefonnummerFeldHinweisSichtbar()).toBeTruthy();
    }
  },
);

Then(
  'erwartet die Sachbearbeitung, dass die vorbelegte Telefaxnummer aus Antragsaufnahme und die aus Backend identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getTelefaxFeld()).toEqual(result['telefax']);
  },
);

Then(
  'wird der entsprechende Hinweis bzgl. Personendaten für Telefaxnummer angezeigt',
  async function (this: ICustomWorld) {
    const telefaxValue = await this.antragaufnahme?.getTelefaxFeld();
    if (telefaxValue?.trim().length !== 0) {
      expect(await this.antragaufnahme?.istTelefaxFeldHinweisSichtbar()).toBeTruthy();
    }
  },
);

Then(
  'erwartet die Sachbearbeitung, dass die vorbelegte DE-Mail aus Antragsaufnahme und die aus Entwurf-BE identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getDeMailFeld()).toEqual(result.antrag['deMailAdresse']);
  },
);

Then(
  'erwartet die Sachbearbeitung, dass der vorbelegte Großdruck aus Antragsaufnahme und der aus Entwurf-BE identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.istGroßDruckCBAktiviert()).toEqual(
      result.antrag['grossdruck'],
    );
  },
);

Then(
  'erwartet die Sachbearbeitung, dass die vorbelegte Kurzschrift aus Antragsaufnahme und die aus Entwurf-BE identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.istInBrailleKurzCBAktiviert()).toEqual(
      result.antrag['kurzschrift'],
    );
  },
);

Then(
  'erwartet die Sachbearbeitung, dass die vorbelegte Vollschrift aus Antragsaufnahme und die aus Entwurf-BE identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.istInBrailleVollCBAktiviert()).toEqual(
      result.antrag['vollschrift'],
    );
  },
);

Then(
  'erwartet die Sachbearbeitung, dass die vorbelegte CD aus Antragsaufnahme und die aus Entwurf-BE identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.istAlsCDCBAktiviert()).toEqual(result.antrag['cd']);
  },
);

Then(
  'erwartet die Sachbearbeitung, dass das vorbelegte als Hörmedium aus Antragsaufnahme und das aus Entwurf-BE identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.istAlsHoermediumCBAktiviert()).toEqual(
      result.antrag['hoermedium'],
    );
  },
);

Then(
  'erwartet die Sachbearbeitung, dass die vorbelegten Bemerkungen aus Antragsaufnahme und die aus Entwurf-BE identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getBemerkungenFeld()).toEqual(result.antrag['bemerkungen']);
  },
);

Then(
  'erwartet die Sachbearbeitung, dass die vorbelegte Reha 1 aus Antragsaufnahme und die aus Entwurf-BE identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getRehaEinR1feld()).toEqual(
      result.antrag['einrichtungStartAuf'],
    );
  },
);

Then(
  'erwartet die Sachbearbeitung, dass die vorbelegte Reha 2 aus Antragsaufnahme und die aus Entwurf-BE identisch sind',
  async function (this: ICustomWorld) {
    const buffer = await this.requestResponse?.body();
    const result = JSON.parse(buffer!.toString());
    expect(await this.antragaufnahme?.getRehaEinR2feld()).toEqual(
      result.antrag['einrichtungTraining'],
    );
  },
);
