import { ICustomWorld } from '../support/custom-world';
import { Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';

Then('wird der Text "{}" angezeigt', async function (this: ICustomWorld, text: string) {
  expect(await this.versichertenHeader?.getUeberschrift()).toEqual(text);
});

Then(
  'wird die Versicherungsnummer "{}" zur versicherten Person angezeigt',
  async function (this: ICustomWorld, vsnr: string) {
    expect(await this.versichertenHeader?.getVersicherterVSNR()).toEqual(vsnr);
  },
);

Then(
  'wird die Fehler-Notification {} angezeigt',
  async function (this: ICustomWorld, error: string) {
    expect(await this.versichertenHeader?.getErrorNotification()).toBeTruthy;
    expect(await this.versichertenHeader?.getErrorTitle()).toEqual(error);
  },
);

Then(
  'wird der Grund {} für den Fehler angezeigt',
  async function (this: ICustomWorld, error: string) {
    expect(await this.versichertenHeader?.getErrorText()).toEqual(error);
  },
);
